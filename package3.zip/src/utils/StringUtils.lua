require "debug.lua"

StringUtils = class("StringUtils")

StringUtils.__index = StringUtils

function StringUtils.toThousandSeparate(num,sep)
    local fushu = false
    if num < 0 then fushu = true end
    
    num = math.abs(num)
    
    local ori = tostring(num)
    if string.len(ori) < 4 or not sep or sep=="" then
        if fushu then
            ori = "-"..ori
        end
        return ori
    end
    local startIndex = string.len(ori)-2
    local endIndex = string.len(ori)
    local str = ""
    while startIndex do
        local s = string.sub(ori,startIndex,endIndex)
        if not str or str == "" then
            str = s
        else
            str = s..sep..str
        end
        endIndex = startIndex - 1
        startIndex = endIndex-2
        if startIndex < 1 then
            startIndex = 1
        end
        if endIndex < 1 then
            break
        end
    end
    
    if fushu then
        str = "-"..str
    end
    
    return str
end

function StringUtils.split(str,sep)
    local t = {}
    local startIndex = 1
    local endIndex = 1
    local s = 0
    while true do
        if startIndex> #str then
            break
        end
        endIndex = string.find(str,sep,startIndex)
        if endIndex==nil or endIndex<1 then
            endIndex = #str+1
        end
        
        local s = string.sub(str,startIndex,endIndex-1)
        startIndex = endIndex+1
        table.insert(t,#t+1,s)
    end
    return t
end