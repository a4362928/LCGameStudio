require "debug.lua"

TweenUtils = class("TweenUtils")

TweenUtils.__index = TweenUtils

TweenUtils.tweens = {}

function TweenUtils.tweenTextNumber(t,dur,from,to,handler)
    if t==nil then return end

    TweenUtils.stopTweenTextNumber(t)
    
    local tweenObj = {target=t,dur=dur,from=from,to=to,handler=handler}
    table.insert(TweenUtils.tweens,#TweenUtils.tweens+1,tweenObj)
    
    t:setString(from)
    
    local cur = 0
    local tickScheduler = nil
    local tick = function(interval)
        cur = cur + interval
        if cur>dur then cur=dur end
        local p = cur/dur
        local curNum = math.ceil(from + p*(to-from))
        t:setString(curNum)
        
        --结束
        if cur>= dur then
            TweenUtils.stopTweenTextNumber(t)
            handler()
            return
        end
    end
    tickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false)
    tweenObj.scheduler = tickScheduler
end

function TweenUtils.stopTweenTextNumber(t)
    for i=1, #TweenUtils.tweens do
        local obj = TweenUtils.tweens[i]
        if obj.target==t then
            local tickScheduler = obj.scheduler
            if tickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(tickScheduler) end
            
            table.remove(TweenUtils.tweens,i)
            --cclog("TweenUtils.stopTweenTextNumber %d",#TweenUtils.tweens)
            break
        end
    end
end

function TweenUtils.getTweenTextTweenObj(t)
    for i=1, #TweenUtils.tweens do
        local obj = TweenUtils.tweens[i]
        if obj.target==t then
            return obj
        end
    end
    return nil
end