require "debug.lua"

TableUtils = class("TableUtils")

TableUtils.__index = TableUtils

function TableUtils.tClone(t)
    local clone = {}
    for i=1, #t do
        table.insert(clone,#clone+1,t[i])
    end

    return clone
end

function TableUtils.tConcat(t1,t2)
    for i=1, #t2 do
        table.insert(t1,#t1+1,t2[i])
    end
end

function TableUtils.tSplice(str,sep)
    local t = {}
    local startIndex = 0
    local endIndex = 0
    endIndex = string.find(str,sep)
    endIndex = endIndex or 0
    if endIndex == 0 then
        table.insert(t,#t+1,str)
        return t
    end

    while endIndex and endIndex > 0 do
        if (endIndex-1) < (startIndex+1) then
            break
        end
        local d = string.sub(str,startIndex+1,endIndex-1)
        if d and d ~= "" then
            table.insert(t,#t+1,d)
        end
        startIndex = endIndex
        endIndex = string.find(str,sep,startIndex+1)
    end
    
    return t
end

function TableUtils.mtLength(arr)
    local len = 0
    for k, v in pairs(arr) do
        len = len + 1
    end
    return len
end