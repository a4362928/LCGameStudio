require "debug.lua"

DelayUtils = class("DelayUtils")

DelayUtils.__index = DelayUtils

function DelayUtils.delayCall(delay,handler,target,...)
    if not handler or not target then
        return
    end
    
    local params = {...}
    local tickScheduler = nil
    
    local function execHandler()
        if #params==0 then
            handler(target)
        elseif #params==1 then
            handler(target,params[1])
        elseif #params==2 then
            handler(target,params[1],params[2])
        elseif #params==3 then
            handler(target,params[1],params[2],params[3])
        elseif #params==4 then
            handler(target,params[1],params[2],params[3],params[4])
        elseif #params==5 then
            handler(target,params[1],params[2],params[3],params[4],params[5])
        end
    end

    --local seq = cc.Sequence:create(cc.DelayTime:create(delay),cc.CallFunc:create(execHandler,{...}))
    --self:runAction(seq)
    
    local total = 0
    local tick = function(interval)
        total = total+interval
        if total>=delay then
            if tickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(tickScheduler) end
            execHandler()
            return
        end
    end
    
    tickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false)
end