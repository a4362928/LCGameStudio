local _cclogs={}
local showDisplay = nil
local displayScheduler

function cclog(...)
    if Config.debugEnabled then
        print("[LOG] "..string.format(...))
    end
end

function ccwarn(...)
    if Config.debugEnabled then
        print("[WARN] "..string.format(...))
    end
end

function ccshow(...)
    if Config.debugEnabled then
        if not showDisplay then
            local visibleSize = cc.Director:getInstance():getVisibleSize()
            
            showDisplay = ccui.Text:create()
            showDisplay:retain()
            showDisplay:setColor(cc.c3b(255, 0, 0))
            showDisplay:setTextAreaSize(cc.size(visibleSize.width-10,visibleSize.height-20))
            showDisplay:setPosition(cc.p(10,visibleSize.height-10))
            showDisplay:setAnchorPoint(cc.p(0, 1))
            
            local tick = function()
                if showDisplay:getParent()~=cc.Director:getInstance():getRunningScene() then
                    if showDisplay:getParent() then
                        showDisplay:removeFromParent(false)
                    end

                    if cc.Director:getInstance():getRunningScene() then
                        cc.Director:getInstance():getRunningScene():addChild(showDisplay)
                    end
                end
            end
            displayScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0.1, false)
        end
        
        local old = showDisplay:getString()
        showDisplay:setString(old.."\n"..string.format(...))
    end
end

function ccerror(...)
    if Config.debugEnabled then
        print("[ERROR] "..string.format(...))
        ccshow(...)
    end
end

function _cclog(...)
    local n = #_cclogs
    _cclogs[n+1]=tostring(n+1)..":<"..os.date()..">:"..string.format(...)
end

function reloadModule(moduleName)
    package.loaded[moduleName] = nil

    return require(moduleName)
end

function cclogSave()
    local n=#_cclogs
    --log文件保存的位置，是针对android平台
    local f=io.open("/mnt/sdcard/cocos2dx_log.txt","w+")
    for i=1,n do
        f:write(_cclogs[i].."\n")
    end
    f:close() 
end