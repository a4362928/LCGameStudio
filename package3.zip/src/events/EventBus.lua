require "debug.lua"

EventBus = class("EventBus")
EventBus.__index = EventBus

EventBus._inst = nil

EventBus.observers = {}

function EventBus.getInst()
    if EventBus._inst == nil then
        EventBus._inst = EventBus.new()
    end
    
    return EventBus._inst
end

function EventBus:ctor()

end

function EventBus:addObserver(target,func,name,sender)
    if self:observerExisted(target,name,sender) then 
        return nil
    end
    
    local observer = {target=target,func=func,name=name,sender=sender}
    
    table.insert(self.observers,#self.observers+1,observer)
    
    return observer
end

function EventBus:removeObserver(target,name)
    for i=1, #self.observers do
        local observer = self.observers[i]
        if observer and observer.target == target and observer.name == name then
            table.remove(self.observers,i)
            break
        end
    end
end

function EventBus:observerExisted(target,name,sender)
    for i=1, #self.observers do
        local observer = self.observers[i]
        if observer and observer.target == target and observer.name == name then
            return true
        end
    end
    
    return false
end

function EventBus:removeAllObservers(target)
    local removes = {}
    for i=1, #self.observers do
        local observer = self.observers[i]
        if observer and observer.target == target then
            --table.remove(self.observers,i)
            table.insert(removes,#removes+1,observer)
        end
    end
    
    while #removes > 0 do
        local observer = removes[1]
        self:removeObserver(observer.target,observer.name)
        table.remove(removes,1)
    end
end

function EventBus:registerEvent(target,name,func,once)
    once = once and once or false
    local observer = self:addObserver(target,func,name,nil)
    observer.once = once
end

function EventBus:unregisterEvent(target,name)
    self:removeObserver(target,name)
end

function EventBus:unregisterEvents(target)
    self:removeAllObservers(target)
end

function EventBus:postEvent(name,data)
    data = data or {}
    
    local removes = {}
    
    for i=1, #self.observers do
        local observer = self.observers[i]
        if observer and observer.name == name then
            local func = observer.func
            local target = observer.target
            func(target,name,data)
            
            if observer.once then
                table.insert(removes,#removes+1,observer)
            end
        end
    end
    
    while #removes > 0 do
        local observer = removes[1]
        self:removeObserver(observer.target,observer.name)
        table.remove(removes,1)
    end
end