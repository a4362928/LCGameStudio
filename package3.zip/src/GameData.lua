GameData = class("GameData")

GameData.curScene = nil
GameData.curLayer = nil
GameData.storeChats = nil
GameData.lastChat = nil