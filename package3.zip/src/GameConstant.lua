GameConstant = class("GameConstant")

GameConstant.SCENE_FADE_TIME = 0.6
GameConstant.SCENE_FADEOUT_TIME = 0.6
GameConstant.SCENE_FADEIN_TIME = 0.6

GameConstant.ALLIN_RATE = 10
GameConstant.CARD_SIZE = cc.size(40,55)
GameConstant.MULTI_OWNER_CARD_SIZE = cc.size(60,83)
GameConstant.SOLO_CARD_SIZE = cc.size(68,94)

GameConstant.LOGIN_AWARDS = {1000,1500,2000,2500,3000}
GameConstant.JACKPOT_NUMS = {"parts/jackpot/shiziditiao.png","parts/jackpot/0.png","parts/jackpot/1.png","parts/jackpot/2.png","parts/jackpot/3.png","parts/jackpot/4.png","parts/jackpot/5.png","parts/jackpot/6.png","parts/jackpot/7.png","parts/jackpot/8.png","parts/jackpot/9.png"}

--座位状态
--无用户,也不可以点击坐下
GameConstant.SEAT_MODE_EMPTY = 1
--显示用户信息
GameConstant.SEAT_MODE_USER = 2
    --可以点击坐下
GameConstant.SEAT_MODE_SEAT = 3

GameConstant.SEAT_POKER_GAP = -10

--桌子状态
--等待
GameConstant.DESK_STATUS_WAIT = 0
--玩牌
GameConstant.DESK_STATUS_PLAYING = 1
--结束
GameConstant.DESK_STATUS_OVER = 4

--用户状态
--在线
GameConstant.USER_STATUS_NORMAL = 0
--正在玩
GameConstant.USER_STATUS_PLAY = 1
--等待
GameConstant.USER_STATUS_WAIT = 2
--准备
GameConstant.USER_STATUS_READY = 3
--旁观
GameConstant.USER_STATUS_LOOK = 4
--加注
GameConstant.USER_STATUS_RAISE = 6
--弃牌
GameConstant.USER_STATUS_FOLD = 7
--游戏中退出
GameConstant.USER_STATUS_QUIT = 1001