require "debug.lua"
require "config.lua"
require "net/LCSocket.lua"
require "events/EventBus.lua"
require "net/NI.lua"

GameConnector = class("GameConnector")

GameConnector.__index = GameConnector
GameConnector._inst = nil

function GameConnector.getInst()
    if GameConnector._inst == nil then
        GameConnector._inst = GameConnector.new()
    end

    return GameConnector._inst
end

function GameConnector:ctor()
    --self.json = require("json")
    
    self.host = Config.Server.ip
    self.port = Config.Server.port
    self.socket = LCSocket.new(self.host,self.port,false)
    self.socket:addEventListener(LCSocket.EVENT_CONNECTED,self,self.onSocketStatus)
    self.socket:addEventListener(LCSocket.EVENT_VERIFYED,self,self.onSocketStatus)
    self.socket:addEventListener(LCSocket.EVENT_CLOSE,self,self.onSocketStatus)
    self.socket:addEventListener(LCSocket.EVENT_ERROR,self,self.onSocketError)
    self.socket:addEventListener(LCSocket.EVENT_CLOSED,self,self.onSocketStatus)
    self.socket:addEventListener(LCSocket.EVENT_CONNECT_FAILURE,self,self.onSocketStatus)
    self.socket:addEventListener(LCSocket.EVENT_DATA,self,self.onSocketData)
end

function GameConnector:onSocketStatus(eventName)
    cclog("GameConnector:onSocketStatus %s",eventName)
    if eventName == LCSocket.EVENT_CONNECTED then
    	--cclog("连接服务器成功...")
        EventBus.getInst():postEvent(NI.ID.CONNECTED_SUCCESS)
    elseif eventName == LCSocket.EVENT_VERIFYED then
        --cclog("验证服务器成功...")
        EventBus.getInst():postEvent(NI.ID.CONNECTED_VERIFY)
    elseif eventName == LCSocket.EVENT_CLOSE then
        --cclog("服务器关闭...")
        EventBus.getInst():postEvent(NI.ID.CONNECTED_CLOSED)
    elseif eventName == LCSocket.EVENT_CLOSED then
        --cclog("服务器关闭...")
        EventBus.getInst():postEvent(NI.ID.CONNECTED_CLOSED)
    elseif eventName == LCSocket.EVENT_CONNECT_FAILURE then
        --cclog("连接服务器失败...")
        EventBus.getInst():postEvent(NI.ID.CONNECTED_FAILED)
    end
end

function GameConnector:onSocketError(eventName,data)
    ccerror("socket异常:%s",data.msg)
    EventBus.getInst():postEvent(NI.ID.CONNECTED_ERROR)
end

function GameConnector:onSocketData(eventName,data)
    --cclog("GameConnector:onSocketData %s",data)
    --发布消息
    local msg = GameMessage.createRes(data)
    if msg.decoded==true then
        EventBus.getInst():postEvent(msg.rqId,msg)
    end
    
    --异常提示
    if msg.state~=0 then
        local errorid = tostring(math.abs(msg.state))
        local str = "["..msg.state.."] "..MI.ERROR_ID["error"..errorid]
        PopupText.show(str,p)
    end
end

function GameConnector:connect()
    self.host = self.host or "jlb.gunabc.com"
    self.port = self.port or 8215
    
    self.socket:connect(self.host,self.port,false)
end

function GameConnector:send(data)
    if self.socket.isConnected then
        self.socket:send(data)
    else
        cclog("服务器未连接不能发送消息")    
    end
end
