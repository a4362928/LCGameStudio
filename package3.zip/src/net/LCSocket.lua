require "debug.lua"

LCSocket = class("LCSocket")
LCSocket.__index = LCSocket

--事件名
LCSocket.EVENT_DATA = "SOCKET_TCP_DATA"
LCSocket.EVENT_CLOSE = "SOCKET_TCP_CLOSE"
LCSocket.EVENT_CLOSED = "SOCKET_TCP_CLOSED"
LCSocket.EVENT_ERROR = "SOCKET_ERROR"
LCSocket.EVENT_CONNECTED = "SOCKET_TCP_CONNECTED"
LCSocket.EVENT_VERIFYED = "SOCKET_TCP_VERIFYED"
LCSocket.EVENT_CONNECT_FAILURE = "SOCKET_TCP_CONNECT_FAILURE"

--Socket状态
LCSocket.STATUS_CLOSED = "closed"
LCSocket.STATUS_NOT_CONNECTED = "Socket is not connected"
LCSocket.STATUS_ALREADY_CONNECTED = "already connected"
LCSocket.STATUS_ALREADY_IN_PROGRESS = "Operation already in progress"
LCSocket.STATUS_TIMEOUT = "timeout"

--tick时间
LCSocket.socketTickTime = 0.1            -- check socket data interval
LCSocket.socketReconnectTime = 5         -- socket _reconnect try interval
LCSocket.socketTimeout = 3   -- socket failure timeout

--socket
LCSocket.socket = nil
LCSocket.tcp = nil

LCSocket.name = 'LCSocket'
LCSocket.host = nil
LCSocket.port = nil
--Scheduler
LCSocket.tickScheduler = nil            -- timer for data
LCSocket.reconnectScheduler = nil       -- timer for _reconnect
LCSocket.connectTimeTickScheduler = nil -- timer for connect timeout
LCSocket.isRetryConnect = false
LCSocket.isConnected = false
LCSocket.isVerifyed = false
LCSocket.waitConnect = nil

LCSocket.handlers = {}

LCSocket.uncompleteMsg = nil

function LCSocket:ctor(host, port, retryConnectWhenFailure)
    self.socket = require "socket"
    self.host = host
    self.port = port
    self.isRetryConnect = retryConnectWhenFailure
end

function LCSocket:setName(name)
    self.name = name
    return self
end

function LCSocket:setTickTime(time)
    self.socketTickTime = time
    return self
end

function LCSocket:setReconnTime(time)
    self.socketReconnectTime = time
    return self
end

function LCSocket:setConnFailTime(time)
    self.socketTimeout = time
    return self
end

----连接服务器
----@param #string host IP地址
----@param #int port 端口
----@param #boolean retryConnectWhenFailure 是否自动重连
function LCSocket:connect(host, port, retryConnectWhenFailure)
    --cclog("LCSocket:connect %s %d %s",host,port,retryConnectWhenFailure)
    if host then self.host = host end
    if port then self.port = port end
    if retryConnectWhenFailure ~= nil then self.isRetryConnect = retryConnectWhenFailure end
    assert(self.host or self.port, "Host and port are necessary!")
    --printInfo("%s.connect(%s, %d)", self.name, self.host, self.port)
    self.tcp = self.socket.tcp()
    self.tcp:settimeout(0)

    local function checkConnect()
        local succ, status = self.tcp:connect(self.host, self.port)
        local connectSucc = succ == 1 or status == LCSocket.STATUS_ALREADY_CONNECTED
        if connectSucc then
            self:_onConnected()
        end
        return connectSucc
    end

    if not checkConnect() then
        local connectTimeTick = function ()
            if self.isConnected then return end

            self.waitConnect = self.waitConnect or 0
            self.waitConnect = self.waitConnect + self.socketTickTime
            
            --cclog("connectTimeTick: %d",self.waitConnect)
            
            if self.waitConnect >= self.socketTimeout then
                self.waitConnect = nil
                self:close(false)
                self:_onConnectFailure()
            end
            checkConnect()
        end
        
        self.connectTimeTickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(connectTimeTick, self.socketTickTime, false)
    end
end

----private重连
----@param #boolean immediately 是否立即重连
function LCSocket:_reconnect(immediately)
    --cclog("LCSocket:_reconnect")
    if not self.isRetryConnect then return end
    
    if immediately then self:connect() return end
    
    if self.reconnectScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.reconnectScheduler) end
    
    local doReConnect = function ()
        self:connect()
    end
    self.reconnectScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(doReConnect, self.socketReconnectTime,false)
end

----发送
----@param #string data 数据包
function LCSocket:send(data)
    --cclog("LCSocket:send %s",data)
    cclog("send:%s",data)
    assert(self.isConnected, self.name .. " is not connected.")
    self.tcp:send(data)
end

----关闭tcp
function LCSocket:close(dispachEvent)
    if dispachEvent==nil then
        dispachEvent = true
    end
    --cclog("LCSocket:close")
    self.tcp:close()
    
    if self.connectTimeTickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.connectTimeTickScheduler) end
    if self.tickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickScheduler) end
    
    if dispachEvent then
        self:_execEventHandle(LCSocket.EVENT_CLOSE)
    end
end

----断开连接
function LCSocket:disconnect()
    self.isRetryConnect = false
    self.isConnected = false
    self.tcp:shutdown()
    
    self:_execEventHandle(LCSocket.EVENT_CLOSED)
end

----添加侦听器
----@param #string eventName 事件名
----@param #* target 事件目标对象(func self)
----@param #function func 事件响应函数
function LCSocket:addEventListener(eventName,target,func)
    local handler = {name=eventName,target=target,func=func}
    table.insert(self.handlers,#self.handlers+1,handler)
    cclog("LCSocket:addEventListener %s %d",eventName,#self.handlers)
end

----判断是否存在指定名称侦听器
----@param #* target 事件目标对象(func self)
----@param #function func 事件响应函数
function LCSocket:hasEventListener(eventName,func)
    for i=1, #self.handlers do
        local handler = self.handlers[i]
        if handler.name == eventName and handler.func == func then
            return true
        end
    end
    
    return false
end

----移除指定名称侦听器
----@param #* target 事件目标对象(func self)
----@param #function func 事件响应函数
function LCSocket:removeEventListener(eventName,func)
    for i=1, #self.handlers do
        local handler = self.handlers[i]
        if handler.name == eventName and handler.func == func then
            table.remove(self.handlers,i)
            break
        end
    end
    
    cclog("LCSocket:removeEventListener %d",#self.handlers)
end

----移除所有已注册侦听器
function LCSocket:removeAllEventListeners()
    while #self.handlers > 0 do
        table.remove(self.handlers,0)
    end
    
    cclog("LCSocket:removeAllEventListeners %d",#self.handlers)
end

----执行事件响应函数
function LCSocket:_execEventHandle(eventName,...)
    for i=1, #self.handlers do
        local handler = self.handlers[i]
        if handler.name == eventName then
            local func = handler.func
            local target = handler.target
            func(target,eventName,...)
        end
    end
end

----连接成功
function LCSocket:_onConnected()
    --cclog("LCSocket:_onConnected")
    --标识连接成功
    self.isConnected = true
    self:_execEventHandle(LCSocket.EVENT_CONNECTED)
    --停止连接超时检测
    if self.connectTimeTickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.connectTimeTickScheduler) end
    
    local dataTick = function()
        while true do
            -- if use "*l" pattern, some buffer will be discarded, why?
            local __body, __status, __partial = self.tcp:receive("*a")  -- read the package body
            
            --[[cclog("%s",__status)
            if __status~=nil and __status~="timeout" then
                cclog("!!!")
            end]]
            --print("body:", __body, "__status:", __status, "__partial:", __partial)
            if __status == LCSocket.STATUS_CLOSED or __status == LCSocket.STATUS_NOT_CONNECTED then
                self:close(false)
                if self.isConnected then
                    self:_onDisconnect()
                else
                    self:_onConnectFailure()
                end
                return
            end
            
            if  (__body and string.len(__body) == 0) or (__partial and string.len(__partial) == 0) then 
                return
            end
            
            if __body == nil then __body = "" end
            if __body or __partial then __body = __body .. __partial end
            
            local startIndex,endIndex = string.find(__body,"</cross(.-)domain(.-)policy>")
            
            if startIndex or endIndex then
                self.isVerifyed = true
                self:_execEventHandle(LCSocket.EVENT_VERIFYED,self.isVerifyed)
            else
                self:handle(__body)
            end
        end
    end

    --开始接收数据
    self.tickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(dataTick, self.socketTickTime, false)
    
    --发送服务器验证  非必需
    self:send("GET / HTTP/1.1\r\nHost: "..self.host..":"..self.port.."\r\n\r\n")
end

function LCSocket:dataSplice(data,sep)
    local datas = {}
    local startIndex = 0
    local endIndex = 0
    endIndex = string.find(data,sep)
    endIndex = endIndex or 0
    if endIndex == 0 then
        table.insert(datas,#datas+1,data)
        return datas
    end
    
    while endIndex and endIndex > 0 do
        if (endIndex-1) < (startIndex+1) then
            break
        end
        local d = string.sub(data,startIndex+1,endIndex-1)
        if d and d ~= "" then
            table.insert(datas,#datas+1,d)
        end
        startIndex = endIndex
        if endIndex >= #data then
            break
        else
            endIndex = string.find(data,sep,startIndex+1)
            if not endIndex then
                endIndex = #data+1
            end
        end
    end
    
    if #datas > 1 then
        cclog("粘包：%d",#datas)
    end
    
    return datas
end

function LCSocket:handle(data)
    local datas = self:dataSplice(data,"\n")
    
    for i=1, #datas do
        self:distribute(datas[i])
    end
end

function LCSocket:distribute(data)
    local s = string.sub(data,1,1)
    local bStart = false
    local bEnd = false
    if s == "[" then
        bStart = true
    end
    s = string.sub(data,string.len(data),string.len(data)) 
    if s == "]" then
        bEnd = true
    end
    
    if not bStart and bEnd then
        if self.uncompleteMsg then
            data = self.uncompleteMsg..data
            self.uncompleteMsg = nil
            bStart = true
        else
            --self:_execEventHandle(LCSocket.EVENT_ERROR,{msg=("不完整消息1："..data),data=data,errorid=10001})
        end
    end
    
    if bStart and not bEnd then
        if not self.uncompleteMsg then
            self.uncompleteMsg = data
        else
            --self:_execEventHandle(LCSocket.EVENT_ERROR,{msg=("不完整消息2："..data),data=data,errorid=10001})
        end
    end
    
    if bStart and bEnd then
        cclog("receive:%s",data)
        --ccerror("处理消息：%s",data)
        self:_execEventHandle(LCSocket.EVENT_DATA,data)
    end
end

----连接失败
function LCSocket:_onConnectFailure(status)
    --cclog("LCSocket:_onConnectFailure")
    self:_execEventHandle(LCSocket.EVENT_CONNECT_FAILURE)
    self:_reconnect();
end

----断开连接
function LCSocket:_onDisconnect()
    --cclog("LCSocket:_onDisconnect")
    self.isConnected = false
    self:_execEventHandle(LCSocket.EVENT_CLOSED)
    self:_reconnect()
end