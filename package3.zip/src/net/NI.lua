NI = NI or {}

NI.ID = 
{
    --
    APP_STARTUP = "app_startup",
    ENTER_GAME = "enter_game",
	--已成功登录
	USER_LOGINED = "logined",
	--记录
	RESOURCES_CONFIG_GETED = "getSystemConfigsed",
	--连接状态
	CONNECTED_VERIFY = "connect_verify",
	CONNECTED_SUCCESS = "connect_success",
	CONNECTED_FAILED = "connect_failed",
	CONNECTED_CLOSED = "connect_closed",
    CONNECTED_ERROR = "connect_error",
	--准备完成，进入游戏
	READYED = "readyed",
	--扑克牌
	CARD_OWNER_DEAL_COMPLETE = "CARD_OWNER_DEAL_COMPLETE",
    CARD_SEAT_DEAL_COMPLETE = "CARD_SEAT_DEAL_COMPLETE",
    CARD_TRY_FLIP = "CARD_TRY_FLIP",
	--扑克牌组
	DECK_FLIP_START = "deck_flip_start",
	DECK_FLIP_MIDDLE = "deck_flip_middle",
	DECK_FLIP_COMPLETE = "deck_flip_complete",
	DECK_CLICKTALE_MIDDLE = "deck_clicktale_middle",
	DECK_CLICKTALE_COMPLETE = "deck_clicktale_complete",

	--计时器事件
	INNOCLOCK_TIMER = "innoclock_timer",
	INNOCLOCK_SHORT_WARN = "innoclock_short_warn",
	INNOCLOCK_COMPLETE = "innoclock_complete",
	
	--结算动画事件
    CASH_COMPLETE = "cash_complete",

	--用户状态改变
	USER_STATUS_CHANGE = "user_status_change",

	--导航按钮点击
	MALL_CLICK = "mall_click",

	--购买道具
	MALL_BUY_ITEM = "mall_buy_item",

	--聊天更新
	CHAT_UPDATE = "chat_update",

	--用户道具更新
	USER_ITEM_UPDATE = "user_item_update",
	BAG_ITEM_CLICK = "bag_item_click",

	--排行数据更新
	RANKING_DATA_UPDATE = "ranking_data_update",
	
	--系统广播更新
	BROAD_CAST_UPDATE = "broadcast_update",
	
	--救助金
    JIU_UPDATE = "jiu_update",
	
	--邮件更新
    USER_MAIL_UPDATE = "user_mail_update",
    USER_MAIL_NUMS_UPDATE = "user_mail_nums_update",

	--用户数据更新
	USER_UPDATE = "user_update",

	USER_GOLD_UPDATE = "user_gold_update"
}