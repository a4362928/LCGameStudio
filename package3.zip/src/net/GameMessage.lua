require "debug.lua"

GameMessage = class("GameMessage")
GameMessage.__index = GameMessage

GameMessage.json = require("json")
GameMessage.stepMIs = {"achieveService.getUserAchieves","mailService.getMailByType","rankService.getRankByType"}

--GameMessage.rqId = nil
--GameMessage.params = nil

--GameMessage.state = -1
--GameMessage.result = {}

--GameMessage.isCommand = false

--创建请求消息
function GameMessage.createReq(rqId,params)
    params = params or {}
    local msg = GameMessage.new()
    msg.rqId = rqId
    msg.params = params
    return msg
end

--创建响应消息
function GameMessage.createRes(msgStr)
    local msg = GameMessage.new(msgStr)
    return msg
end

function GameMessage:ctor(msgStr)
    self.decoded = false
    
    if msgStr~=nil then
        --单条消息过长时
        if #msgStr>1500 then
            local startIndex = string.find(msgStr,"\"",1)
            local endIndex = string.find(msgStr,"\"",startIndex+1)
            --id
            self.rqId = string.sub(msgStr,startIndex+1,endIndex-1)

            if self:needSteps(self.rqId)==true then
                startIndex = string.find(msgStr,",",endIndex+2)
                endIndex = #msgStr-1
                local resultStr = string.sub(msgStr,startIndex+1,endIndex)
                local cutStr = string.sub(msgStr,1,startIndex+1)
                cutStr = cutStr..string.sub(msgStr,endIndex,endIndex+1)
                --解析挖空结果的消息
                self:parse(cutStr)
                --分时解析结果
                self:steps(resultStr)
                --self:steps1(resultStr)
                return
            end
        end
        
        --直接解析
        self:parse(msgStr)
        self.decoded = true
    end
end

function GameMessage:parse(str)
    local msgObj = self.json.decode(str)

    self.rqId = msgObj[1]
    self.state = 0
    
    local cindex = string.find(self.rqId,"Command")
    if cindex then
        self.isCommand = true
    end

    if not self.isCommand then
        self.state = msgObj[2]
        if #msgObj >= 3 then
            self.result = msgObj[3]
        end
    else
        self.result = {}
        for i=2, #msgObj do
            table.insert(self.result,#self.result+1,msgObj[i])
        end
    end
end

function GameMessage:needSteps(rqId)
    for i=1, #self.stepMIs do
    	if self.stepMIs[i]==rqId then
    	   return  true
    	end
    end
    return false
end

function GameMessage:steps1(resultStr)
    local tick = function()
        if self.tickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickScheduler) end
        
        self.result = self.json.decode(resultStr)
        --发送自身
        EventBus.getInst():postEvent(self.rqId,self)
    end

    self.tickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false)
end

function GameMessage:steps(resultStr)
    cclog("分时解析->%s",self.rqId)
    local startIndex = string.find(resultStr,"{")
    local endIndex = 0
    
    local arrIndex = 1
    while true do
        local i = string.find(resultStr,",")
        if i<arrIndex then
            arrIndex = arrIndex+1
        else
            break
        end
    end
    
    local treeIndex = startIndex-2
    
    local objStrs = {}
    local si = string.find(resultStr,"{",endIndex)
    local ei = 0
    while true do
        startIndex = string.find(resultStr,"{",endIndex)
        if startIndex==nil or startIndex<1 then
            break
        end
        endIndex = string.find(resultStr,"}",startIndex)
        ei = endIndex
        local obj = string.sub(resultStr,startIndex,endIndex)
        table.insert(objStrs,#objStrs+1,obj)
    end
    
    local tmp = string.sub(resultStr,1,si-1)
    tmp = tmp..string.sub(resultStr,ei+1,#resultStr)
    self.result = self.json.decode(tmp)
    
    local objs = {}
    local tick = function()
        if #objStrs<1 then
            cclog("解析完成->%s",self.rqId)
            if self.tickScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickScheduler) end
            self.decoded = true
            if treeIndex==0 then
                self.result = objs
            elseif treeIndex==1 then
                self.result[arrIndex] = objs
            end
            --发送自身
            EventBus.getInst():postEvent(self.rqId,self)
            return
        end
        local count = 0
        while count<2 and #objStrs>0 do
            local str = objStrs[1]
            local obj = self.json.decode(str)
            table.insert(objs,#objs+1,obj)
            table.remove(objStrs,1)
            count = count+1
        end
        --cclog("step %d %s",stepIndex,str)
    end
    
    self.tickScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false)
end

--参数时候数值
function GameMessage:isParamInt(p)
    local num = tonumber(p)
    if num ~= nil then
        return true
    end
    return false
end

--参数是否布尔值
function GameMessage:isParamBoolean(p)
    if p==true or p==false then
        return true
    end
    return false
end

--字符串化消息
function GameMessage:toString()
    --"['userService.login','lzp13111','guyu','mainweb']\n"
    --"['userService.login','lzp13111','guyu','mainweb',null,null,null,null]\n"
    local paramStr = ""
    for i=1, #self.params do
        local p = self.params[i]
        if self:isParamBoolean(p) then
            if p==true then
                paramStr = paramStr..",true"
            else
                paramStr = paramStr..",false"
            end
        elseif not self:isParamInt(p) then 
            paramStr = paramStr..",\""..p.."\"" 
        else
            paramStr = paramStr..","..p
        end
    end
    local str = "[\""..self.rqId.."\""..paramStr.."]"
    str = str.."\n"
    return str
end