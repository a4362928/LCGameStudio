MI = MI or {}

MI.ID = 
{
    --用户登录
	--params (String openId,String openkey)
	--return new Object[] { UserCache, List<RoomInfo> ,List<TableListVO> }
	USER_LOGIN = "userService.login",
	--记录
	USER_RECORD = "userService.record",
	--获取资源
	RESOURCES_CONFIG_GET = "resourceService.getSystemConfigs",
	--[[public static final int type_room = 1;
    public static final int type_achieve = 2;
    public static final int type_property = 3;
    public static final int type_award = 4;
    public static final int type_shop = 5;
    public static final int type_activity = 6;]]
    RESOURCES_CONFIG_GET_BY_TYPE = "resourceService.getSystemConfigByType",
	--指引奖励
	GUIDE_GET_AWARD = "awardService.receiveGuideAward",
	
	--单人模式 
	--单人发牌
	SOLO_DEAL = "gameService.startSingle",
	--单人弃牌
	SOLO_FOLD = "gameService.foldSingle",
	--单人加注
	SOLO_RAISE = "gameService.betSingle",
    --弃牌
    SOLO_OPEN = "gameService.lookSingle",
	
	--多人大厅
	--获取桌子列表/刷新桌子列表
	DESK_LIST_GET = "roomService.getTableList",
	--进入桌子
	DESK_INTO = "tableService.intoTable",
	--离开桌子
	DESK_OUT = "tableService.outTable",
	--快速进入桌子
	DESK_FAST_INTO = "roomService.fastIntoTable",
	--桌子玩家列表
	DESK_USERS_GET = "tableService.getTableUserList",
	--玩家进入桌子
	C_DESK_INTO = "Command.intoTable",
	--玩家离开桌子
	C_DESK_OUT = "Command.outTable",
	
	--多人模式
	--站起
	MULIT_STANDUP = "tableService.standUp",
	--坐下
	MULIT_SITDOWN = "tableService.siteDown",
	--点击开始
	MULIT_READY = "tableService.ready",
	--取消激活彩金
	MULIT_JACKPOT = "tableService.lottery",
	--加注
	MULIT_RAISE = "gameService.bet",
	--庄家加倍
    MULIT_HOST_RAISE = "gameService.hostBet",
	--弃牌
    MULIT_OPEN = "gameService.look",
	--闲家看牌
    MULIT_FOLD = "gameService.fold",
	--下注
	C_MULIT_RAISE = "Command.bet",
    --庄家加倍
    C_MULIT_HOST_RAISE = "Command.hostBet",
	--弃牌
	C_MULIT_FOLD = "Command.fold",
	--闲家看牌
    C_MULIT_OPEN = "Command.look",
	--开始-坐下
	C_MULIT_START = "Command.start",
	--开始-旁观
	C_MULIT_START_LOOK = "Command.startLook",
	--准备
	C_MULIT_READY = "Command.ready",
	--站起
	C_MULIT_STANDUP = "Command.standUp",
	--计时取消
	C_START_TIMER_RESET = "Command.enforceTime",
	--游戏结束
	C_MULIT_OVER = "Command.gameOver",
	
	--好友
	--获取玩家好友列表
	FRIENDS_QQ_GET = "userService.getQQFriends",
	--获取玩家玩友列表
	FRIENDS_PLAY_GET = "userService.getPuFriends",
	--获取扑得快同城列表
	FRIENDS_CITY_GET = "userService.getCityFriends",
	--获取用户信息
	USER_INFO_GET = "userService.getUserDetailInfo",

	--邮件
	--获取邮件列表
    MAILS_GET = "mailService.getMailByType",
	--获取发件箱邮件列表
	MAILS_SEND_GET = "mailService.getSentMails",
	--阅读邮件
	MAIL_READ = "mailService.readMail",
	--删除邮件
	MAILS_DELETE = "mailService.deleteMails",
	--删除发件箱邮件
	MAILS_SEND_DELETE = "mailService.deleteSentMails",
	--发送邮件
	MAIL_SEND = "mailService.sendMail",
	--标记邮件为已读
	MAILS_MARK = "mailService.markMails",
	--领取单个邮件附件
	MAIL_ATTACH_GET = "mailService.getPackage",
	
	--商城
	MALL_HOT_LIST_GET = "propertyService.getHotSellPropertys",
	MALL_ITEM_BUY = "propertyService.buy",
	--获取库存
	MALL_STOCK_GET = "propertyService.getPropsStock",
	
	--背包
	BAG_LIST_GET = "propertyService.getUserPropertys",
	BAG_ITEM_USE = "propertyService.useProperty",
	BAG_ITEM_DISPOSE = "propertyService.throwPropertys",
	
	--排行榜
	--1 牌型 2-下注 3-财富
	RANKING_REAL_GET = "rankService.getRankByType",
	RANKING_WEEK_GET = "rankService.getLastRank",
	RANKING_GOLD_AWARD_GET = "awardService.receiveGoldRankAward",
	RANKING_BET_AWARD_GET = "awardService.receiveBetRankAward",
	
	--个人彩金信息
	JACKPOT_INFO_GET = "achieveService.getUserMaxCardInfo",
	
	--成就
	--获得成就列表
	ACH_INFO_GET = "achieveService.getUserAchieves",
	--设置称号
	ACH_RANK_SET = "achieveService.setTitle",
	--获得成就
	ACH_GET = "Command.getAchieve",
	
	--领取补助金
	GRANTS_GET = "awardService.receiveGrants",
	
	--签到
	REPORT_DRAW = "awardService.sign",
	REPORT_ADD = "awardService.fillSign",
	
	--连续登录
	LOGINS_GET = "awardService.receiveLoginAward",
	
	--用户活动
    ACTIVITY_GET  = "activityService.getActivitys",
    ACTIVITY_AWARD_GET  = "activityService.receiveActivityAward",
	
	--用户状态
	BUFFERS_GET = "propertyService.getUserBuffers",
	
	--弹出通知
	C_NOTICE_GET = "Command.sysNotice",
	
	--聊天
	--私聊 (String nickName,String msg)
	CHAT_TO_USER = "charService.charToOne",
	--对房间内说话 (String nickName,String msg)
	CHAT_TO_DESK = "charService.charToTable",
	--世界聊天 (String nickName,String msg)
	CHAT_TO_WORLD = "charService.charToWorld",
	--私聊 (String nickName,String msg)
	C_CHAT_TO_USER = "Command.charToOne",
	--对房间内说话 (String nickName,String msg)
	C_CHAT_TO_DESK = "Command.charToTable",
	--世界聊天 (String nickName,String msg)
	C_CHAT_TO_WORLD = "Command.charToWorld",
	--系统广播
	C_BROAD_CAST = "Command.systemBroadcast",
	
	--黄钻特权
	YVIP_NEW_GET = "awardService.receiveVipNewAwards",
	YVIP_DAILY_GET = "awardService.receiveVipDayAwards",
	
	--cdkey
	CDKEY_USE = "propertyService.useSecret",
	
	--领取新年消费活动奖励
	CONSUME_AWARD_GET = "activityService.receiveReChargeActivityAward",
	
	
	--任务
	--开始新手任务
	START_TASK_2 = "activityService.startNoviceTask",
	--连续玩牌
	C_TASK_1 = "Command.continuousPlayNum",
	--新手
	C_TASK_2 = "Command.novicePlayNum",
	--每晚玩牌
	C_TASK_3 = "Command.dailyPlayNum",
	
	--数据同步
	--用户信息同步
	SYNC_USER = "Command.syncUser",
	--用户信息同步
	SYNC_USER_EXTRA = "Command.syncUserInfo",
	--用户道具同步
	SYNC_ITEM = "Command.syncUserProperty",
	--用户邮件同步
	SYNC_MAIL = "Command.syncMail",
	--用户邮件同步
	SYNC_RANK = "Command.syncTitle",
	--用户等级同步
	SYNC_LEVEL = "Command.syncLevel",
	--彩金信息同步
	SYNC_JACKPOT = "Command.syncPot",
}

MI.ERROR_ID = {
    error1 = "系统异常",
    error2 = "请求超时",
    error3 = "拒绝请求",
    error4 = "没有这个接口",
    error5 = "还没有进入桌子",
    error6 = "没有坐下",
    error7 = "已经在桌子里面",
    error8 = "数据异常",
    error9 = "客户端未验证数据",
    error11 = "IO异常",
    error13 = "不在同一个服务器",
    error19 = "不是你的回合，无法操作",
    error22 = "已经准备了",
    error23 = "已经进入扑的阶段无法操作",
    error26 = "用户手上的牌异常",
    error27 = "已经扑过了",
    error100 = "系统已关闭",
    
    error0 = "",
    
    error1000 = "本商品不出售",
    error1001 = "没有这个桌子",
    error1002 = "游戏币不足",
    error1003 = "牌局已经开始了",
    error1004 = "还未准备",
    error1005 = "邮件不存在",
    error1006 = "邮件已经读过了",
    error1007 = "没有该道具",
    error1008 = "道具已经用完了",
    error1009 = "该道具不可使用",
    error1010 = "道具的效果还未消失，不可重复使用",
    error1011 = "今天已经领取过了奖励",
    error1012 = "不是黄钻",
    error1013 = "不是年费黄钻",
    error1014 = "发表说说次数达到上限",
    error1015 = "用户不存在",
    error1016 = "用户不在线",
    error1017 = "交换规则错误",
    error1018 = "无法获取平台数据",
    error1019 = "座位上没人",
    error1020 = "这张头像已经使用过了",
    error1021 = "这张牌已经被占用了",
    error1022 = "头像不存在",
    error1023 = "谷雨币不足",
    error1024 = "用户已经准备了",
    error1025 = "还没有进入桌子",
    error1026 = "对方和你不在同一张桌子上",
    error1027 = "分享次数达到上限",
    error1028 = "已经在座位上了",
    error1029 = "座位上已满",
    error1030 = "对方和你在同一张桌子里面",
    error1031 = "腾讯错误码：账户余额不足",
    error1032 = "腾讯错误码：账户被冻结",
    error1033 = "腾讯服务器繁忙",
    error1034 = "不能邀请自己",
    error1035 = "对方金币不足无法进入",
    error1036 = "对方正在游戏中",
    error1037 = "该头像已经参选了",
    error1038 = "该榜的票数已用完",
    error1039 = "该头像没有参选本届排行",
    error1040 = "不是蓝钻",
    error1041 = "同IP的不能进入同张桌子内",
    error1042 = "下注类型不存在",
    error1043 = "不在pve场",
    error1044 = "已经在pve场",
    error1045 = "重复加注",
    error1046 = "加倍范围错误",
    error1047 = "今天的签到奖励已经领取了,或者错过了签到时间",
    error1048 = "无法补签",
    error1049 = "没有上排行榜",
    error1050 = "抽奖次数已经用完",
    error1051 = "牌局还未开始",
    error1052 = "发送附件邮费不足",
    error1053 = "今日发送钱币数量达到上限",
    error1054 = "附件不为空不能删除",
    error1055 = "没有附件",
    error1056 = "信件内容过长",
    error1057 = "这个座位上已经有人了",
    error1058 = "领取补助金的次数用完",
    error1059 = "领取补助金的条件不足",
    error1060 = "该道具不可丢弃 ",
    error1061 = "邀请奖励领取达到上限",
    error1062 = "邀请奖励领取条件未达到",
    error1063 = "低级效果道具无法覆盖高级效果道具",
    error1064 = "没有可领取的奖励",
    error1065 = "血战券不足",
    error1066 = "成就未完成",
    error1067 = "该成就没有头衔",
    error1068 = "已经拥有该头衔",
    error1069 = "CD-KEY已经被领取",
    error1070 = "CD-KEY不存在",
    error1071 = "实物道具无法在这里兑换",
    error1072 = "客户端上传内容过长",
    error1073 = "等级不足,无法进入",
    error1074 = "缺少血战钥匙",
    
    error6001 = "没有库存",
    
    error7001 = "还在游戏中，不能进入任何房间。需要等待回合结束",
    
    error8401 = "任务已经开始了",
    error8402 = "任务已经完成了",
    
    error8101 = "活动要求没达到",
    error8102 = "奖励已经被领取",
    error8103 = "活动时间未到或已经结束",
    
    error9001 = "订单号已经被使用了",
    error9002 = "充值购买的道具不存在",
    error9003 = "充值购买数量不正确",
    error9004 = "充值金额不正确",
    error9005 = "充值用户不存在"
}