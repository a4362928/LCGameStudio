require "debug.lua"
require "net/GameConnector.lua"
require "net/GameMessage.lua"

GameMessageService = class("GameMessageService")

GameMessageService.__index = GameMessageService
GameMessageService._inst = nil

function GameMessageService.getInst()
    if GameMessageService._inst == nil then
        GameMessageService._inst = GameMessageService.new()
    end

    return GameMessageService._inst
end

function GameMessageService:ctor()
    
end

function GameMessageService:init()
    cclog("GameMessageService:init")
end

----向服务器发送请求消息
----@param #MI.ID rqId 消息ID
----@param #table params 参数数组
function GameMessageService.req(rqId,params)
    local msg = GameMessage.createReq(rqId,params)
    GameConnector.getInst():send(msg:toString())
end