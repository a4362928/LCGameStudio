require "Cocos2d"

-- cclog
local cclog = function(...)
    print(string.format(...))
end

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
    return msg
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    
    cc.FileUtils:getInstance():addSearchPath("src")
    cc.FileUtils:getInstance():addSearchPath("res")
    cc.FileUtils:getInstance():addSearchPath("res/hd")
    --cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(760, 590, 1)--fixed_height=3,fixed_width=4
    cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(960, 640, 3)

    require "fz.lua"
    --start service
    GameMessageService.getInst():init()
    CommandController.getInst():init()
    
    EventBus.getInst():postEvent(NI.ID.APP_STARTUP,{})

    --create scene 
    if Config.ServerInput then
        --进入输入界面
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(cc.TransitionFade:create(1,TestLogin.create()))
        else
            cc.Director:getInstance():runWithScene(cc.TransitionFade:create(1,TestLogin.create()))
        end
    else
        --进入游戏
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(cc.TransitionFade:create(1.0,Splash.create()))
        else
            cc.Director:getInstance():runWithScene(cc.TransitionFade:create(1.0,Splash.create()))
        end
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
