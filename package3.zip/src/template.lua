require "debug.lua"
require "config.lua"
require "base/LCLayer.lua"
require "base/LCScene.lua"

Template = class("Template",function()
    return LCLayer.create()
end)

Template.__index = Template

function Template.create()
    --cclog("Template:create")
    local scene = LCScene.create()
    local layer = Template.new()
    scene:addChild(layer)
    return scene
end

function Template:ctor()
    --cclog("Template:ctor()")
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end

    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end
    
    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)
    
    local function onKeyReleased(touch,event)
        return self:onKeyReleased(touch,event)
    end
    
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)
    
    self:setupViews()
end

function Template:setupViews()
    --cclog("Template:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/emplate/emplate.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)
    
    --self.btn = self.widget:getChildByName("btn")
    
    --local function btnCallback(sender, eventType)
        --if eventType == ccui.TouchEventType.ended then
            --if sender == self.btn then
                --self:onBtnClick(sender)
            --end
        --end
    --end
    
    --self.btn:addTouchEventListener(btnCallback)
end

function Template:onEnter()
    --cclog("Template:onEnter")
    --self:_onEnter()
end

function Template:onEnterTransitionDidFinish()
    --cclog("Template:onEnterTransitionDidFinish")
    --self:_onEnterTransitionDidFinish()
end

function Template:onExitTransitionDidStart()
    --cclog("Template:onExitTransitionDidStart")
    --self:_onExitTransitionDidStart()
end

function Template:onExit()
    --cclog("Template:onExit")
    --self:_onExit()
end

function Template:cleanup()
    --cclog("Template:cleanup")
    --self:_cleanup()
end

function Template:onTouchBegan(touch,event)
--cclog("Template:onTouchBegan")
end

function Template:onTouchMoved(touch,event)
--cclog("Template:onTouchMoved")
end

function Template:onTouchEnded(touch,event)
--cclog("Template:onTouchEnded")
end

function Template:onTouchCancelled(touch,event)
--cclog("Template:onTouchEnded")
end

function Template:onKeyReleased(keyCode, event)
--cclog("Template:onKeyReleased")
end