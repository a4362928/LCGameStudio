UserModel = class("UserModel")

UserModel.__index = UserModel
UserModel._inst = nil

UserModel.uid = nil
UserModel.siteId = nil
UserModel.tableId = nil
UserModel.serverId = nil
UserModel.status = nil
UserModel.user = nil
UserModel.ui = nil
UserModel.puStatus = nil
UserModel.openKey = nil
UserModel.pf = nil
UserModel.userip = nil
UserModel.level = nil
UserModel.pfVO = nil
UserModel.firstLogin = nil
UserModel.newDay = nil
UserModel.think = nil
UserModel.pfKey = nil
UserModel.round = nil
UserModel.invNum = nil

function UserModel.getInst()
    if UserModel._inst == nil then
        UserModel._inst = UserModel.new()
    end

    return UserModel._inst
end

function UserModel:ctor()

end

function UserModel:read(loginData)
    local obj = loginData
    
    self.uid = obj.uid
    self.firstLogin = obj.firstLogin
    self.newDay = obj.newDay
    self.openKey = obj.openKey
    self.pf = obj.pf
    self.serverId = obj.serverId
    self.siteId = obj.siteId
    self.status = obj.status
    self.tableId = obj.tableId
    
    self.level = obj.level
    if self.level==nil then
        self.level = {}
    end
    
    self.ubs = obj.ubs
    if self.ubs==nil then
        self.ubs = {}
    end
    
    self.user = obj.user
    if self.user==nil then
        self.user = {}
    end
    
    self.userInfo = obj.userInfo
    if self.userInfo==nil then
        self.userInfo = {}
    end
    
    EventBus.getInst():postEvent(NI.ID.USER_UPDATE,{})
end

function UserModel:readSync(msg)
    local obj = msg.result[1]
    --cclog("UserModel:readSync->%d",obj.gold)
    self.user.score = obj.score
    self.user.gold = obj.gold
    self.user.bang = obj.bang
    
    EventBus.getInst():postEvent(NI.ID.USER_UPDATE,{})
end

function UserModel:getAllinBet(base)
    local yu = self.user.gold - base
    local allin = GameConstant.ALLIN_RATE * base
    
    return math.min(yu,all)
end

function UserModel:getStatus()
    return self.status
end

function UserModel:setStatus(status)
    local ostatus = self.status
    self.status = tonumber(status)
    
    local data = {oldStatus=ostatus,newStatus=self.status}
    EventBus.getInst():postEvent(NI.ID.USER_STATUS_CHANGE,data)
end