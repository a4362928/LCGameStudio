StorageModel = class("StorageModel")

StorageModel.__index = StorageModel

StorageModel.EFFECT_VOLUME = "effect_volume"
StorageModel.MUSIC_VOLUME = "music_volume"
StorageModel.USER_OPENID = "user_openid"
StorageModel.APP_VERSION = "app_version"

StorageModel._inst = nil

StorageModel.effectVolume = 50
StorageModel.musicVolume = 50
StorageModel.version = "1.0.0"

function StorageModel.getInst()
    if StorageModel._inst == nil then
        StorageModel._inst = StorageModel.new()
    end

    return StorageModel._inst
end

function StorageModel:ctor()
    self.userDefault = cc.UserDefault:getInstance()
    
    self.effectVolume = self.userDefault:getIntegerForKey(StorageModel.EFFECT_VOLUME,50)
    self.musicVolume = self.userDefault:getIntegerForKey(StorageModel.MUSIC_VOLUME,50)
    
    --初次进入游戏时保存版本号
    local version = self:getVersion()
    if version==nil then
        self:setVersion(Config.version)
    end
end

function StorageModel:getEffectVolume()
    return self.effectVolume
end

function StorageModel:setEffectVolume(value,flush)
    if flush==nil then flush = false end
    self.effectVolume = value
    if flush==true then 
        self.userDefault:setIntegerForKey(StorageModel.EFFECT_VOLUME,value)
        self.userDefault:flush() 
    end
end

function StorageModel:getMusicVolume()
    return self.musicVolume
end

function StorageModel:setMusicVolume(value,flush)
    if flush==nil then flush = false end
    self.musicVolume = value
    
    if flush==true then 
        self.userDefault:setIntegerForKey(StorageModel.MUSIC_VOLUME,value)
        self.userDefault:flush() 
    end
end

function StorageModel:getOpenId()
    self.openId = self.userDefault:getStringForKey(StorageModel.USER_OPENID,"")
    local newCreate = false
    if self.openId==nil or self.openId=="" or #self.openId<1 then
        self.openId = self:createOpenId()
        self.userDefault:setStringForKey(StorageModel.USER_OPENID,self.openId)
        self.userDefault:flush()
        newCreate = true
    end 
    return self.openId,newCreate
end

function StorageModel:createOpenId()
    local curTime = os.time()
    local rand = math.random(1,99999999)
    local id = curTime+rand
    local openid = "fz"..id
    openid = string.sub(openid,1,#openid-1)
    return openid
end

function StorageModel:getVersion()
    local v = self.userDefault:getStringForKey(StorageModel.APP_VERSION,"")
    if v==nil or v=="" or #v<1 then
        return nil
    end
    return v
end

function StorageModel:setVersion(v)
    self.version = v
    self.userDefault:setStringForKey(StorageModel.APP_VERSION,v)
    self.userDefault:flush() 
end

function StorageModel:isNewVersion(v)
    local o = self:getVersion()
    local narr = StringUtils.split(v,"%.")
    local oarr = StringUtils.split(o,"%.")
    
    local min = math.min(#narr,#oarr)
    
    for i=1, min do
        local n1 = tonumber(narr[i])
        local o1 = tonumber(oarr[i])
        if n1>o1 then
            return true
        end
    end
    
    if #narr>#oarr then
        return true
    end
    
    return false
end