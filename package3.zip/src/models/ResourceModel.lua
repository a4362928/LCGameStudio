require "debug.lua"

ResourceModel = class("ResourceModel")

ResourceModel.__index = ResourceModel
ResourceModel._inst = nil

ResourceModel.achList = {}
ResourceModel.activityList = {}
ResourceModel.areaList = {}
ResourceModel.propetyList = {}
ResourceModel.rankList = {}
ResourceModel.mallList = {}
ResourceModel.eventList = {}

function ResourceModel.getInst()
    if ResourceModel._inst == nil then
        ResourceModel._inst = ResourceModel.new()
    end

    return ResourceModel._inst
end

function ResourceModel:ctor()

end

function ResourceModel:read(data)

end

function ResourceModel:setAchieves(obj)
    self.achList = obj or {}

    cclog("ResourceModel:setAchieves->%d",#self.achList)
end

function ResourceModel:getAch(id)
    for i=1,#self.achList do
        if self.achList[i].id == id then
            return self.achList[i]
        end
    end

    return nil
end

function ResourceModel:getAchByRank(rank)
    if rank==nil or rank=="" then 
        return nil
    end

    for i=1,#self.achList do
        if self.achList[i].title~=nil and self.achList[i].title == rank then
            return self.achList[i]
        end
    end

    return nil
end

function ResourceModel:getAchList(type)
    local v = {}

    for i=1,#self.achList do
        local ach = self.achList[i]
        if type == -1 then
            table.insert(v,ach)
        else
            if ach.kind == type then
                table.insert(v,ach)
            end
        end
    end

    return v
end

function ResourceModel:getTotalAchPoint()
    local point = 0
    for i=1,#self.achList do
        point = point + self.achList[i].source
    end

    return point
end

function ResourceModel:setMalls(obj)
    self.mallList = obj or {}

    cclog("ResourceModel:setMalls->%d",#self.mallList)
end

function ResourceModel:setEvents(obj)
    self.eventList = obj or {}

    cclog("ResourceModel:setEvents->%d",#self.eventList)
end

function ResourceModel:getEventList()
    return self.eventList
end

function ResourceModel:getEvent(id)
    for i=1, #self.eventList do
    	if self.eventList[i].id==id then
            return self.eventList[i]
    	end
    end
    return nil
end

function ResourceModel:setProps(obj)
    self.propetyList = obj or {}

    local ipad3 = {}
    ipad3.pid = 10001
    ipad3.color = 4
    ipad3.name = "ipad三代"
    ipad3.description = "ipad三代，以邮件形式发送兑换码到您的邮箱。"
    table.insert(self.propetyList,ipad3)

    cclog("ResourceModel:setProps->%d",#self.propetyList)
end

function ResourceModel:setRooms(obj)
    self.areaList = obj or {}

    for i=1,#self.areaList do
        local area = self.areaList[i]
        if area~=nil then
            if area.id>1 then
                area.minLevel = 6
                area.maxLevel = 100
            else
                area.minLevel = 0
                area.maxLevel = 5
            end
        end
    end
    cclog("ResourceModel:setRooms->%d",#self.areaList)
end

function ResourceModel:getGold(id)
    --cc.PLATFORM_OS_ANDROID
    local golds = self:getMallList(1)
    if golds then
        for i=1, #golds do
            local vo = golds[i]
            if vo.id==id then
                return vo
            end
        end
    end
    return nil
end

function ResourceModel:getVip(id)
    local vips = self:getMallList(2)
    if vips then
        for i=1, #vips do
            local vo = vips[i]
            if vo.id==id then
                return vo
            end
        end
    end
    return nil
end

function ResourceModel:getMallList(type)
    local plat = cc.Application:getInstance():getTargetPlatform()
    local arr = {}

    if type==1 then
        if plat==cc.PLATFORM_OS_ANDROID then
            arr = self.mallList.golds_android
        elseif plat==cc.PLATFORM_OS_IPHONE or plat==cc.PLATFORM_OS_IPAD then
            arr = self.mallList.golds_ios
        elseif plat==cc.PLATFORM_OS_WINDOWS then
            arr = self.mallList.golds_android
        end
    elseif type==2 then
        arr = self.mallList.vips
    elseif type==3 then
        arr = self.mallList.frees
    end
    
    return arr
end

function ResourceModel:getRank(id)
    for i=1,#self.rankList do
        if rankList[i].id == id then
            return rankList[i]
        end
    end

    return nil
end

function ResourceModel:getPropety(pid)
    --cclog("ResourceModel:getPropety %d",#self.propetyList)
    for i=1,#self.propetyList do
        local prop = self.propetyList[i]
        if prop.pid == pid then
            return prop
        end
    end

    return nil
end

function ResourceModel:getArea(id)
    for i=1,#self.areaList do
        if self.areaList[i].id == id then
            return self.areaList[i]
        end
    end

    --{baseBet=700,enterNum=2300,id=2,name="初级场",serverId=1,sysCost=200,type=2}
    --{baseBet=100,enterNum=300,id=1,name="新手场",serverId=1,sysCost=0,type=1}
    --{baseBet=700,enterNum=2300,id=2,name="初级场",serverId=1,sysCost=200,type=2}
    return nil
end

function ResourceModel:getMallList1(type)
    local v = {}
    cclog("getMallList %d",#self.propetyList)
    for i=1,#self.propetyList do
        local prop = self.propetyList[i]
        if prop.onSell == 1 then
            if type == -1 then
                table.insert(v,prop)
            elseif type == prop.mallType and prop.type ~= 4 then
                -- && propetyList[i].type != 6
                table.insert(v,prop)
            end
        end
    end

    --v.sort(ascFunc);
    return v
end

--等级计算
function ResourceModel:getLevelInfo(exp)
    local curExp = exp
    local needExp = 0
    local totalExp = exp
    local lv = 0
    for i=1, 35 do
        if i<6 then 
            needExp=60+(i-1)*10
        elseif i<20 then 
            needExp=720+(i-6)*80
        elseif i<35 then 
            needExp=3680+(i-20)*160
        end
        
        curExp = curExp-needExp
        if curExp<0 then
            lv = i-1
            curExp = curExp+needExp
            break
        end
    end
    
    return curExp,needExp,totalExp,lv
end

--活动
function ResourceModel:setActivitys(arr)
    self.activityList = arr
end

function ResourceModel:getActivitys()
    return self.activityList
end

function ResourceModel:getActivity(id)
    for i=1, #self.activityList do
        local act = self.activityList[i]
        if act.id==id then
            return act
        end
    end
    return nil
end