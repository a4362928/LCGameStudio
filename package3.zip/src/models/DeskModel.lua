require "views/multi/MultiPlayer.lua"

DeskModel = class("DeskModel")

DeskModel.__index = DeskModel
DeskModel._inst = nil

DeskModel.tid = nil

-- 房间ID
DeskModel.rid = nil
-- 桌子名称
DeskModel.name = nil

-- 桌子编号 */
DeskModel.tableNum = nil

-- 房间内用户状态
DeskModel.users = nil

-- 当前桌子状态。未开始、进行中。。。。
DeskModel.status = nil

-- 限时，倒计时 */
DeskModel.countdown = nil

-- 历史筹码数 */
DeskModel.historyBet = nil

-- 当前局的桌面总筹码 */
DeskModel.sumBet = nil

-- 桌子类型 */
DeskModel.type = nil
-- 开始剩余时间，0表示还未开始倒计时 */
DeskModel.leftStartTime = nil
--庄家
DeskModel.buckPids = 0
DeskModel.buckUid = 0
DeskModel.usedTime = 0
--场信息
DeskModel.area = nil

function DeskModel.getInst()
    if DeskModel._inst == nil then
        DeskModel._inst = DeskModel.new()
    end

    return DeskModel._inst
end

function DeskModel:ctor()

end

function DeskModel:read(obj)
    self.tid = obj.tid
    self.rid = obj.rid
    self.name = obj.name
    self.tableNum = obj.tableNum
    local arr = obj.users
    self.users = {}
    if arr~=nil then
        for i=1,#arr do
            local user = MultiPlayer.create(arr[i])
            table.insert(self.users,user)
        end
    end

    arr = obj.outUsers
    if arr~=nil then
        for i=1,#arr do
            local user = MultiPlayer.create(arr[i])
            user.status = GameConstant.USER_STATUS_QUIT
            table.insert(self.users,user)
            cclog("该桌子有离线玩家:"..user)
        end
    end
    self.status = obj.status
    self.countdown = obj.countdown
    self.historyBet = obj.historyBet
    self.sumBet = obj.sumBet
    self.type = obj.type
    self.leftStartTime = obj.leftStartTime
    self.buckPids = obj.hostCid
    self.buckUid = obj.hostUid
    self.usedTime = obj.usedTime

    self.area = ResourceModel.getInst():getArea(self.rid)
    --cclog("self.area:%s",self.area.name)

    cclog("DeskModel:setDesk:%d",self.tid)
    cclog(self:toUsersString())
end

function DeskModel:hasUser(uid)
    local user = self:getUser(uid)

    return user and true or false
end

function DeskModel:getUser(uid)
    if self.users==nil then
        cclog("用户没有进入桌子!")
        return nil
    end

    for i=1,#self.users do
        local user = self.users[i]
        if user.uid == uid then 
            return user
        end
    end

    return nil
end

function DeskModel:shiftQuitUser()
    if self.users==nil then
        cclog("用户没有进入桌子!")
        return nil
    end

    for i=1,#self.users do
        local user = self.users[i]
        if user.status == GameConstant.USER_STATUS_QUIT then
            table.remove(self.users,i)
            return user
        end
    end

    return nil
end

function DeskModel:addUser(player)
    if self.users==nil then
        cclog("用户没有进入桌子!")
        return -1
    end

    if not self:hasUser(player.uid) then
        if #self.users < 6 then
            table.insert(self.users,player)
        else 
            cclog("座位已经满了")
        end
    else
        local user = self:getUser(player.uid)
        if user.status == GameConstant.USER_STATUS_QUIT then
            user.status = GameConstant.USER_STATUS_WAIT
        else
            cclog("玩家"..user:toString().."重复进入同一个桌子")
        end
    end

    --fillPlayers(resourceModel)

    return #self.users
end

function DeskModel:removeUser(uid)
    if self.users==nil then
        cclog("用户没有进入桌子!")
        return -1
    end

    for i=1,#self.users do
        if self.users[i].uid == uid then
            table.remove(self.users,i)
            break
        end
    end

    return #self.users
end

function DeskModel:setUsersStatus(status,bSetQuit)
    if self.users==nil then
        cclog("用户没有进入桌子!")
        return
    end

    for i=1,#self.users do
        local user = self.users[i]
        self:setUserStatus(user.uid,status,bSetQuit)
    end
end

function DeskModel:setUserStatus(uid,status,bSetQuit)
    local user = self:getUser(uid)
    if user~=nil then
        if bSetQuit then 
            user.status = status
        elseif user.status ~= GameConstant.USER_STATUS_QUIT then
            user.status = status
        end
    end
end

function DeskModel:getUserStatus(uid)
    local user = self:getUser(uid)
    if user~=nil then
        return user.status
    end
    return -1
end

function DeskModel:setBuck(uid,pids)
    self.buckUid = uid
    self.buckPids = pids
end

function DeskModel:getBuck()
    return self.buckUid
end

function DeskModel:isBuck(uid)
    if self.buckUid == uid then
        return true
    end
    return false
end

function DeskModel:getBuckPid()
    return self.buckPids
end

function DeskModel:getBaseChip()
    if self.area~=nil then
        return self.area.baseBet
    else 
        cclog("获取桌子底注异常")
    end

    return 0
end

function DeskModel:getMinChip()
    if self.area~=nil then
        return self.area.enterNum
    else 
        cclog("获取桌子最小注异常")
    end

    return 0
end

function DeskModel:getUsersNum(bContainsQuit)
    if bContainsQuit == nil then bContainsQuit = true end
    local arr = {}
    if self.users~=nil then
        for i=1,#self.users do
            if bContainsQuit then
                table.insert(arr,#arr+1,self.users[i])
            elseif self.users[i].status ~= GameConstant.USER_STATUS_QUIT then
                table.insert(arr,#arr+1,self.users[i])
            end
        end
        return #arr,arr
    end

    return 0,arr
end

function DeskModel:getStatus()
    return self.status
end

function DeskModel:setStatus(status)
    self.status = status
end

function DeskModel:toUsersString()
    local str = "\n↓\n玩家数量:"..(#self.users).."\n"
    for i=1,#self.users do
        str = str.."玩家"..i..":"..self.users[i].nickName
        str = str.."\n"
    end
    str = str.."↑"
    return str
end