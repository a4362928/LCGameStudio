UserDataModel = class("UserDataModel")

UserDataModel.__index = UserDataModel

UserDataModel._inst = nil

UserDataModel.userAchs = nil
UserDataModel.userJackpots = nil
UserDataModel.userMails = {}
UserDataModel.userActs = {}

function UserDataModel.getInst()
    if UserDataModel._inst == nil then
        UserDataModel._inst = UserDataModel.new()
    end

    return UserDataModel._inst
end

function UserDataModel:ctor()

end

--用户成就信息
function UserDataModel:setUserAchs(arr)
    self.userAchs = arr or {}
    
    self.userAchs = arr
end

function UserDataModel:getUserAch(id)
    for i=1, #self.userAchs do
        local ach = self.userAchs[i]
        if ach.achieveId == id then
            return ach
        end
    end
    return nil
end

function UserDataModel:getAchPoints(type)
    local points = 0
    for i=1, #self.userAchs do
        local uach = self.userAchs[i]
        if uach.finished >= 1 then
            local ach = ResourceModel.getInst():getAch(uach.achieveId)
            if ach then
                points = points + ach.source
            end
        end
    end
    return points
end

--用户彩金信息
function UserDataModel:setUserJackpot(obj)
    self.userJackpots = obj
    --self.userJackpots = {pveTotalPot=121341,pveVO={{pot=100,cards={102,103,104,105,106}},{pot=1000,cards={207,208,209,210,211}},{pot=10000,cards={314,313,412,211,110}}},pvpTotalPot=1412312,pvpVO={{pot=300,cards={314,313,412,211,110}}}}
end

function UserDataModel:getUserSoloJackpot()
    if self.userJackpots then
        return self.userJackpots.pveTotalPot,self.userJackpots.pveVO
    end
    return 0,{pot=0,cards={}}
end

function UserDataModel:getUserMultiJackpot()
    if self.userJackpots then
        return self.userJackpots.pvpTotalPot,self.userJackpots.pvpVO
    end
    return 0,{pot=0,cards={}}
end

--用户排行信息
function UserDataModel:getMyRanking(type)
    local arr = GlobalDataModel.getInst():getRankingList(type)
    if arr~=nil then
        local myUid = UserModel.getInst().uid
        for i=1, #arr do
        	if arr[i].uid==myUid then
                return arr[i]
        	end
        end
    end
    return nil
end

--用户邮件信息
function UserDataModel:addUserMails(arr)
    if arr then
        for i=1, #arr do
            local m = arr[i]
            local index = self:getUserMail(m.mailId)
            if index~=nil and index>0 then
                table.remove(self.userMails,index)
                table.insert(self.userMails,index,m)
            else
                table.insert(self.userMails,1,m)
            end
        end
    end
    
    EventBus.getInst():postEvent(NI.ID.USER_MAIL_UPDATE,{})
    EventBus.getInst():postEvent(NI.ID.USER_MAIL_NUMS_UPDATE,{})
end

function UserDataModel:getUserMail(id)
    for i=1, #self.userMails do
        local m = self.userMails[i]
        local mid = m.id
        if mid==nil then mid=m.mailId end
        if mid==id then
            return i
        end
    end
    return 0
end

function UserDataModel:setUserMails(arr)
    self:addUserMails(arr)
end

function UserDataModel:getUserMails(type)
    local arr = {}
    for i=1, #self.userMails do
        local m = self.userMails[i]
        if m.type==type then
            table.insert(arr,#arr+1,m)
        end
    end
    return arr
end

function UserDataModel:getNewMails()
    local arr = {}
    for i=1, #self.userMails do
        local m = self.userMails[i]
        if m.expression~=nil and m.expression~="" then
            table.insert(arr,#arr+1,m)
        end
    end
    return #arr
end

--用户活动信息
function UserDataModel:setUserActs(arr)
    self.userActs = arr
end

function UserDataModel:getUserAct(id)
    for i=1, #self.userActs do
        local act = self.userActs[i]
        if act.id==id then
            return act
        end
    end
    return nil
end
