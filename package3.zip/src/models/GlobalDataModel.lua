require "debug.lua"

GlobalDataModel = class("GlobalDataModel")

GlobalDataModel.__index = GlobalDataModel
GlobalDataModel._inst = nil

GlobalDataModel.jackpot = {}
GlobalDataModel.ranking = {}
GlobalDataModel.broadcasts = {}

function GlobalDataModel.getInst()
    if GlobalDataModel._inst == nil then
        GlobalDataModel._inst = GlobalDataModel.new()
    end

    return GlobalDataModel._inst
end

function GlobalDataModel:ctor()
    local msg = {used=false,content="欢迎进入肥猪加勒比！更多游戏尽在www.fz222.com"}
    table.insert(self.broadcasts,#self.broadcasts+1,msg)
end

--彩金数据
function GlobalDataModel:setJackpot(obj)
    self.jackpot = obj
end

function GlobalDataModel:getSoloJackpot()
    if self.jackpot then
        return self.jackpot.pve
    end
    return 0
end

function GlobalDataModel:getMultiJackpot()
    if self.jackpot then
        return self.jackpot.pvp
    end
    return 0
end

--排行数据
function GlobalDataModel:setRankingList(arr,type)
    self.ranking[tostring(type)] = arr
    
    EventBus.getInst():postEvent(NI.ID.RANKING_DATA_UPDATE,{type})
end

function GlobalDataModel:getRankingList(type)
    local arr = self.ranking[tostring(type)]
    return arr
end

--系统广播
function GlobalDataModel:addBroadcast(obj)
    local msg = {used=false,content=obj}
    table.insert(self.broadcasts,#self.broadcasts+1,msg)
    
    EventBus.getInst():postEvent(NI.ID.BROAD_CAST_UPDATE,msg)
end

function GlobalDataModel:getBroadcastList()
    return self.broadcasts
end

function GlobalDataModel:getUsedBroadcastList()
    local arr = {}
    for i=1, #self.broadcasts do
        local b = self.broadcasts[i]
        if b.used==true then
            table.insert(arr,#arr+1,b)
        end
    end
    return arr
end

function GlobalDataModel:getNextBroadcast()
    for i=1, #self.broadcasts do
        local b = self.broadcasts[i]
        if b.used==false then
            b.used = true
            return b
        end
    end
    return nil
end