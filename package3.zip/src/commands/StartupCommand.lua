require "commands/ICommand.lua"

StartupCommand = class("StartupCommand",function()
    return ICommand.create()
end)

StartupCommand.__index = StartupCommand
StartupCommand.name = "StartupCommand"

function StartupCommand.create()
    local cmd = StartupCommand.new()
    return cmd
end

function StartupCommand:ctor()

end

function StartupCommand:execute(eventName,data)
    --cclog("StartupCommand:execute %s",eventName)
    if eventName == NI.ID.APP_STARTUP then
        StorageModel.getInst()
    end
end