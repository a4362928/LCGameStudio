require "commands/ICommand.lua"

ConnectCommand = class("ConnectCommand",function()
    return ICommand.create()
end)

ConnectCommand.__index = ConnectCommand
ConnectCommand.name = "ConnectCommand"

function ConnectCommand.create()
    local cmd = ConnectCommand.new()
    return cmd
end

function ConnectCommand:ctor()

end

function ConnectCommand:execute(eventName,data)
    if eventName == NI.ID.CONNECTED_CLOSED then
        Alert.show(self,"网络连接中断","提示",Alert.OK+Alert.CANCEL,self.onConnectCloseHandler,self)
    elseif eventName == NI.ID.CONNECTED_FAILED then
        Alert.show(self,"连接服务器失败，请检查网络","提示",Alert.OK+Alert.CANCEL,self.onConnectFailedHandler,self)
    elseif eventName == NI.ID.CONNECTED_ERROR then
        Alert.show(self,"网络连接异常","提示",Alert.OK+Alert.CANCEL,self.onConnectErrorHandler,self)
    end
end

function ConnectCommand:onConnectCloseHandler(detail)
    if detail == Alert.OK or detail == Alert.CANCEL then
        cc.Director:getInstance():endToLua()
    end
end

function ConnectCommand:onConnectErrorHandler(detail)
    if detail == Alert.OK or detail == Alert.CANCEL then
        cc.Director:getInstance():endToLua()
    end
end

function ConnectCommand:onConnectFailedHandler(detail)
    if detail == Alert.OK or detail == Alert.CANCEL then
        cc.Director:getInstance():endToLua()
    end
end