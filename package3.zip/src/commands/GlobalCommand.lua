require "commands/ICommand.lua"

GlobalCommand = class("GlobalCommand",function()
    return ICommand.create()
end)

GlobalCommand.__index = GlobalCommand
GlobalCommand.name = "GlobalCommand"

function GlobalCommand.create()
    local cmd = GlobalCommand.new()
    return cmd
end

function GlobalCommand:ctor()

end

function GlobalCommand:execute(eventName,data)
    --cclog("GlobalCommand:execute %s",eventName)
    if eventName == MI.ID.GRANTS_GET then
        if data.state==0 then
            local gold = data.result
            
            UserModel.getInst().userInfo.grants = UserModel.getInst().userInfo.grants-1
            EventBus.getInst():postEvent(NI.ID.JIU_UPDATE,{})
            
            PopupText.show("获得补助金"..gold.."金币")
        elseif data.state==1058 then
            
        end
    elseif eventName == MI.ID.LOGINS_GET then
        if data.state==0 then
            local days = UserModel.getInst().user.continueLoginCount
            if days>5 then days=5 end
            local award = GameConstant.LOGIN_AWARDS[days]
            PopupText.show("领取每日登录奖励"..award.."金币")
            --标识登录奖励已经领取
            UserModel.getInst().user.loginAward = true
        else
            PopupText.show("领取每日登录奖励异常")
        end
    elseif eventName == MI.ID.ACH_GET then
        --获得新成就
        local aid = data.result[1]
        local ach = ResourceModel.getInst():getAch(aid)
        PopupText.show("您获得新的成就："..ach.name..",请在成就界面查看")
    elseif eventName == MI.ID.SYNC_JACKPOT then
    
    elseif eventName == MI.ID.RANKING_REAL_GET then
        --排行数据
        GlobalDataModel.getInst():setRankingList(data.result[1],data.result[2])
    elseif eventName == MI.ID.C_BROAD_CAST then
        --系统广播
        GlobalDataModel.getInst():addBroadcast(data.result)
    elseif eventName == MI.ID.RESOURCES_CONFIG_GET_BY_TYPE then
        if data.result.activitys then
            --活动配置
            ResourceModel:setActivitys(data.result.activitys)
        end
    end
end