require "commands/ICommand.lua"

EnterGameCommand = class("EnterGameCommand",function()
    return ICommand.create()
end)

EnterGameCommand.__index = EnterGameCommand
EnterGameCommand.name = "EnterGameCommand"

function EnterGameCommand.create()
    local cmd = EnterGameCommand.new()
    return cmd
end

function EnterGameCommand:ctor()

end

function EnterGameCommand:execute(eventName,data)
    --cclog("EnterGameCommand:execute %s",eventName)
    if eventName == NI.ID.ENTER_GAME then
        --[[public static final int type_room = 1;
        public static final int type_achieve = 2;
        public static final int type_property = 3;
        public static final int type_award = 4;
        public static final int type_shop = 5;
        public static final int type_activity = 6;]]
        --请求活动配置
        GameMessageService.req(MI.ID.RESOURCES_CONFIG_GET_BY_TYPE,{6})
        --请求用户活动信息
        GameMessageService.req(MI.ID.ACTIVITY_GET,nil)
    end
end