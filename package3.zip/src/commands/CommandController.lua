require "commands/UserCommand.lua"
require "commands/GlobalCommand.lua"
require "commands/StartupCommand.lua"
require "commands/EnterGameCommand.lua"
require "commands/ConnectCommand.lua"

CommandController = class("CommandController")

CommandController.__index = CommandController
CommandController._inst = nil

CommandController.commands = {}

function CommandController.getInst()
    if CommandController._inst == nil then
        CommandController._inst = CommandController.new()
    end

    return CommandController._inst
end

function CommandController:ctor()

end

----@function [parent=#commands.CommandController] --此处注册全局命令
function CommandController:init()
    --程序启动
    self:registerCommand(NI.ID.APP_STARTUP,{StartupCommand},true)
    self:registerCommand(NI.ID.ENTER_GAME,{EnterGameCommand},true)
    --用户数据
    self:registerCommand(MI.ID.USER_LOGIN,{UserCommand},false)
    self:registerCommand(MI.ID.SYNC_USER,{UserCommand},false)
    self:registerCommand(MI.ID.JACKPOT_INFO_GET,{UserCommand},false)
    self:registerCommand(MI.ID.ACH_INFO_GET,{UserCommand},false)
    self:registerCommand(MI.ID.MAILS_GET,{UserCommand},false)
    self:registerCommand(MI.ID.SYNC_MAIL,{UserCommand},false)
    self:registerCommand(MI.ID.MAIL_ATTACH_GET,{UserCommand},false)
    self:registerCommand(MI.ID.ACTIVITY_GET,{UserCommand},false)
    --其他
    self:registerCommand(MI.ID.GRANTS_GET,{GlobalCommand},false)
    self:registerCommand(MI.ID.LOGINS_GET,{GlobalCommand},false)
    self:registerCommand(MI.ID.SYNC_JACKPOT,{GlobalCommand},false)
    self:registerCommand(MI.ID.RANKING_REAL_GET,{GlobalCommand},false)
    self:registerCommand(MI.ID.C_BROAD_CAST,{GlobalCommand},false)
    self:registerCommand(MI.ID.ACH_GET,{GlobalCommand},false)
    self:registerCommand(MI.ID.RESOURCES_CONFIG_GET_BY_TYPE,{GlobalCommand},false)
    
    --服务器连接
    self:registerCommand(NI.ID.CONNECTED_CLOSED,{ConnectCommand},false)
    self:registerCommand(NI.ID.CONNECTED_FAILED,{ConnectCommand},false)
    self:registerCommand(NI.ID.CONNECTED_ERROR,{ConnectCommand},false)
    
    --注册更多
    --self:registerCommand(MI.ID.USER_LOGIN,{UserCommand},false)
    
    
    
    
    
    
    
end

function CommandController:registerCommand(eventName,cmdClassies,once)
    if EventBus.getInst():observerExisted(self,eventName) then
        cclog("ERROR: "..eventName.." 命令已注册")
        return
    end

    once = once or false
    
    local cmd = {name=eventName,clazz=cmdClassies,once=once}
    table.insert(self.commands,#self.commands+1,cmd)
    
    EventBus.getInst():registerEvent(self,eventName,self.handle)
    
    local classiesStr = ""
    for i=1, #cmdClassies do
        local clazz = cmdClassies[i]
        classiesStr = classiesStr..clazz.name
        if i < #cmdClassies then
            classiesStr = classiesStr..","
        end
    end
    cclog("[注册命令：%s %s]",eventName,classiesStr)
end

function CommandController:handle(eventName,data)
    local cmds = self:getCmds(eventName)
    local removes = {}
    
    for i=1, #cmds do
        local cmd = cmds[i]
        local classies = cmd.clazz
        for j=i, #classies do
            local clazz = classies[j]
            clazz.create():execute(eventName,data)
            
            if cmd.once then
                table.insert(removes,#removes+1,cmd)
            end
        end
    end
    
    while #removes > 0 do
        local cmd = removes[1]
        self:removeCmd(cmd)
        table.remove(removes,1)
    end
end

function CommandController:removeCommand(eventName,cmdClass)
    local removes = {}

    for i=1, #self.commands do
        local cmd = self.commands[i]
        if cmd.name == eventName and cmd.clazz == cmdClass then
            table.insert(removes,#removes+1,cmd)
        end
    end
    
    while #removes > 0 do
        local cmd = removes[1]
        self:removeCmd(cmd)
        table.remove(removes,1)
    end
end

function CommandController:removeCmd(cmd)
    for i=1, #self.commands do
        local tmp = self.commands[i]
        if tmp == cmd then
            table.remove(self.commands,i)
            EventBus.getInst():unregisterEvent(self,tmp.name)
        end
    end
end

function CommandController:getCmds(eventName)
    local cmds = {}

    for i=1, #self.commands do
        local cmd = self.commands[i]
        if cmd.name == eventName then
            table.insert(cmds,#cmds+1,cmd)
        end
    end
    
    return cmds
end