ICommand = class("ICommand")

ICommand.__index = ICommand

function ICommand.create()
    local cmd = ICommand.new()
    return cmd
end

function ICommand:ctor()
    
end

function ICommand:execute(eventName,data)
    
end
