require "commands/ICommand.lua"

UserCommand = class("UserCommand",function()
    return ICommand.create()
end)

UserCommand.__index = UserCommand
UserCommand.name = "UserCommand"

function UserCommand.create()
    local cmd = UserCommand.new()
    return cmd
end

function UserCommand:ctor()

end

function UserCommand:execute(eventName,data)
    if eventName == MI.ID.USER_LOGIN then
        --用户基础信息
        UserModel.getInst():read(data.result)
        GlobalDataModel.getInst():setJackpot(data.result.pot)
    elseif eventName == MI.ID.SYNC_USER then 
        --用户同步信息
        UserModel.getInst():readSync(data)
    elseif eventName == MI.ID.JACKPOT_INFO_GET then 
        --用户彩金信息
        UserDataModel.getInst():setUserJackpot(data.result)
    elseif eventName == MI.ID.ACH_INFO_GET then
        --用户成就信息
        UserDataModel.getInst():setUserAchs(data.result[1])
    elseif eventName == MI.ID.MAILS_GET then
        --用户邮件信息
        UserDataModel.getInst():setUserMails(data.result)
    elseif eventName == MI.ID.SYNC_MAIL then
        UserDataModel.getInst():addUserMails(data.result)
    elseif eventName == MI.ID.MAIL_ATTACH_GET then
        --发送邮件改变通知
        EventBus.getInst():postEvent(NI.ID.USER_MAIL_NUMS_UPDATE,{})
    elseif eventName == MI.ID.ACTIVITY_GET then
        --用户活动参与信息
        UserDataModel.getInst():setUserActs(data.result)
    end
end