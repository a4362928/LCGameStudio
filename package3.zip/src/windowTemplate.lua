require "debug.lua"
require "GameData.lua"

Wtemplate = class("Wtemplate",function()
    return SubWindow:create()
end)

Wtemplate.__index = Wtemplate
Wtemplate._inst = nil

function Wtemplate.show(p)
    if Wtemplate._inst == nil then
        Wtemplate._inst = Wtemplate.new()
    end

    p = p and p or GameData.curScene
    Wtemplate._inst:_show(p)
end

function Wtemplate.hide()
    if Wtemplate._inst~=nil then
        Wtemplate._inst:_hide()
    end

    Wtemplate._inst = nil
end

function Wtemplate:ctor()
    --cclog("Wtemplate:ctor()")
    self:setupViews()
end

function Wtemplate:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/mall/mall.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    --self.btn = self.widget:getChildByName("btn")

    --local function btnCallback(sender, eventType)
        --if eventType == ccui.TouchEventType.ended then
            --if sender == self.btn then
                --self:onBtnClick(sender)
            --end
        --end
    --end

    --self.btn:addTouchEventListener(btnCallback)
end