TestLogin = class("TestLogin",function()
    return LCLayer.create()
end)

TestLogin.__index = TestLogin

function TestLogin.create()
    --cclog("TestLogin:create")
    local scene = LCScene.create()
    local layer = TestLogin.new()
    scene:addChild(layer)

    GameData.curLayer = layer
    GameData.curScene = scene
    return scene
end

function TestLogin:ctor()
    --cclog("TestLogin:ctor()")
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end
    
    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)
    
    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end
    
    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)

    --eventDispatcher:removeEventListenersForType(cc.EVENT_TOUCH_ONE_BY_ONE)
    local function onKeyReleased(touch,event)
        return self:onKeyReleased(touch,event)
    end
    
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)
    
    self:setupViews()
end

function TestLogin:setupViews()
    --cclog("TestLogin:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/testLogin/testLogin.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.serverText = self.widget:getChildByName("serverText")
    self.portText = self.widget:getChildByName("portText")
    self.openIdText = self.widget:getChildByName("openIdText")
    self.openKeyText = self.widget:getChildByName("openKeyText")
    self.pfText = self.widget:getChildByName("pfText")
    self.confirmBtn = self.widget:getChildByName("confirmBtn")
    
    self.serverText:setText(Config.Server.ip)
    self.portText:setText(Config.Server.port)
    self.openIdText:setText(Config.Server.openid)
    self.openKeyText:setText(Config.Server.openkey)
    self.pfText:setText(Config.Server.pf)

    local function confirmBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:connectServer()
        end
    end
    
    self.confirmBtn:addTouchEventListener(confirmBtnCallback)
end

function TestLogin:connectServer()
    cclog("TestLogin:connectServer")
    
    Config.Server.ip = self.serverText:getStringValue()
    Config.Server.port = self.portText:getStringValue()
    Config.Server.openid = self.openIdText:getStringValue()
    Config.Server.openkey = self.openKeyText:getStringValue()
    Config.Server.pf = self.pfText:getStringValue()
    
    --cc.Director:getInstance():setDepthTest(true)
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Splash.create()))
    else
        cc.Director:getInstance():runWithScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Splash.create()))
    end
end

function TestLogin:onEnter()
    --cclog("TestLogin:onEnter")
    self:_onEnter()
end

function TestLogin:onEnterTransitionDidFinish()
    --cclog("TestLogin:onEnterTransitionDidFinish")
    self:_onEnterTransitionDidFinish()
end

function TestLogin:onExitTransitionDidStart()
    --cclog("TestLogin:onExitTransitionDidStart")
    self:_onExitTransitionDidStart()
end

function TestLogin:onExit()
    --cclog("TestLogin:onExit")
    self:_onExit()
end

function TestLogin:cleanup()
    --cclog("TestLogin:cleanup")
    self:_cleanup()
end

function TestLogin:onTouchBegan()
    --cclog("TestLogin:onTouchBegan")
end

function TestLogin:onTouchMoved()
    --cclog("TestLogin:onTouchMoved")
end

function TestLogin:onTouchEnded()
    --cclog("TestLogin:onTouchEnded")
end

function TestLogin:onTouchCancelled()
    --cclog("TestLogin:onTouchEnded")
end

function TestLogin:onKeyReleased(keyCode, event)
    --cclog("TestLogin:onKeyReleased")
    if keyCode==cc.KeyCode.KEY_RETURN then
        Alert.show(self,"要离开游戏吗？","提示",Alert.OK+Alert.CANCEL,self.onAlertHandler,self)
    end
end

function TestLogin:onAlertHandler(detail)
    cclog("TestLogin:onAlertHandler %d",detail)
    if detail == Alert.OK then
        cc.Director:getInstance():endToLua()
    end
end