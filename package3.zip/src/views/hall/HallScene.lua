require "views/hall/MoreMenu.lua"

Hall = class("Hall",function()
    return LCLayer.create()
end)

Hall.__index = Hall

function Hall.create()
    --cclog("Hall:create")
    local scene = LCScene.create()
    local layer = Hall.new()
    scene:addChild(layer)
    
    GameData.curLayer = layer
    GameData.curScene = scene
    return scene
end

function Hall:ctor()
    --cclog("Hall:ctor()")
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end

    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)

    --eventDispatcher:removeEventListenersForType(cc.EVENT_TOUCH_ONE_BY_ONE)
    local function onKeyReleased(touch,event)
        return self:onKeyReleased(touch,event)
    end
    
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)

    self:setupViews()
end

function Hall:setupViews()
    --cclog("Hall:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/hall/hall.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)
    
    self.chatBtn = self.widget:getChildByName("chatBtn")
    self.eventBtn = self.widget:getChildByName("eventBtn")
    self.jackpotBtn = self.widget:getChildByName("jackpotBtn")
    self.mallBtn = self.widget:getChildByName("mallBtn")
    self.rankingBtn = self.widget:getChildByName("rankingBtn")
    self.achBtn = self.widget:getChildByName("achBtn")
    self.moreBtn = self.widget:getChildByName("moreBtn")
    self.qGameBtn = self.widget:getChildByName("qGameBtn")
    self.jiuBtn = self.widget:getChildByName("jiuBtn")
    self.mailBtn = self.widget:getChildByName("mailBtn")
    
    self.moreGroup = self.widget:getChildByName("moreGroup")
    
    self.headGroup = self.widget:getChildByName("headGroup")
    
    self.scrollView = self.widget:getChildByName("scrollView")
    local csize = self.scrollView:getContentSize()
    csize.width = visibleSize.width
    self.scrollView:setContentSize(csize)
    
    self.soloBtn = self.scrollView:getChildByName("soloBtn")
    self.area1Btn = self.scrollView:getChildByName("area1Btn")
    self.area2Btn = self.scrollView:getChildByName("area2Btn")
    self.area3Btn = self.scrollView:getChildByName("area3Btn")
    self.area4Btn = self.scrollView:getChildByName("area4Btn")
    
    local btns = {self.area1Btn,self.area2Btn,self.area3Btn,self.area4Btn}
    for i=1, #btns do
        local btn = btns[i]
        local needText = btn:getChildByName("needText")
        local baseText = btn:getChildByName("baseText")
        
        local areaVO = ResourceModel.getInst():getArea(i)
        needText:setString("进入需"..areaVO.enterNum)
        baseText:setString("底注"..areaVO.baseBet)
    end
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.chatBtn then
                self:onChatClick(sender)
            elseif sender == self.eventBtn then
            	self:onEventClick(sender)
            elseif sender == self.jackpotBtn then
                self:onJackpotClick(sender)
            elseif sender == self.mallBtn then
                self:onMallClick(sender)
            elseif sender == self.mailBtn then
                self:onMailClick(sender)
            elseif sender == self.rankingBtn then
                self:onRankingClick(sender)
            elseif sender == self.achBtn then
                self:onAchClick(sender)
            elseif sender == self.moreBtn then
                self:onMoreClick(sender)
            elseif sender == self.qGameBtn then
                self:onQGameClick(sender)
            elseif sender == self.area1Btn then
                self:onAreaClick(sender)
            elseif sender == self.area2Btn then
                self:onAreaClick(sender)
            elseif sender == self.area3Btn then
                self:onAreaClick(sender)
            elseif sender == self.area4Btn then
                self:onAreaClick(sender)
            elseif sender == self.soloBtn then
                self:onSoloClick(sender)
            elseif sender == self.jiuBtn then
                self:onSubsidyClick(sender)
            end
        end
    end

    --self.chatBtn:addTouchEventListener(btnCallback)
    self.eventBtn:addTouchEventListener(btnCallback)
    self.jackpotBtn:addTouchEventListener(btnCallback)
    self.mallBtn:addTouchEventListener(btnCallback)
    self.rankingBtn:addTouchEventListener(btnCallback)
    self.achBtn:addTouchEventListener(btnCallback)
    self.moreBtn:addTouchEventListener(btnCallback)
    self.qGameBtn:addTouchEventListener(btnCallback)
    self.jiuBtn:addTouchEventListener(btnCallback)
    self.mailBtn:addTouchEventListener(btnCallback)
    
    self.area1Btn:addTouchEventListener(btnCallback)
    self.area2Btn:addTouchEventListener(btnCallback)
    self.area3Btn:addTouchEventListener(btnCallback)
    self.area4Btn:addTouchEventListener(btnCallback)
    self.soloBtn:addTouchEventListener(btnCallback)
    
    EventBus.getInst():registerEvent(self,NI.ID.USER_UPDATE,self.refreshUser)
    EventBus.getInst():registerEvent(self,NI.ID.USER_MAIL_NUMS_UPDATE,self.refreshMail)
    EventBus.getInst():registerEvent(self,NI.ID.JIU_UPDATE,self.refreshJiu)
    EventBus.getInst():registerEvent(self,MI.ID.DESK_FAST_INTO,self.onFastIntoResult)
    
    self.moreMenu = MoreMenu.create(self.moreGroup)
    self.head = HeadWrapper.create(self.headGroup,1)
    self.notice = NoticeWidget.create(self,1)
    
    self:refreshUser()
    self:refreshNews()
    
    --显示领取登录奖励
    if UserModel.getInst().user.loginAward==false then
        DailyWindow.show(self)
    end
end

function Hall:refreshUser()
    self.head:refresh()
end

function Hall:refreshNews()
    local btns = {self.mailBtn,self.jiuBtn,self.eventBtn,self.jackpotBtn,self.mallBtn,self.rankingBtn,self.achBtn,self.moreBtn}
    for i=1, #btns do
    	local btn = btns[i]
        self:refreshNew(btn,0,false)
    end
    
    self:refreshMail()
    self:refreshJiu()
end

function Hall:refreshNew(btn,nums,b)
    if b==nil then
        if nums>0 then b = true end
    end
    local newGroup = btn:getChildByName("newGroup")
    local newText = newGroup:getChildByName("newText")
    newGroup:setVisible(b)
    newText:setVisible(true)
    
    newText:setString(nums)
    if nums<1 then
        newText:setVisible(false)
    end
end

function Hall:refreshMail()
    local nums = UserDataModel.getInst():getNewMails()
    self:refreshNew(self.mailBtn,nums)
end

function Hall:refreshJiu()
    local nums = UserModel.getInst().userInfo.grants
    local b = false
    if nums>0 and UserModel.getInst().user.gold <= 1500 then
        b = true
    end
    self:refreshNew(self.jiuBtn,0,b)
end

function Hall:onFastIntoResult(eventName,msg)
    if msg.state == 0 then
        DeskModel.getInst():read(msg.result)
            
        cc.Director:getInstance():setDepthTest(true)
        cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Multi.create()))
    end
    
    self:setButtonEnable(true,{self.qGameBtn})
    self:setButtonEnable(true,{self.area1Btn,self.area2Btn,self.area3Btn,self.area4Btn})
end

function Hall:onChatClick()
    --cclog("Hall:onChatClick")
    ChatWindow.show()
end

function Hall:onEventClick()
--cclog("Hall:onEventClick")
    ActivityWindow.show()
end

function Hall:onJackpotClick()
--cclog("Hall:onJackpotClick")
    JackpotWindow.show()
end

function Hall:onMallClick()
--cclog("Hall:onMallClick")
    MallWindow.show()
end

function Hall:onMailClick()
    --cclog("Hall:onMailClick")
    MailWindow.show()
end

function Hall:onRankingClick()
--cclog("Hall:onRankingClick")
    RankingWindow.show()
end

function Hall:onAchClick()
--cclog("Hall:onAchClick")
    AchWindow.show()
end

function Hall:onMoreClick()
--cclog("Hall:onMoreClick")
    self.moreMenu:show(self)
end

function Hall:onQGameClick()
--cclog("Hall:onQGameClick")
    local roomId = 1

    local ulevel = UserModel:getInst().level.level
    if ulevel~=nil and ulevel>5 then
        roomId = 2
    end
    
    GameMessageService.req(MI.ID.DESK_FAST_INTO,{roomId})
    
    self:setButtonEnable(false,{self.qGameBtn})
end

function Hall:onSubsidyClick()
    SubsidyWindow.show(self)
end

function Hall:onAreaClick(sender)
    --cclog("Hall:onAreaClick")
    local area = nil
    
    if sender == self.area1Btn then
        area = ResourceModel.getInst():getArea(1)
    elseif sender == self.area2Btn then
        area = ResourceModel.getInst():getArea(2)
    elseif sender == self.area3Btn then
        area = ResourceModel.getInst():getArea(3)
    elseif sender == self.area4Btn then
        area = ResourceModel.getInst():getArea(4)
    end
    
    if area then
        if area.id==1 then
            if UserModel.getInst().user.level > 5 then
                PopupText.show("您的等级超过5级，不能进入新手区")
                return
            end
        end
        
        if UserModel.getInst().user.gold>=area.enterNum then
            GameMessageService.req(MI.ID.DESK_FAST_INTO,{area.id})
            
            self:setButtonEnable(false,{sender})
        else
            PopupText.show("您的金币不足 "..area.enterNum)
        end
    end
end

function Hall:onSoloClick()
    --cclog("Hall:onSoloClick")
    cc.Director:getInstance():setDepthTest(true)
    cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Solo.create()))
end

function Hall:onEnter()
--cclog("Hall:onEnter")
    self:_onEnter()
end

function Hall:onEnterTransitionDidFinish()
--cclog("Hall:onEnterTransitionDidFinish")
    self:_onEnterTransitionDidFinish()
end

function Hall:onExitTransitionDidStart()
--cclog("Hall:onExitTransitionDidStart")
    self:_onExitTransitionDidStart()
end

function Hall:onExit()
--cclog("Hall:onExit")
    self:_onExit()
    
    self.notice:dispose()
    
    self.notice = nil
end

function Hall:cleanup()
--cclog("Hall:cleanup")
    self:_cleanup()
end

function Hall:onTouchBegan()
--cclog("Hall:onTouchBegan")
end

function Hall:onTouchMoved()
--cclog("Hall:onTouchMoved")
end

function Hall:onTouchEnded()
--cclog("Hall:onTouchEnded")
end

function Hall:onTouchCancelled()
--cclog("Hall:onTouchEnded")
end

function Hall:onKeyReleased(keyCode, event)
--cclog("Hall:onKeyReleased")
    if keyCode==cc.KeyCode.KEY_BACK then
        Alert.show(self,"要离开游戏吗？","提示",Alert.OK+Alert.CANCEL,self.onAlertHandler,self)
    end
end

function Hall:onAlertHandler(detail)
    --cclog("Hall:onAlertHandler %d",detail)
    if detail == Alert.OK then
        cc.Director:getInstance():endToLua()
    end
end