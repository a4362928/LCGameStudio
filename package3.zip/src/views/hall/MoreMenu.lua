MoreMenu = class("MoreMenu")

MoreMenu.__index = MoreMenu

function MoreMenu.create(group)
    local item = MoreMenu.new(group)
    return item
end

function MoreMenu:ctor(group)
    self.group = group
    self.group:setVisible(false)

    self.settingBtn = self.group:getChildByName("settingBtn")
    self.helpBtn = self.group:getChildByName("helpBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.settingBtn then
                self:onSettingClick(sender)
            elseif sender == self.helpBtn then
                self:onHelpClick(sender)
            end
        end
    end
    self.settingBtn:addTouchEventListener(btnCallback)
    self.helpBtn:addTouchEventListener(btnCallback)
end

function MoreMenu:show(p)
    self.group:setVisible(true)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self.group)
end

function MoreMenu:hide()
    self.group:setVisible(false)

    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self.group)
end

function MoreMenu:onSettingClick()
    SettingWindow.show()
end

function MoreMenu:onHelpClick()
    HelpWindow.show()
end

function MoreMenu:onTouchBegan()
    return true
end

function MoreMenu:onTouchEnded(touch,event)
    local pos = touch:getLocationInView()
    local size = self.group:getContentSize()
    if pos.x > 0 and pos.x < size.width and pos.y > 0 and pos.y < size.height then

    else
        self:hide()
    end
end

function MoreMenu:dispose()
    EventBus.getInst():unregisterEvents(self)
end