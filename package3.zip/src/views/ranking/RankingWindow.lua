require "views/ranking/RankingItem.lua"

RankingWindow = class("RankingWindow",function()
    return SubWindow:create()
end)

RankingWindow.__index = RankingWindow
RankingWindow._inst = nil

function RankingWindow.show(p)
    if RankingWindow._inst == nil then
        RankingWindow._inst = RankingWindow.new()
    end

    p = p and p or GameData.curScene
    RankingWindow._inst:_show(p)
end

function RankingWindow.hide()
    if RankingWindow._inst~=nil then
        RankingWindow._inst:_hide()
    end

    RankingWindow._inst = nil
end

function RankingWindow:ctor()
    --cclog("RankingWindow:ctor()")
    self.items = {}
    
    self:setupViews()
end

function RankingWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/ranking/ranking.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)
    
    self.BG = self.widget:getChildByName("BG")

    self.levelBtn = self.BG:getChildByName("levelBtn")
    self.goldBtn = self.BG:getChildByName("goldBtn")
    self.profitBtn = self.BG:getChildByName("profitBtn")
    self.closeBtn = self.BG:getChildByName("closeBtn")
    
    self.myGroup = self.BG:getChildByName("myGroup")
    self.myText = self.myGroup:getChildByName("myText")
    self.myText:setString("")

    self.scrollView = self.BG:getChildByName("scrollView")
    
    self.loading = Loading.create()
    self:addChild(self.loading)

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.levelBtn then
                self:onLevelClick(sender)
            elseif sender == self.goldBtn then
                self:onGoldClick(sender)
            elseif sender == self.profitBtn then
                self:onProfitClick(sender)
            elseif sender == self.closeBtn then
                self:onCloseClick(sender)
            end
        end
    end

    self.levelBtn:addTouchEventListener(btnCallback)
    self.goldBtn:addTouchEventListener(btnCallback)
    self.profitBtn:addTouchEventListener(btnCallback)
    self.closeBtn:addTouchEventListener(btnCallback)

    local function scrollViewEvent(sender, evenType)
        if evenType == ccui.ScrollviewEventType.scrolling then
            self:refreshScrollView()
        end
    end
    self.scrollView:addEventListener(scrollViewEvent)
    
    EventBus:registerEvent(self,NI.ID.RANKING_DATA_UPDATE,self.onUpdateRanking)

    self:changeView(self.goldBtn)
end

function RankingWindow:refreshScrollView()
    for i=1, #self.items do
        local item = self.items[i]

        if item.setupViewed==false then
            local gpos = self.scrollView:convertToWorldSpace(cc.p(0,0))
            local size = self.scrollView:getContentSize()
            local srect = cc.rect(gpos.x,gpos.y,size.width,size.height)

            gpos = item:convertToWorldSpace(cc.p(0,0))
            size = cc.size(626,87)
            local irect = cc.rect(gpos.x-size.width/2,gpos.y+size.height/2,size.width,size.height)

            if cc.rectIntersectsRect(srect,irect)==true then
                item:setupViews()
            else
                if cc.rectGetMinY(srect)>cc.rectGetMaxY(irect) then
                    break
                end
            end
        end
    end
end

function RankingWindow:changeView(button)
    local btns = {self.levelBtn,self.goldBtn,self.profitBtn}
    local type = 1
    self.itemRowSize = 1
    self.itemColOffset = 0
    self.itemRowOffset = 10
    self.itemSize = cc.size(626,87)

    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
            self.selectedBtn = button
        else
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
        end
    end

    if button==self.levelBtn then
        type = 1
    elseif button==self.profitBtn then
        type = 2
    elseif button==self.goldBtn then
        type = 3
    end

    local rankings = GlobalDataModel.getInst():getRankingList(type)
    if rankings==nil or #rankings<1 then
        --请求数据
        GameMessageService.req(MI.ID.RANKING_REAL_GET,{type})
        
        self.loading:show()
        return
    end
    
    local myRanking = UserDataModel.getInst():getMyRanking(type)
    if myRanking~=nil then
        self.myText:setString("我的排名："..myRanking.indexs)
    else
        self.myText:setString("我的排名：未上榜")
    end

    local innerSize,size = self:resetView(#rankings)
    self.items = {}

    for i=1, #rankings do
        local item = RankingItem.create(rankings[i],type)
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = self.itemSize.width/2+2+yu*(self.itemSize.width+self.itemColOffset)
        local ty = -self.itemSize.height/2+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        item:setPosition(cc.p(tx,ty))
        self.scrollView:addChild(item)
        table.insert(self.items,#self.items+1,item)
    end

    self.scrollView:jumpToTop()

    self:refreshScrollView()
end

function RankingWindow:onUpdateRanking(eventName,data)
    local type = data[1]
    if type==1 then
        if self.selectedBtn==self.levelBtn then 
            self.loading:hide()
            self:changeView(self.levelBtn) 
        end
    elseif type==2 then
        if self.selectedBtn==self.profitBtn then 
            self.loading:hide()
            self:changeView(self.profitBtn) 
        end
    elseif type==3 then
        if self.selectedBtn==self.goldBtn then 
            self.loading:hide()
            self:changeView(self.goldBtn) 
        end
    end
end

function RankingWindow:resetView(num)

    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function RankingWindow:onLevelClick(sender)
    self:changeView(sender)
end

function RankingWindow:onGoldClick(sender)
    self:changeView(sender)
end

function RankingWindow:onProfitClick(sender)
    self:changeView(sender)
end

function RankingWindow:onCloseClick()
    RankingWindow.hide()
end