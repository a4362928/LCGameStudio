RankingItem = class("RankingItem",function()
    return cc.Node:create()
end)

RankingItem.__index = RankingItem

function RankingItem.create(vo,type)
    local item = RankingItem.new(vo,type)
    return item
end

function RankingItem:ctor(vo,type)
    self.vo = vo
    self.type = type
    self.setupViewed = false

    --self:setupViews()
end

function RankingItem:setupViews()
    if self.setupViewed==true then
        return
    end

    self.setupViewed = true

    self.bg = cc.Sprite:create("parts/ranking/dikuang.png")
    self.bg:setPosition(95,0)
    self:addChild(self.bg)

    local size = self.bg:getContentSize()
    self:setContentSize(size)

    if self.vo.indexs<4 then
        local str = "parts/ranking/huangguan.png"
        if self.vo.indexs==1 then
            str = "parts/ranking/huangguan.png"
        elseif self.vo.indexs==2 then
            str = "parts/ranking/yinguan.png"
        elseif self.vo.indexs==3 then
            str = "parts/ranking/tongguan.png"
        end
        self.flag = cc.Sprite:create(str)
        local s = self.flag:getContentSize()
        self.flag:setPosition(-size.width/2+s.width/2+7,-5)
        self:addChild(self.flag)
    end
    
    self:refreshIndex()
    
    self.headIcon = cc.Sprite:create("parts/common/default100.png")
    self.headIcon:setScale(0.65,0.64)
    self.headIcon:setPosition(166-size.width/2,2)
    self:addChild(self.headIcon)
    
    self.nameText = ccui.Text:create()
    self.nameText:setAnchorPoint(0,0.5)
    self.nameText:setPosition(-size.width/2+250,0)
    self.nameText:setFontSize(26)
    self.nameText:setString(self.vo.nickName)
    self:addChild(self.nameText)
    
    self.descText = ccui.Text:create()
    self.descText:setAnchorPoint(1,0.5)
    self.descText:setFontSize(26)
    self:addChild(self.descText)
    if self.type==1 then
        self.descText:setPosition(size.width/2+50,0)
        self.descText:setString("Lv "..self.vo.level)
    elseif self.type==2 then
        self.descText:setPosition(size.width/2+60,0)
        self.descText:setString(StringUtils.toThousandSeparate(self.vo.gold,","))
    elseif self.type==3 then
        self.descText:setPosition(size.width/2+60,0)
        self.descText:setString(StringUtils.toThousandSeparate(self.vo.gold,","))
        
        self.goldFlag = cc.Sprite:create("parts/ranking/jinbi.png")
        local pos = cc.p(self.descText:getPosition())
        pos.x = pos.x-self.descText:getContentSize().width-40
        self.goldFlag:setPosition(pos)
        self:addChild(self.goldFlag)
    end
    --self.icon = cc.Sprite:create("parts/ach/icons/"..self.vo.id..".png")
    --self.icon:setPosition(-size.width/2+self.icon:getContentSize().width/2+11,3)
    --self:addChild(self.icon)
end

function RankingItem:refreshIndex()
    local str = tostring(self.vo.indexs)
    local nums = {}
    for i=1, string.len(str) do
        local d = string.sub(str,i,i)
        d = tonumber(d)
        table.insert(nums,#nums+1,d)
    end
    
    local numSize = cc.size(24,28)
    local gap = -4
    local tw = (numSize.width+gap)*(#nums)-gap
    local numSprites = {}
    for i=1, #nums do
    	local num = nums[i]
        local s = cc.Sprite:create("parts/ranking/"..num..".png")
        local p = cc.p(-263,0)
        p.x = p.x-tw/2+(numSize.width+gap)*(i-1)+numSize.width/2
        s:setPosition(p)
        self:addChild(s)
        table.insert(numSprites,#numSprites+1,s)
    end
end