MallItem = class("MallItem",function()
    return cc.Node:create()
end)

MallItem.__index = MallItem

function MallItem.create(vo,type)
    local item = MallItem.new(vo,type)
    return item
end

function MallItem:ctor(vo,type)
    self.vo = vo
    self.type = type
    
    self:setupViews()
end

function MallItem:getBgName()
    if self.type==1 then
        return "parts/mall/dikuang.png"
    elseif self.type==2 then
        return "parts/mall/dekuang.png"
    end
end

function MallItem:setupViews()
    self.bg = cc.Sprite:create(self:getBgName())
    local size = self.bg:getContentSize()
    self:setContentSize(size)
    
    self.icon = cc.Sprite:create(self.vo.icon)
    self:addChild(self.bg)
    self:addChild(self.icon)
    self.buyBtn = ccui.Button:create("parts/mall/dituanniu.png","parts/mall/dituanniu-1.png","parts/mall/dituanniu-1.png",ccui.TextureResType.localType)
    if self.type==1 then
        self.icon:setPosition(0,-15)
        local tw = 0
        self.nameGroup = ccui.ImageView:create("parts/mall/jinbi.png",ccui.TextureResType.localType)
        local s = self.nameGroup:getContentSize()
        self.nameGroup:setPosition(cc.p(0,size.height/2-s.height/2-10))
        self.nameText = ccui.Text:create()
        self.nameText:setPosition(cc.p(s.width+2,s.height/2))
        self.nameText:setString(self.vo.name)
        self.nameText:setFontSize(20)
        self.nameText:setAnchorPoint(cc.p(0, 0.5))
        self.nameGroup:addChild(self.nameText)
        self:addChild(self.nameGroup)
        
        tw = self.nameText:getPositionX()-s.width
        s = self.nameText:getContentSize()
        tw = tw + s.width
        self.nameGroup:setPositionX(-tw/2)

        if self.vo.ex and self.vo.ex~="" then
            self.exGroup = ccui.ImageView:create("parts/mall/zensongdai.png",ccui.TextureResType.localType)
            s = self.exGroup:getContentSize()
            self.exGroup:setPosition(19,-50)
            self.exText = ccui.Text:create()
            self.exText:setPosition(s.width-15,s.height/2+1)
            self.exText:setFontSize(20)
            self.exText:setString(self.vo.ex)
            self.exText:setAnchorPoint(cc.p(1, 0.5))
            self.exGroup:addChild(self.exText)
            self:addChild(self.exGroup)
        end
        
        self.buyBtn:setPosition(0,-size.height/2-25)
    elseif self.type==2 then
        local s = self.icon:getContentSize()
        self.icon:setPosition(-size.width/2+s.width/2+12,0)
        
        self.nameText = ccui.Text:create()
        self.nameText:setPosition(self.icon:getPositionX()+s.width/2+10,35)
        self.nameText:setString(self.vo.name)
        self.nameText:setFontSize(30)
        self.nameText:setColor(cc.c3b(255,228,1))
        self.nameText:setAnchorPoint(cc.p(0, 0.5))
        self:addChild(self.nameText)
        
        s = self.buyBtn:getContentSize()
        self.buyBtn:setPosition(size.width/2-s.width/2-15,0)

        self.descText = ccui.Text:create()
        self.descText:setPosition(self.icon:getPositionX()+s.width/2+20,15)
        self.descText:setString(self.vo.desc)
        self.descText:setFontSize(15)
        self.descText:setTextAreaSize(cc.size(240,75))
        self.descText:setAnchorPoint(cc.p(0, 1))
        self:addChild(self.descText)
    end

    self.buyBtn:setTitleFontSize(36)
    self.buyBtn:setTitleText("￥"..self.vo.rmb)
    self:addChild(self.buyBtn)
end