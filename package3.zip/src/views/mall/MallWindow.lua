require "views/mall/MallItem.lua"

MallWindow = class("MallWindow",function()
    return SubWindow:create()
end)

MallWindow.__index = MallWindow
MallWindow._inst = nil

function MallWindow.show(p)
    if MallWindow._inst == nil then
        MallWindow._inst = MallWindow.new()
    end

    p = p and p or GameData.curScene
    MallWindow._inst:_show(p)
end

function MallWindow.hide()
    if MallWindow._inst~=nil then
        MallWindow._inst:_hide()
    end

    MallWindow._inst = nil
end

function MallWindow:ctor()
--cclog("MallWindow:ctor()")
    self:setupViews()
end

function MallWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/mall/mall.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.goldBtn = self.BG:getChildByName("goldBtn")
    self.vipBtn = self.BG:getChildByName("vipBtn")
    self.freeBtn = self.BG:getChildByName("freeBtn")
    self.scrollView = self.BG:getChildByName("scrollView")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            elseif sender == self.goldBtn then
                self:onGoldClick(sender)
            elseif sender == self.vipBtn then
                self:onVipClick(sender)
            elseif sender == self.freeBtn then
                self:onFreeClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    self.goldBtn:addTouchEventListener(btnCallback)
    self.vipBtn:addTouchEventListener(btnCallback)
    self.freeBtn:addTouchEventListener(btnCallback)
    
    self:changeView(self.goldBtn)
end

function MallWindow:changeView(button)
    local btns = {self.goldBtn,self.vipBtn,self.freeBtn}
    local type = 1
    self.itemRowSize = 3
    self.itemColOffset = 55
    self.itemRowOffset = 8
    self.itemSize = cc.size(0,0)
    
    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
        else
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
        end
    end
    
    if button==self.goldBtn then
        type = 1
        self.itemRowSize = 3
        self.itemColOffset = 67
        self.itemRowOffset = 12
        self.itemSize = cc.size(151,157+45)
    elseif button==self.vipBtn then
        type = 2
        self.itemRowSize = 1
        self.itemRowOffset = 15
        self.itemSize = cc.size(558,126)
    elseif button==self.freeBtn then
        type = 3
    end
    
    local items = ResourceModel.getInst():getMallList(type)
    
    local innerSize,size = self:resetView(#items,type)
    
    for i=1, #items do
    	local item = MallItem.create(items[i],type)
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = self.itemSize.width/2+2+yu*(self.itemSize.width+self.itemColOffset)
        local ty = -self.itemSize.height/2+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        if type==1 then
            tx = tx+20
            ty = ty+23
        elseif type==2 then
            tx = tx+40
        elseif type==3 then
        end
        item:setPosition(cc.p(tx,ty))
    	self.scrollView:addChild(item)
    end
    
    self.scrollView:jumpToTop()
end

function MallWindow:resetView(num,type)
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function MallWindow:onGoldClick(sender)
    self:changeView(sender)
end

function MallWindow:onVipClick(sender)
    self:changeView(sender)
end

function MallWindow:onFreeClick(sender)
    self:changeView(sender)
end

function MallWindow:onCloseClick()
    MallWindow.hide()
end