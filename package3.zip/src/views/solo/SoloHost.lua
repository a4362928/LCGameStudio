SoloHost = class("SoloHost")

SoloHost.__index = SoloHost

function SoloHost.create(cardGroup,solo)
    local seat = SoloHost.new(cardGroup,solo)
    return seat
end

function SoloHost:ctor(cardGroup,solo)
    self.cardGroup = cardGroup
    self.solo = solo
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.cardOffset = 35
    
    self.typeGroup = self.solo.widget:getChildByName("htypeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    
    EventBus.getInst():registerEvent(self,CaribDeck.EVENT_TIDY_COMPLETE,self.onDeckTidyComplete,false)
    
    self:reset()
end

--全部牌翻转完毕
function SoloHost:onDeckTidyComplete(eventName,data)
    if self.deck and self.deck == data[1] then
        --结算动画
        self.solo.results:cash()
        --DelayUtils.delayCall(2,self.solo.results.cash,self.solo.results,1,2)
        --显示牌型
        self:showType()
    end
end

function SoloHost:showType()
    if self.deck and self.deck.dvo then
        self.typeGroup:setVisible(true)
        self.typeText:setString(self.deck.dvo:getDeckType())
    end
end

--获取位置
function SoloHost:getPosition()
    local pos = cc.p(self.visibleSize.width/2,self.visibleSize.height)
    return pos
end

--变灰色
function SoloHost:grayCards()
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:gray()
    end
end

function SoloHost:getCardPosition(card,gap,index,total)
    local csize = card.size
    local gsize = self.cardGroup:getLayoutSize()
    local pos = cc.p(card:getPosition())
    pos.y = gsize.height/2
    pos.x = (gsize.width-(csize.width+gap)*5-gap)/2+(index-1)*(csize.width+gap)+csize.width/2+gap
    return pos
end

--给自己发牌
function SoloHost:deal(card,immediate)
    if not card then
        return
    end

    if not self.deck then
        self.deck = CaribDeck.create(true,false,GameConstant.SOLO_CARD_SIZE,CaribDeck.TYPE_SOLO)
        self.deck:setAutoTidy(true)
    end
    self.deck:addCard(card)

    if not immediate then
        local pos = self.cardGroup:convertToWorldSpace(self:getCardPosition(card,self.cardOffset,#self.deck.cards,5))
        pos = card:getParent():convertToNodeSpace(pos)

        local actions = {}
        local time = 0.7
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(time,pos)))
        table.insert(actions,#actions+1,cc.RotateTo:create(time,0))
        local spa = cc.Spawn:create(actions)
        local seqActions = {}
        table.insert(seqActions,#seqActions+1,spa)
        local function completeHandler(card)
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)
        end
        --完成移动
        table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeHandler,{card}))
        if #self.deck.cards == 5 then
            EventBus:registerEvent(self,NI.ID.CARD_OWNER_DEAL_COMPLETE,self.onHostDealComplete,true)

            local function completeEventHandler(ss)
                EventBus.getInst():postEvent(NI.ID.CARD_OWNER_DEAL_COMPLETE,{})
            end
            --最后一张牌完成移动
            table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeEventHandler,{}))
        end
        local seq = cc.Sequence:create(seqActions)
        card:runAction(seq)

        card:tweenSize(time,self.deck.size)
    else
        local pos = self:getCardPosition(card,self.cardOffset,#self.deck.cards,5)
        card:setPosition(pos)
        --card:removeFromParent(false)
        self.cardGroup:addChild(card)
        if #self.deck.cards == 5 then
            self:onHostDealComplete(nil,nil)
        end

        card:setSize(self.deck.size)
    end
end

--自己发牌完毕
function SoloHost:onHostDealComplete(eventName,msg)
    cclog("Multi:onHostDealComplete")
    local pids = self.solo.mingPids
    for i=1, #pids do
        local index = (#self.deck.cards+1)-i
        local card = self.deck.cards[index]
        --设置牌
        card:setPid(pids[i])
        --打开
        card:flip()
    end
    
    --启用操作按钮
    self.solo:setButtonEnable(true,{self.solo.raiseBtn,self.solo.allopenBtn,self.solo.foldBtn})
end

--打开牌
function SoloHost:flip()
    --填充并翻开牌
    local pids = self.solo.results:getHostCards()
    self.deck:fillEmptyWithPids(pids)
    self.deck:flip(0.1,0,true)
end

--移除牌
function SoloHost:removeCards()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end

function SoloHost:reset()
    self.cardGroup:setOpacity(0)
    self.typeGroup:setVisible(false)
    --self.betGroup:setVisible(false)
    --self.anFlag:setVisible(false)
    --self.buckFlag:setVisible(false)
    --self.readyFlag:setVisible(false)

    --self:seatBet(0)
    --self:removeTips()
    self:removeCards()
end

function SoloHost:dispose()
    EventBus.getInst():unregisterEvents(self)
end