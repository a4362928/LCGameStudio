SoloResults = class("SoloResults")

SoloResults.__index = SoloResults

function SoloResults.create(resultGroup,solo)
    local seat = SoloResults.new(resultGroup,solo)
    return seat
end

function SoloResults:ctor(resultGroup,solo)
    self.resultGroup = resultGroup
    self.solo = solo
    self.result = {}
    
    self.loseBG = self.resultGroup:getChildByName("loseBG")
    self.winBG = self.resultGroup:getChildByName("winBG")
    self.tipText = self.resultGroup:getChildByName("tipText")
    
    self.htypeGroup = self.solo.widget:getChildByName("htypeGroup")
    self.htypeText = self.htypeGroup:getChildByName("typeText")
    self.typeGroup = self.solo.widget:getChildByName("typeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    
    self.resultGroup:setVisible(false)
    self.htypeGroup:setVisible(false)
    self.typeGroup:setVisible(false)
end

function SoloResults:showResult(delay,dur,gold)
    dur = dur or 3
    self.curShowDur = 0
    self.showDur = dur
    self.curShowDur = self.curShowDur - delay
    
    self.resultGroup:setVisible(false)
    self.loseBG:setVisible(false)
    self.winBG:setVisible(false)
    local str = ""
    if gold > 0 then
        str = "你赢了"
        self.winBG:setVisible(true)
    else
        str = "你输了"
        self.loseBG:setVisible(true)
    end
    local wgold = math.abs(gold)
    str = str..wgold.."金币"
    self.tipText:setString(str)
    
    local function showHandler(dt)
        if self.curShowDur >= 0 then
            self.resultGroup:setVisible(true)
        end
        self.curShowDur = self.curShowDur + dt
        if self.curShowDur >= self.showDur then
            self.resultGroup:setVisible(false)
            if self.showScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.showScheduler) end
        end
    end
    if self.showScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.showScheduler) end
    self.showScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(showHandler, 0,false)
end

function SoloResults:setResult(result)
    self:clear()
    
    self.result = result
end

function SoloResults:getHostCards()
    if self.result then
        return self.result.sysCards
    end
    return nil
end

function SoloResults:getCards()
    if self.result then
        return self.result.handCards
    end
    return nil
end


function SoloResults:cash()
    if self.result.winGold < 0 then
        self:cashLose()
    else
        self:cashWin()
    end
end

function SoloResults:cashLose()
    --输{"baseBet":100,"fillBet":200,"multiple":1,"sysCards":[303,312,414,206,103],"sysStyle":1,"userStyle":-1,"winGold":-300}
    local r = self.result
    local to = self.solo.host:getPosition()
    local all = math.abs(r.winGold)
    local base = self.solo.currentBet
    local raise = r.fillBet
    local yu = all - base - raise
    cclog("loser %d=%d+%d+%d",r.winGold,-base,-raise,-yu)
    --显示筹码动画
    local values = {}
    if base > 0 then table.insert(values,#values+1,base) end
    if raise > 0 then table.insert(values,#values+1,raise) end
    if #values > 0 then
        local function completeHandler()
            cclog("cashlose complete!!")
            EventBus.getInst():postEvent(NI.ID.CASH_COMPLETE,{})
        end
        --self.solo.heaps.heap:subTo(values,to,completeHandler)
        self.solo.heaps:subTo(1,values,to,completeHandler)
        --DelayUtils.delayCall(1,self.solo.heaps.heap.subTo,self.solo.heaps.heap,values,to,completeHandler)
    end

    if yu > 0 then
        local from = self.solo.owner:getPosition()
        --cclog("from %f %f",from.x,from.y)
        --self.solo.heaps.heap:createTo(yu,from,to)
        self.solo.heaps:createTo(1,yu,from,to)
        --DelayUtils.delayCall(1,self.solo.heaps.heap.createTo,self.solo.heaps.heap,yu,from,to)
    end
    
    self:showResult(0,2,r.winGold)
end

function SoloResults:cashWin()
    --赢{"baseBet":100,"fillBet":200,"multiple":1,"sysCards":[413,305,414,213,212],"sysStyle":1,"userStyle":1,"winGold":300}
    local r = self.result
    local to = self.solo.owner:getPosition()
    local all = math.abs(r.winGold)
    local base = self.solo.currentBet
    local raise = r.fillBet
    local yu = all - base - raise
    if yu < 0 then yu = 0 end
    cclog("winer %d=%d+%d+%d",r.winGold,base,raise,yu)
    --显示筹码动画
    local values = {}
    if base > 0 then table.insert(values,#values+1,base) end
    if raise > 0 then table.insert(values,#values+1,raise) end
    if #values > 0 then
        local function completeHandler()
            cclog("cashwin complete!!")
            EventBus.getInst():postEvent(NI.ID.CASH_COMPLETE,{})
        end
        --self.solo.heaps.heap:subTo(values,to,completeHandler)
        self.solo.heaps:subTo(1,values,to,completeHandler)
        --DelayUtils.delayCall(1,self.solo.heaps.heap.subTo,self.solo.heaps.heap,values,to,completeHandler)
    end

    if yu > 0 then
        local from = self.solo.host:getPosition()
        --self.solo.heaps.heap:createTo(yu,from,to)
        self.solo.heaps:createTo(1,yu,from,to)
        --DelayUtils.delayCall(1,self.solo.heaps.heap.createTo,self.solo.heaps.heap,yu,from,to)
    end
    
    self:showResult(0,2,r.winGold)
end

function SoloResults:clear()
    self.result = {}
end

function SoloResults:dispose()
    EventBus.getInst():unregisterEvents(self)
end