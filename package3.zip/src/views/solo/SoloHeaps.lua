SoloHeaps = class("SoloHeaps")

SoloHeaps.__index = SoloHeaps

function SoloHeaps.create(heapGroup,solo)
    local seat = SoloHeaps.new(heapGroup,solo)
    return seat
end

function SoloHeaps:ctor(heapGroup,solo)
    self.heapGroup = heapGroup
    self.solo = solo
    self.userModel = UserModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()

    self:initHeap()
end

function SoloHeaps:subTo(delay,values,to,compHandler)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.subTo,self.heap,values,to,compHandler)
    end
end

function SoloHeaps:createTo(delay,value,from,to)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.createTo,self.heap,value,from,to)
    end
end

function SoloHeaps:mergeFrom(delay,value,from)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.mergeFrom,self.heap,value,from)
    end
end

function SoloHeaps:initHeap()
    if not self.heap then
        local excs = {}
        local s = cc.size(300,100)
        local rect = cc.rect((self.visibleSize.width-s.width)/2-10,(self.visibleSize.height-s.height)/2-10,s.width,s.height)
        self.heap = CaribHeap.create(self.heapGroup,rect,excs,0)
    end
end

function SoloHeaps:betBases()
    self.heap:mergeFrom(self.solo.currentBet,self.solo.owner:getPosition())
    self.solo.owner:seatBet(self.solo.currentBet,false)
end

function SoloHeaps:dispose()
    EventBus.getInst():unregisterEvents(self)
end