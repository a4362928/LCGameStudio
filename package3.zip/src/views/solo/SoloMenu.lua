SoloMenu = class("SoloMenu")

SoloMenu.__index = SoloMenu

function SoloMenu.create(group,solo)
    local seat = SoloMenu.new(group,solo)
    return seat
end

function SoloMenu:show(p)
    if self:isVisible()==true then
        self:hide()
        return
    end

    self.group:setVisible(true)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self.group)
end

function SoloMenu:isVisible()
    return self.group:isVisible()
end

function SoloMenu:hide()
    self.group:setVisible(false)

    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self.group)
end

function SoloMenu:ctor(group,solo)
    self.group = group
    self.solo = solo
    self.group:setVisible(false)

    self.quitBtn = self.group:getChildByName("quitBtn")
    self.ptypeBtn = self.group:getChildByName("ptypeBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.quitBtn then
                self:onQuitClick(sender)
            elseif sender == self.ptypeBtn then
                self:onPTypeClick(sender)
            end
        end
    end
    self.quitBtn:addTouchEventListener(btnCallback)
    self.ptypeBtn:addTouchEventListener(btnCallback)
end

function SoloMenu:onQuitClick(sender)
    --GameMessageService.req(MI.ID.DESK_OUT)
    cc.Director:getInstance():setDepthTest(true)
    cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Hall.create()))

    UserModel.getInst():setStatus(GameConstant.USER_STATUS_NORMAL)

    self:hide()
end

function SoloMenu:onPTypeClick(sender)
    if self.cardType==nil then
        self.cardType = CardTypeWidget.create(CaribDeck.TYPE_SOLO)
    end
    self.cardType:show(self.solo)
    
    self:hide()
end

function SoloMenu:onTouchBegan()
    return true
end

function SoloMenu:onTouchEnded(touch,event)
    local pos = touch:getLocationInView()
    local size = self.group:getContentSize()
    if pos.x > 0 and pos.x < size.width and pos.y > 0 and pos.y < size.height then

    else
        self:hide()
    end
end

function SoloMenu:dispose()
    EventBus.getInst():unregisterEvents(self)
    
    if self.cardType then
        self.cardType:dispose()
    end
    self.cardType = nil
end