SoloDealer = class("SoloDealer")

SoloDealer.__index = SoloDealer

function SoloDealer.create(dealsGroup,solo)
    local seat = SoloDealer.new(dealsGroup,solo)
    return seat
end

function SoloDealer:ctor(dealsGroup,solo)
    self.dealsGroup = dealsGroup
    self.immediate = true
    self.solo = solo
    self.deals = {}

    self.dealsGroup:setOpacity(0)
end

--展开所有牌
function SoloDealer:cover()
    self:clearDeals()

    local cardSize = GameConstant.CARD_SIZE
    local dealsSize = self.dealsGroup:getLayoutSize()
    local len = 15
    local gap = -38
    local tw = (cardSize.width+gap)*len-gap

    if not self.immediate then
        for i=1, len do
            local tx = dealsSize.width/2+tw/2-(1-1)*(cardSize.width+gap)-cardSize.width/2
            local ty = dealsSize.height/2+i*0
            if i==1 then
                tx = tx+1
                ty = ty-1
            end
            local card = CaribCard.createWithPid(0,true,false,GameConstant.CARD_SIZE)
            card:setPosition(cc.p(tx,ty))
            table.insert(self.deals,#self.deals+1,card)
            self.dealsGroup:addChild(card)
        end

        for i=1, len do
            local index = math.abs(len+1-i)
            local tox = dealsSize.width/2+tw/2-(index-1)*(cardSize.width+gap)-cardSize.width/2
            local ty = dealsSize.height/2+index*0
            local card = self.deals[index]
            --actions
            local actions = {}
            table.insert(actions,#actions+1,cc.DelayTime:create((i-1)*0.005+0.1))
            table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(0.3,cc.p(tox,ty))))
            if i==len then
                local function completeHandler(card)
                    --发牌
                    self:deal()
                end
                table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{card}))
            end
            local seq = cc.Sequence:create(actions)
            card:runAction(seq)
        end
    else
        for i=1, len do
            local card = CaribCard.createWithPid(0,true,false,GameConstant.CARD_SIZE)
            table.insert(self.deals,#self.deals+1,card)
        end

        --发牌
        self:deal()
    end
end

--折叠所有牌
function SoloDealer:uncover()
    local cardSize = GameConstant.CARD_SIZE
    local dealsSize = self.dealsGroup:getLayoutSize()
    local len = #self.deals
    local gap = -38
    local tw = (cardSize.width+gap)*15-gap

    if not self.immediate then
        for i=1, len do
            local index = math.abs(len+1-i)
            local tx = dealsSize.width/2+tw/2-(1-1)*(cardSize.width+gap)-cardSize.width/2
            local ty = dealsSize.height/2+i*0
            local card = self.deals[index]
            if index==1 then
                tx = tx+1
                ty = ty-1
            end
            --actions
            local actions = {}
            table.insert(actions,#actions+1,cc.DelayTime:create((i-1)*0.005+0.3))
            table.insert(actions,#actions+1,cc.EaseSineIn:create(cc.MoveTo:create(0.3,cc.p(tx,ty))))
            if i==len then
                table.insert(actions,#actions+1,cc.DelayTime:create(1.3))
                local function completeHandler(card)
                    self:clearDeals()
                end
                table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{card}))
            end
            local seq = cc.Sequence:create(actions)
            card:runAction(seq)
        end
    else
        self:clearDeals()
    end
end

--发牌动画
function SoloDealer:deal()
    local maxNums = 2 * 5
    local index = 1
    
    if not self.immediate then
        local function dealTick()
            if index > maxNums then
                cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.dealScheduler)
                --剩余扑克牌收拢
                --self:uncover()
                return
            end

            local card = self.deals[#self.deals]
            table.remove(self.deals,#self.deals)

            if index%2==1 then
                self.solo.host:deal(card)
            else
                self.solo.owner:deal(card)
            end
            index = index + 1
        end

        self.dealScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(dealTick, 0.10, false)
    else
        while index<=maxNums do
            local card = self.deals[1]
            table.remove(self.deals,1)

            if index%2==1 then
                self.solo.host:deal(card,self.immediate)
            else
                self.solo.owner:deal(card,self.immediate)
            end
            index = index + 1
        end
    end
end

function SoloDealer:clearDeals()
    while #self.deals > 0 do
        local card = self.deals[1]
        table.remove(self.deals,1)
        card:removeFromParent(true)
    end

    self.deals = {}
end

function SoloDealer:dispose()
    EventBus.getInst():unregisterEvents(self)
end