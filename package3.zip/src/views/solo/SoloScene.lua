require "views/solo/SoloMenu.lua"
require "views/solo/SoloDealer.lua"
require "views/solo/SoloOwner.lua"
require "views/solo/SoloHost.lua"
require "views/solo/SoloHeaps.lua"
require "views/solo/SoloResults.lua"

Solo = class("Solo",function()
    return LCLayer.create()
end)

Solo.__index = Solo

function Solo.create()
    --cclog("Solo:create")
    local scene = LCScene.create()
    local layer = Solo.new()
    scene:addChild(layer)
    
    GameData.curLayer = layer
    GameData.curScene = scene
    return scene
end

function Solo:ctor()
    --cclog("Solo:ctor()")
    self.userModel = UserModel.getInst()
    self.currentBetId = 0
    self.currentBet = 100
    self.jackpot = false
    
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end

    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)

    local function onKeyReleased(keyCode, event)
        self:onKeyReleased(keyCode,event)
    end
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)

    self:setupViews()
end

function Solo:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/solo/solo.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)
    
    self.userGroup = self.widget:getChildByName("userGroup")
    self.jackpotGroup = self.widget:getChildByName("jackpotGroup")
    self.hcardGroup = self.widget:getChildByName("hcardGroup")
    self.cardGroup = self.widget:getChildByName("cardGroup")
    self.dealsGroup = self.widget:getChildByName("dealsGroup")
    self.menuGroup = self.widget:getChildByName("menuGroup")
    self.heapGroup = self.widget:getChildByName("heapGroup")
    self.resultGroup = self.widget:getChildByName("resultGroup")
    
    --按钮
    self.menuBtn = self.widget:getChildByName("menuBtn")
    self.mallBtn = self.widget:getChildByName("mallBtn")
    
    self.bet100Btn = self.widget:getChildByName("bet100Btn")
    self.bet500Btn = self.widget:getChildByName("bet500Btn")
    self.bet1000Btn = self.widget:getChildByName("bet1000Btn")
    self.bet5000Btn = self.widget:getChildByName("bet5000Btn")
    self.bet10000Btn = self.widget:getChildByName("bet10000Btn")
    
    self.dealBtn = self.widget:getChildByName("dealBtn")
    self.rebetBtn = self.widget:getChildByName("rebetBtn")
    self.jackpotBtn = self.widget:getChildByName("jackpotBtn")
    
    self.allopenBtn = self.widget:getChildByName("allopenBtn")
    self.raiseBtn = self.widget:getChildByName("raiseBtn")
    self.foldBtn = self.widget:getChildByName("foldBtn")
    
    self.restartBtn = self.widget:getChildByName("restartBtn")
    self.continueBtn = self.widget:getChildByName("continueBtn")
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.menuBtn then
                self:onMenuClick(sender)
            elseif sender == self.mallBtn then
                self:onMallClick(sender)
            elseif sender == self.bet100Btn then
                self:onBetClick(sender)
            elseif sender == self.bet500Btn then
                self:onBetClick(sender)
            elseif sender == self.bet1000Btn then
                self:onBetClick(sender)
            elseif sender == self.bet5000Btn then
                self:onBetClick(sender)
            elseif sender == self.bet10000Btn then
                self:onBetClick(sender)
            elseif sender == self.dealBtn then
                self:onDealClick(sender)
            elseif sender == self.rebetBtn then
                self:onRebetClick(sender)
            elseif sender == self.jackpotBtn then
                self:onJackpotClick(sender)
            elseif sender == self.allopenBtn then
                self:onAllopenClick(sender)
            elseif sender == self.raiseBtn then
                self:onRaiseClick(sender)
            elseif sender == self.foldBtn then
                self:onFoldClick(sender)
            elseif sender == self.restartBtn then
                self:onRestartClick(sender)
            elseif sender == self.continueBtn then
                self:onContinueClick(sender)
            end
        end
    end

    self.menuBtn:addTouchEventListener(btnCallback)
    self.mallBtn:addTouchEventListener(btnCallback)
    self.bet100Btn:addTouchEventListener(btnCallback)
    self.bet500Btn:addTouchEventListener(btnCallback)
    self.bet1000Btn:addTouchEventListener(btnCallback)
    self.bet5000Btn:addTouchEventListener(btnCallback)
    self.bet10000Btn:addTouchEventListener(btnCallback)
    self.dealBtn:addTouchEventListener(btnCallback)
    self.rebetBtn:addTouchEventListener(btnCallback)
    self.jackpotBtn:addTouchEventListener(btnCallback)
    self.allopenBtn:addTouchEventListener(btnCallback)
    self.raiseBtn:addTouchEventListener(btnCallback)
    self.foldBtn:addTouchEventListener(btnCallback)
    self.restartBtn:addTouchEventListener(btnCallback)
    self.continueBtn:addTouchEventListener(btnCallback)
    
    --主动消息
    EventBus.getInst():registerEvent(self,MI.ID.SOLO_DEAL,self.onDealResult)
    EventBus.getInst():registerEvent(self,MI.ID.SOLO_FOLD,self.onFoldResult)
    EventBus.getInst():registerEvent(self,MI.ID.SOLO_RAISE,self.onRaiseResult)
    EventBus.getInst():registerEvent(self,MI.ID.SOLO_OPEN,self.onOpenResult)
    
    --命令消息
    --EventBus.getInst():registerEvent(self,MI.ID.C_DESK_OUT,self.onCOutDeskResult)
    
    EventBus.getInst():registerEvent(self,NI.ID.CARD_TRY_FLIP,self.onCardTryFlip)
    EventBus.getInst():registerEvent(self,NI.ID.CASH_COMPLETE,self.onCashComplete)
    
    --菜单
    self.menu = SoloMenu.create(self.menuGroup,self)
    self.head = HeadWrapper.create(self.userGroup,2)
    self.notice = NoticeWidget.create(self,2)
    --发牌器
    self.dealer = SoloDealer.create(self.dealsGroup,self)
    --筹码
    self.heaps = SoloHeaps.create(self.heapGroup,self)
    --用户自己
    self.owner = SoloOwner.create(self.userGroup,self.cardGroup,self)
    self.owner:refresh()
    --庄家
    self.host = SoloHost.create(self.hcardGroup,self)
    --结果
    self.results = SoloResults.create(self.resultGroup,self)
    
    self:restart()
end

function Solo:restart()
    --显示下注按钮
    self:setButtonVisible(true,{self.bet100Btn,self.bet500Btn,self.bet1000Btn,self.bet5000Btn,self.bet10000Btn})
    --显示发牌按钮，重新下注按钮，但不可用
    self:setButtonVisible(true,{self.dealBtn,self.rebetBtn})
    self:setButtonEnable(false,{self.dealBtn,self.rebetBtn})
    --不显示打开，下注，弃牌，重新开始,继续下注
    self:setButtonVisible(false,{self.allopenBtn,self.raiseBtn,self.foldBtn})
    self:setButtonVisible(false,{self.restartBtn,self.continueBtn})
    --清除牌
    self.owner:removeCards()
    self.host:removeCards()
    self.owner:reset()
    self.host:reset()
    --重置筹码按钮
    self:resetBets()
end

function Solo:resetBets()
    local btns = {self.bet10000Btn,self.bet5000Btn,self.bet1000Btn,self.bet500Btn,self.bet100Btn}
    for i = 1 ,#btns do
        local btn = btns[i]
        btn:setBright(false)
        btn:setTouchEnabled(false)
    end

    self:refreshBets(self.userModel.user.gold)
end

function Solo:refreshBets(gold)
    local golds = {30000,15000,3000,1500,300}
    local btns = {self.bet10000Btn,self.bet5000Btn,self.bet1000Btn,self.bet500Btn,self.bet100Btn}

    for i = 1 ,#btns do
        local btn = btns[i]
        btn:setTouchEnabled(true)
        btn:setBright(true)
    end

    for i = 1, #golds do
        local g = golds[i]
        if gold < g then
            local btn = btns[i]
            btn:setTouchEnabled(false)
            btn:setBright(false)
        else
            break
        end
    end
end

function Solo:onMenuClick(sender)
    self.menu:show(self)
end

function Solo:onMallClick(sender)
    MallWindow.show()
end

function Solo:onBetClick(sender)
    local btns = {self.bet10000Btn,self.bet5000Btn,self.bet1000Btn,self.bet500Btn,self.bet100Btn}
    cclog("Solo:onBetClick")
    if sender then
        sender:setHighlighted(true)
        sender:setTouchEnabled(false)
        
        self:setButtonEnable(true,{self.dealBtn,self.rebetBtn})

        if sender==self.bet100Btn then
            self.currentBetId = 0
            self.currentBet = 100
        elseif sender==self.bet500Btn then
            self.currentBetId = 1
            self.currentBet = 500
        elseif sender==self.bet1000Btn then
            self.currentBetId = 2
            self.currentBet = 1000
        elseif sender==self.bet5000Btn then
            self.currentBetId = 3
            self.currentBet = 5000
        elseif sender==self.bet10000Btn then
            self.currentBetId = 4
            self.currentBet = 10000
        end

        for i = 1 ,#btns do
            local btn = btns[i]
            if btn~=sender and btn:isBright() then
                btn:setTouchEnabled(true)
                btn:setHighlighted(false)
            end
        end
    end
end

function Solo:onDealClick(sender)
    --SoundManager:play(SI.ID.START_SOUND)
    --开始新的一局
    self:startNew()
    --发送发牌消息
    GameMessageService.req(MI.ID.SOLO_DEAL,{self.currentBetId,self.jackpot})

    self.userModel:setStatus(GameConstant.USER_STATUS_PLAY)
end

function Solo:startNew()
    --隐藏下注按钮
    self:setButtonVisible(false,{self.bet100Btn,self.bet500Btn,self.bet1000Btn,self.bet5000Btn,self.bet10000Btn})
    --隐藏发牌按钮，重新下注按钮，但不可用
    self:setButtonVisible(false,{self.dealBtn,self.rebetBtn})
    --隐藏重新下注,继续
    self:setButtonVisible(false,{self.restartBtn,self.continueBtn})
    --显示全部打开，弃牌和加注
    self:setButtonVisible(true,{self.allopenBtn,self.foldBtn,self.raiseBtn})
    self:setButtonEnable(false,{self.allopenBtn,self.foldBtn,self.raiseBtn})
end

function Solo:onRebetClick(sender)
    --SoundMgr.play(SI.ID.NORMAL_SOUND)
    
    self:resetBets()

    self:setButtonEnable(false,{self.dealBtn,self.rebetBtn})
end

function Solo:onJackpotClick(sender)
end

function Solo:onAllopenClick(sender)
    --玩家看牌
    if self.owner.opened==false then
        GameMessageService.req(MI.ID.SOLO_OPEN)
        self.owner.opened = true
        --标记将要打开所有牌
        for i=1, #self.owner.deck.cards do
            local card = self.owner.deck.cards[i]
            --不能翻牌
            card:setFlip(false)
            self:addWillFlip(card)
        end
    else
        self.owner:flip()
    end

    --禁用看牌按钮
    self:setButtonEnable(false,{self.allopenBtn})
end

function Solo:onRaiseClick(sender)
    --SoundManager:play(SI.ID.RAISE_SOUND)
    --发送加注消息
    GameMessageService.req(MI.ID.SOLO_RAISE,nil)
    --不启用加注和弃牌按钮
    self:setButtonEnable(false,{self.allopenBtn,self.raiseBtn,self.foldBtn})
    
    local value = self.currentBet*2
    --牌不能再操作
    self.owner.deck:setFlip(false)
    --筹码
    self.owner:seatBet(value,true)
    self.heaps.heap:mergeFrom(value,self.owner:getPosition())
end

function Solo:onFoldClick(sender)
    --SoundManager:play(SI.ID.FOLD_SOUND)
    --发送弃牌消息
    GameMessageService.req(MI.ID.SOLO_FOLD,nil)
    --不启用加注和弃牌按钮
    self:setButtonEnable(false,{self.allopenBtn,self.raiseBtn,self.foldBtn})
    --牌不能再操作
    self.owner.deck:setFlip(false)
end

function Solo:onRestartClick(sender)
    --SoundManager:play(SI.ID.START_SOUND)
    
    self.owner:reset()
    self:restart()
end

function Solo:onContinueClick(sender)
    --SoundManager:play(SI.ID.NORMAL_SOUND)

    self:restart()
    self:onDealClick(nil)
end

function Solo:onDealResult(eventName,msg)
    if msg.state == 0 then
        --庄家牌
        self.mingPids = msg.result.hostCardIds
        
        self:setButtonEnable(false,{self.allopenBtn,self.foldBtn,self.raiseBtn})
        --展开牌
        self.dealer:cover()
        --下注筹码
        self.heaps:betBases()
        
        self.userModel:setStatus(GameConstant.USER_STATUS_PLAY)
    end
end

function Solo:onFoldResult(eventName,msg)
    if msg.state == 0 then
        self.results:setResult(msg.result)
        --筹码
        local function completeHandler()
            self:setButtonVisible(false,{self.allopenBtn,self.foldBtn,self.raiseBtn})
            self:setButtonVisible(true,{self.restartBtn,self.continueBtn})
            EventBus.getInst():postEvent(NI.ID.CASH_COMPLETE,{})
        end
        --self.heaps.heap:subTo({self.currentBet},self.host:getPosition(),completeHandler)
        self.heaps:subTo(1,{self.currentBet},self.host:getPosition(),completeHandler)
        --DelayUtils.delayCall(1,self.heaps.heap.subTo,self.heaps.heap,{self.currentBet},self.host:getPosition(),completeHandler)
        --变灰收起
        self.owner:seatFold()
        --改变用户状态
        self.userModel:setStatus(GameConstant.USER_STATUS_WAIT)
        
        self.results:showResult(0.5,2,-self.currentBet)
    end
end

function Solo:onRaiseResult(eventName,msg)
    if msg.state == 0 then
        self.results:setResult(msg.result)
        --显示玩家和庄家的牌
        self.owner:flip()
        self.host:flip()
        --结算动画
        --self.results:cash()
        --改变用户状态
        self.userModel:setStatus(GameConstant.USER_STATUS_WAIT)
    end
end

function Solo:onOpenResult(eventName,msg)
    if msg.state == 0 then
        local cards = msg.result
        --设置玩家已看牌
        self.owner.opened = true
        --设置所有牌面
        if cards then
            for i=1, #self.owner.deck.cards do
                local card = self.owner.deck.cards[i]
                local pid = tonumber(cards[i])
                if pid >= 102 then
                    card:setPid(pid)
                end
            end
        end
        --打开玩家点击的牌
        if self.willFilpCards and cards then
            for i=1, #self.willFilpCards do
                local card = self.willFilpCards[i]
                card:flip()
            end
        end

        self.willFilpCards = nil
    end
end

function Solo:onCardTryFlip(eventName,data)
    local card = data[1]
    self:addWillFlip(card)

    if self.owner.opened==false then
        --玩家看牌
        GameMessageService.req(MI.ID.SOLO_OPEN)
        self.owner.opened = true
    end
end

function Solo:addWillFlip(card)
    if card and card.back and not card.fliping then
        if not self.willFilpCards then
            self.willFilpCards = {}
        end

        local function hasWill(card)
            for i=1, #self.willFilpCards do
                if self.willFilpCards[i]==card then
                    return true
                end
            end
            return false
        end

        if not hasWill(card) then
            table.insert(self.willFilpCards,#self.willFilpCards+1,card)
        else
            return
        end
    end
end

function Solo:onCashComplete()
    cclog("Solo:onCashComplete")
    self:setButtonVisible(false,{self.allopenBtn,self.foldBtn,self.raiseBtn})
    self:setButtonVisible(true,{self.restartBtn,self.continueBtn})
    self.owner:refresh()
    
    if not self:checkCondition() then
        PopupText.show("您的金币不足！")
        self:onRestartClick(nil)
    end
end

function Solo:checkCondition()
    if self.currentBet*3 > self.userModel.user.gold then
        return false
    end
    return true
end

function Solo:onEnter()
--cclog("Solo:onEnter")
    self:_onEnter()
end

function Solo:onEnterTransitionDidFinish()
--cclog("Solo:onEnterTransitionDidFinish")
    self:_onEnterTransitionDidFinish()
end

function Solo:onExitTransitionDidStart()
--cclog("Solo:onExitTransitionDidStart")
    self:_onExitTransitionDidStart()
end

function Solo:onExit()
--cclog("Solo:onExit")
    self:_onExit()
    
    self.menu:dispose()
    self.notice:dispose()
    self.dealer:dispose()
    self.heaps:dispose()
    self.owner:dispose()
    self.host:dispose()
    self.results:dispose()
    
    self.menu = nil
    self.notice = nil
    self.dealer = nil
    self.heaps = nil
    self.owner = nil
    self.host = nil
    self.results = nil
end

function Solo:cleanup()
--cclog("Solo:cleanup")
    self:_cleanup()
end

function Solo:onTouchBegan()
--cclog("Solo:onTouchBegan")
end

function Solo:onTouchMoved()
--cclog("Solo:onTouchMoved")
end

function Solo:onTouchEnded()
--cclog("Solo:onTouchEnded")
end

function Solo:onTouchCancelled()
--cclog("Solo:onTouchEnded")
end

function Solo:onKeyReleased(keyCode, event)
    if keyCode==cc.KeyCode.KEY_BACK or keyCode==cc.KeyCode.KEY_MENU then
        self:onMenuClick(nil)
    end
end