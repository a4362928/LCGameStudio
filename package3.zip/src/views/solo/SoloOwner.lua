SoloOwner = class("SoloOwner")

SoloOwner.__index = SoloOwner

function SoloOwner.create(group,cardGroup,solo)
    local seat = SoloOwner.new(group,cardGroup,solo)
    return seat
end

function SoloOwner:ctor(group,cardGroup,solo)
    self.group = group
    self.cardGroup = cardGroup
    self.solo = solo
    self.userModel = UserModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.jackpot = false
    self.opened = false
    self.bet = 0
    self.cardOffset = 35
    self.tips = {}

    self.nameText = self.group:getChildByName("nameText")
    self.diamondGroup = self.group:getChildByName("diamondGroup")
    self.goldGroup = self.group:getChildByName("goldGroup")
    --self.betGroup = self.group:getChildByName("betGroup")
    self.goldText = self.goldGroup:getChildByName("goldText")
    self.diamondText = self.diamondGroup:getChildByName("diamondText")
    
    self.typeGroup = self.solo.widget:getChildByName("typeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    --self.betText = self.betGroup:getChildByName("betText")
    --self.anFlag = self.group:getChildByName("anFlag")
    --self.buckFlag = self.group:getChildByName("buckFlag")
    --self.readyFlag = self.group:getChildByName("readyFlag")
    EventBus.getInst():registerEvent(self,CaribDeck.EVENT_FLIPS_COMPLETE,self.onDeckFlips,false)
    EventBus.getInst():registerEvent(self,CaribDeck.EVENT_TIDY_COMPLETE,self.onDeckTidyComplete,false)

    self:reset()
end

--全部牌翻转完毕
function SoloOwner:onDeckFlips(eventName,data)
    if self.deck and self.deck == data[1] then
        self.solo:setButtonEnable(false,{self.solo.allopenBtn})
    end
end

--全部牌展示完毕
function SoloOwner:onDeckTidyComplete(eventName,data)
    if self.deck and self.deck == data[1] then
        --显示牌型
        self:showType()
    end
end

--显示牌型
function SoloOwner:showType()
    if self.deck and self.deck.dvo then
        self.typeGroup:setVisible(true)
        self.typeText:setString(self.deck.dvo:getDeckType())
    end
end

--刷新信息
function SoloOwner:refresh()
    self.nameText:setString(self.userModel.user.nickName)
    self.goldText:setString(StringUtils.toThousandSeparate(self.userModel.user.gold,","))
    self.diamondText:setString(StringUtils.toThousandSeparate(self.userModel.user.bang,","))
end

--获取位置
function SoloOwner:getPosition()
    local pos = cc.p(self.visibleSize.width/2,-30)
    return pos
end

--变灰色
function SoloOwner:grayCards()
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:gray()
    end
end

--加注
function SoloOwner:seatBet(value,raise)
    --[[self.bet = self.bet + value

    if self.bet > 0 then
        self.betGroup:setVisible(true)
    else
        self.betGroup:setVisible(false)
    end

    self.betText:setString(StringUtils.toThousandSeparate(self.bet,","))

    --显示暗注
    if not self.opened and raise and raise==true then
        self.anFlag:setVisible(true)
    end]]
end

--显示庄家标识
function SoloOwner:seatBuck(value)
    return
    self.buckFlag:setVisible(value)
end

--提示信息
function SoloOwner:seatTip(value)
    --cclog("SoloOwner:seatTip")
    self:addTip(value)
end

function SoloOwner:addTip(value)
    if true then return end
    local content = ""
    if value=="raise" then
        content = "加注"
    elseif value=="fold" then
        content = "弃牌"
    elseif value=="open" then
        content = "看牌"
    elseif value=="double" then
        content = "加倍"
    elseif value=="nodouble" then
        content = "不加倍"
    end

    if not content or content=="" then return end
    local tip = MultiTip.create(content,0)
    tip:setPosition(180,105)
    self.group:addChild(tip)

    local function completeHandler(tip)
        if tip then self:removeTip(tip) end
    end
    local actions = {}
    table.insert(actions,#actions+1,cc.MoveBy:create(0.5,cc.p(0,20)))
    table.insert(actions,#actions+1,cc.DelayTime:create(1))
    table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{tip}))

    local seq = cc.Sequence:create(actions)
    tip:runAction(seq)

    table.insert(self.tips,#self.tips+1,tip)
end

function SoloOwner:removeTip(tip)
    if not tip then
        return
    end
    for i=1, #self.tips do
        if self.tips[i]==tip then
            tip:removeFromParent(true)
            table.remove(self.tips,i)
            break
        end
    end
end

function SoloOwner:removeTips()
    while #self.tips > 0 do
        self:removeTip(self.tips[1])
    end
end

function SoloOwner:seatFold()
    self:seatTip("fold")
    --变灰
    self:grayCards()
    --收起
    if not self.opened then
        for i=1, #self.deck.cards do
            local card = self.deck.cards[i]
            --停止移动
            card:stopAllActions()
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)

            local pos = self:getCardPosition(card,-10,i,#self.deck.cards)
            local actions = {}
            table.insert(actions,#actions+1,cc.MoveTo:create(0.5,pos))
            --table.insert(actions,#actions+1,cc.RotateTo:create(0.5,0))
            local spa = cc.Spawn:create(actions)
            card:runAction(spa)
        end
    end
end

function SoloOwner:getCardPosition(card,gap,index,total)
    local csize = card.size
    local gsize = self.cardGroup:getLayoutSize()
    local pos = cc.p(card:getPosition())
    pos.y = gsize.height/2
    pos.x = (gsize.width-(csize.width+gap)*5-gap)/2+(index-1)*(csize.width+gap)+csize.width/2+gap
    return pos
end

--给自己发牌
function SoloOwner:deal(card,immediate)
    if not card then
        return
    end

    if not self.deck then
        self.deck = CaribDeck.create(true,false,GameConstant.SOLO_CARD_SIZE,CaribDeck.TYPE_SOLO)
        self.deck:setAutoTidy(true)
    end
    self.deck:addCard(card)

    if not immediate then
        local pos = self.cardGroup:convertToWorldSpace(self:getCardPosition(card,self.cardOffset,#self.deck.cards,5))
        pos = card:getParent():convertToNodeSpace(pos)

        local actions = {}
        local time = 0.7
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(time,pos)))
        table.insert(actions,#actions+1,cc.RotateTo:create(time,0))
        local spa = cc.Spawn:create(actions)
        local seqActions = {}
        table.insert(seqActions,#seqActions+1,spa)
        local function completeHandler(card)
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)
        end
        --完成移动
        table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeHandler,{card}))
        if #self.deck.cards == 5 then
            EventBus.getInst():registerEvent(self,NI.ID.CARD_OWNER_DEAL_COMPLETE,self.onOwnerDealComplete,true)

            local function completeEventHandler(ss)
                EventBus.getInst():postEvent(NI.ID.CARD_OWNER_DEAL_COMPLETE,{})
            end
            --最后一张牌完成移动
            table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeEventHandler,{}))
        end
        local seq = cc.Sequence:create(seqActions)
        card:runAction(seq)

        card:tweenSize(time,self.deck.size)
    else
        local pos = self:getCardPosition(card,self.cardOffset,#self.deck.cards,5)
        card:setPosition(pos)
        --card:removeFromParent(false)
        self.cardGroup:addChild(card)
        if #self.deck.cards == 5 then
            self.solo:delayCall(0.1,self.onOwnerDealComplete,self)
        end

        card:setSize(self.deck.size)
    end
end

--自己发牌完毕
function SoloOwner:onOwnerDealComplete(eventName,msg)
    cclog("Multi:onOwnerDealComplete")
    --剩余扑克牌收拢
    self.solo.dealer:uncover()
    --设置牌可以操作
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:setFlip(true)
    end
end

--打开牌
function SoloOwner:flip()
    --填充并翻开牌
    local pids = self.solo.results:getCards()
    if not pids then pids = {} end
    self.deck:fillEmptyWithPids(pids)
    self.deck:flip(0.1,0,true)
end

--移除牌
function SoloOwner:removeCards()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end

function SoloOwner:reset()
    self.jackpot = false
    self.opened = false
    
    self.cardGroup:setOpacity(0)
    self.typeGroup:setVisible(false)
    --self.betGroup:setVisible(false)
    --self.anFlag:setVisible(false)
    --self.buckFlag:setVisible(false)
    --self.readyFlag:setVisible(false)

    self:seatBet(0)
    self:removeTips()
    self:removeCards()
end

function SoloOwner:dispose()
    EventBus.getInst():unregisterEvents(self)
end