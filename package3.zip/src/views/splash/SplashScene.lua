Splash = class("Splash",function()
    return LCLayer.create()
end)

Splash.__index = Splash

Splash.logoIndex = 0
Splash.logo = nil

Splash.logoComplete = false
Splash.loginComplete = false
Splash.dataComplete = false

Splash.loadIndex = 0
Splash.loadResComplete = false

function Splash.create()
    --cclog("Splash:create")
    local scene = LCScene.create()
    local layer = Splash.new()
    scene:addChild(layer)
    
    GameData.curLayer = layer
    GameData.curScene = scene
    return scene
end

function Splash:ctor()
    --cclog("Splash:ctor()")
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end

    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)

    --eventDispatcher:removeEventListenersForType(cc.EVENT_TOUCH_ONE_BY_ONE)
    
    local function onKeyReleased(touch,event)
        return self:onKeyReleased(touch,event)
    end
    
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)

    self:setupViews()
end

function Splash:setupViews()
    --cclog("Splash:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.logos = {"images/logo640.png"}--,"images/logo640.png"
    self:showLogo()
    --self:startLogin()
    --self:startLodeRes()
    self:checkUpdate()
end

function Splash:checkUpdate()
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    xhr:open("GET", "https://raw.githubusercontent.com/a4362928/LCGameStudio/master/fzcarib.version")

    local function onReadyStateChange()
        local newVersion = xhr.responseText
        self.needUpdate = StorageModel.getInst():isNewVersion(newVersion)
        
        local support  = false
        local targetPlatform = cc.Application:getInstance():getTargetPlatform()
        if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) 
            or (cc.PLATFORM_OS_WINDOWS == targetPlatform) or (cc.PLATFORM_OS_ANDROID == targetPlatform) 
            or (cc.PLATFORM_OS_MAC  == targetPlatform) then
            support = true
        end
        
        if support==false then self.needUpdate = false end
        
        if self.needUpdate==nil or self.needUpdate==false then
            self:startLogin()
            self:startLodeRes()
        end
    end

    xhr:registerScriptHandler(onReadyStateChange)
    xhr:send()
end

function Splash:getLogo(index)
    if index <= #self.logos then
        return self.logos[index]
    end
    return nil
end

function Splash:showLogo()
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()
    
    self.logoIndex = self.logoIndex + 1
    
    local filename = self:getLogo(self.logoIndex)
    
    if filename then
        self.logo = cc.Sprite:create(filename)
        self.logo:setPosition(visibleSize.width/2,visibleSize.height/2)
        self:addChild(self.logo)
        
        local function completeHandler(ss)
            self:showLogo()
        end
        
        local seq = cc.Sequence:create(cc.DelayTime:create(1.5),cc.FadeOut:create(1),cc.CallFunc:create(completeHandler,{}))
        self.logo:runAction(seq)
    else
        self.logoComplete = true
        self:checkEnter()
        
        --检测更新
        self:handleUpdate()
    end
end

function Splash:handleUpdate()
    if self.needUpdate==true then
        Alert.show(self,"发现新版本，需要更新吗？","提示",Alert.OK+Alert.CANCEL,self.onUpdateHandler,self)
    end
end

function Splash:onUpdateHandler(detail)
    if detail == Alert.OK then
        UpdateWindow.show(self)
    else
        cc.Director:getInstance():endToLua()
    end
end

function Splash:startLogin()
    EventBus.getInst():registerEvent(self,NI.ID.CONNECTED_VERIFY,self.onConnectVerify)
    EventBus.getInst():registerEvent(self,NI.ID.CONNECTED_SUCCESS,self.onConnectSuccess)
    EventBus.getInst():registerEvent(self,NI.ID.CONNECTED_FAILED,self.onConnectFailed)
    EventBus.getInst():registerEvent(self,NI.ID.CONNECTED_CLOSED,self.onConnectClose)
    
    EventBus.getInst():registerEvent(self,MI.ID.USER_LOGIN,self.onLoginResult,true)

    GameConnector.getInst():connect()
end

function Splash:startLodeRes()
    self.resources = {
        --{path="data/props.lua",name="props.lua",type="luadata"},
        {path="data/achieves.lua",name="achieves.lua",type="luadata"},
        {path="data/rooms.lua",name="rooms.lua",type="luadata"},
        {path="data/malls.lua",name="malls.lua",type="luadata"},
        {path="data/events.lua",name="events.lua",type="luadata"},
        
        {path="images/card.plist",name="card.plist",type="plist"},
        {path="images/common.plist",name="common.plist",type="plist"},
        {path="images/chips.plist",name="chips.plist",type="plist"},
        
        {path="ui/multi/multi.csb",name="multi.csb",type="uicsb"},
        {path="ui/solo/solo.csb",name="solo.csb",type="uicsb"},
        --{path="images/face.plist",name="face.plist",type="plist"}
    }
    
    self:loadRes()
end

function Splash:getRes(index)
    if index <= #self.resources then
        return self.resources[index]
    end
    return nil
end

function Splash:loadRes()
    self.loadIndex = self.loadIndex + 1
    
    local res = self:getRes(self.loadIndex)

    if res then
        if res.type == "config" then
            local json = require("json")
            local str = cc.FileUtils:getInstance():getStringFromFile(res.path)
            local obj = json.decode(str) 
        elseif res.type == "luadata" then
            local obj = require(res.path)
            if res.name == "achieves.lua" then
                ResourceModel.getInst():setAchieves(obj)
            elseif res.name == "props.lua" then
                ResourceModel.getInst():setProps(obj)
            elseif res.name == "rooms.lua" then
                ResourceModel.getInst():setRooms(obj)
            elseif res.name == "malls.lua" then
                ResourceModel.getInst():setMalls(obj)
            elseif res.name == "events.lua" then
                ResourceModel.getInst():setEvents(obj)
            end
        elseif res.type == "plist" then
            cc.SpriteFrameCache:getInstance():addSpriteFrames(res.path)
        elseif res.type == "uicsb" then
            ccs.GUIReader:getInstance():widgetFromBinaryFile(res.path)
        elseif res.type == "png" then
            cc.Director:getInstance():getTextureCache():addImageAsync(res.path,nil)
        end
        
        local function loadHandler(ss)
            self:loadRes()
        end

        if not self.loadScheduler  then
            self.loadScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(loadHandler, 0.1 ,false)
        end
    else
        if self.loadScheduler then
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.loadScheduler)
            self.loadScheduler = nil
        end
        self.loadResComplete = true
        self:checkEnter()
    end
end

function Splash:onLoginResult(eventName,msg)
    if msg.state == 0 then
        cclog("登录服务器成功...")
        self.loginComplete = true
        
        EventBus.getInst():registerEvent(self,MI.ID.ACH_INFO_GET,self.onAchResult,true)
        --请求数据
        GameMessageService.req(MI.ID.BAG_LIST_GET,nil)
        GameMessageService.req(MI.ID.MAILS_GET,{0})
        GameMessageService.req(MI.ID.MAILS_GET,{2})
        GameMessageService.req(MI.ID.ACH_INFO_GET,{UserModel.getInst().uid})
        --GameMessageService.req(MI.ID.RESOURCES_CONFIG_GET)
    end
end

function Splash:onAchResult(eventName,msg)
    self.dataComplete = true
    
    self:checkEnter()
end

function Splash:onConnectVerify()
    cclog("验证服务器成功...")
    --"['userService.login','lzp13111','guyu','mainweb',null,null,null,null]\n"
    local openid = Config.Server.openid
    if openid==nil or openid=="" then
        openid = StorageModel.getInst():getOpenId()
    end
    GameMessageService.req(MI.ID.USER_LOGIN,{openid,Config.Server.openkey,Config.Server.pf})
end

function Splash:onConnectSuccess()
    cclog("连接服务器成功...")
end

function Splash:onConnectFailed()
    ccerror("连接服务器失败...")
end

function Splash:onConnectClose()
    cclog("服务器关闭...")
end

function Splash:checkEnter()
    if self.loginComplete and self.logoComplete and self.dataComplete and self.loadResComplete then
        cclog("进入游戏...")
        --cc.Director:getInstance():setDepthTest(true)
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Hall.create()))
        else
            cc.Director:getInstance():runWithScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Hall.create()))
        end
        
        EventBus.getInst():postEvent(NI.ID.ENTER_GAME,{})
    end
end

function Splash:onEnter()
--cclog("Splash:onEnter")
    self:_onEnter()
end

function Splash:onEnterTransitionDidFinish()
--cclog("Splash:onEnterTransitionDidFinish")
    self:_onEnterTransitionDidFinish()
end

function Splash:onExitTransitionDidStart()
--cclog("Splash:onExitTransitionDidStart")
    self:_onExitTransitionDidStart()
end

function Splash:onExit()
    --cclog("Splash:onExit")
    self:_onExit()
end

function Splash:cleanup()
--cclog("Splash:cleanup")
    self:_cleanup()
end

function Splash:onTouchBegan()
--cclog("Splash:onTouchBegan")
end

function Splash:onTouchMoved()
--cclog("Splash:onTouchMoved")
end

function Splash:onTouchEnded()
--cclog("Splash:onTouchEnded")
end

function Splash:onTouchCancelled()
--cclog("Splash:onTouchEnded")
end

function Splash:onKeyReleased(keyCode, event)
    --cclog("Splash:onKeyReleased")
    if keyCode==cc.KeyCode.KEY_BACK then
        Alert.show(self,"要离开游戏吗？","提示",Alert.OK+Alert.CANCEL,self.onAlertHandler,self)
    end
end

function Splash:onAlertHandler(detail)
    if detail == Alert.OK then
        cc.Director:getInstance():endToLua()
    end
end