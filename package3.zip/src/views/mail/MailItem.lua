MailItem = class("MailItem",function()
    return cc.Node:create()
end)

MailItem.__index = MailItem

function MailItem.create(vo,type)
    local item = MailItem.new(vo,type)
    return item
end

function MailItem:ctor(vo,type)
    self.vo = vo
    self.type = type
    self.setupViewed = false

    --self:setupViews()
end

function MailItem:setupViews()
    if self.setupViewed==true then
        return
    end

    self.setupViewed = true
    --背景
    self.bg = cc.Sprite:create("parts/mail/youjiandikuang1.png")
    self:addChild(self.bg)
    
    self.size = self.bg:getContentSize()
    self:setContentSize(self.size)
    
    --图标
    if self.type==0 then
        self.icon = cc.Sprite:create("parts/mail/lihe.png")
    elseif self.type==2 then
        self.icon = cc.Sprite:create("parts/mail/chouma.png")
    end
    
    local s = self.icon:getContentSize()
    self.icon:setPosition(-self.size.width/2+s.width/2+10,0)
    self:addChild(self.icon)
    
    --描述内容
    self.descText = ccui.Text:create()
    self.descText:setAnchorPoint(0,1)
    self.descText:setPosition(-self.size.width/2+115,30)
    self.descText:setTextAreaSize(cc.size(515,64))
    self.descText:setFontSize(26)
    self.descText:setString(self.vo.content)
    self:addChild(self.descText)
    
    --操作按钮
    if self.type==0 then
        self.getBtn = ccui.Button:create("parts/mail/lingqu.png","parts/mail/lingqu-1.png","parts/mail/lingqu-1.png")
        s = self.getBtn:getContentSize()
        self.getBtn:setPosition(self.size.width/2-s.width/2-15,0)
        self:addChild(self.getBtn)
        
        local function btnCallback(sender, eventType)
            if eventType == ccui.TouchEventType.ended then
                if sender == self.getBtn then
                    self:onGetClick(sender)
                end
            end
        end

        self.getBtn:addTouchEventListener(btnCallback)
        
        if self.vo.expression~=nil and self.vo.expression~="" then
            self.getBtn:setTouchEnabled(true)
            self.getBtn:setBright(true)
        else
            self.getBtn:setTouchEnabled(false)
            self.getBtn:setBright(false)
        end
    elseif self.type==2 then
        self.dateGroup = cc.Sprite:create("parts/mail/youjianyoubianyuandian.png")
        s = self.dateGroup:getContentSize()
        self.dateGroup:setPosition(self.size.width/2-s.width/2-13,0)
        self:addChild(self.dateGroup)
    end
end

function MailItem:onGetClick(sender)
    --cclog("领取")
    local exps = self.vo.expression
    self.vo.expression = ""
    
    local arr = StringUtils.split(exps,",")
    --提示
    for i=1, #arr do
    	local s = arr[i]
    	local type = string.sub(s,1,1)
    	if type=="g" then
            local g = tonumber(string.sub(s,2,#s))
            PopupText.show("获得"..g.."金币")
    	end
    end
    
    self.getBtn:setTouchEnabled(false)
    self.getBtn:setBright(false)
    
    GameMessageService.req(MI.ID.MAIL_ATTACH_GET,{self.vo.mailId})
end