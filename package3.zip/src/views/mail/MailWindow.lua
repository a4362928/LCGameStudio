require "views/mail/MailItem.lua"

MailWindow = class("MailWindow",function()
    return SubWindow:create()
end)

MailWindow.__index = MailWindow
MailWindow._inst = nil

function MailWindow.show(p)
    if MailWindow._inst == nil then
        MailWindow._inst = MailWindow.new()
    end

    p = p and p or GameData.curScene
    MailWindow._inst:_show(p)
end

function MailWindow.hide()
    if MailWindow._inst~=nil then
        MailWindow._inst:_hide()
    end

    MailWindow._inst = nil
end

function MailWindow:ctor()
    self.items = {}
    --cclog("MailWindow:ctor()")
    self:setupViews()
end

function MailWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/mail/mail.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    self.descGroup = self.BG:getChildByName("descGroup")
    self.descText = self.descGroup:getChildByName("descText")

    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.mailBtn = self.BG:getChildByName("mailBtn")
    self.msgBtn = self.BG:getChildByName("msgBtn")
    self.scrollView = self.BG:getChildByName("scrollView")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            elseif sender == self.mailBtn then
                self:onMailClick(sender)
            elseif sender == self.msgBtn then
                self:onMsgClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    self.mailBtn:addTouchEventListener(btnCallback)
    self.msgBtn:addTouchEventListener(btnCallback)
    
    local function scrollViewEvent(sender, evenType)
        if evenType == ccui.ScrollviewEventType.scrolling then
            self:refreshScrollView()
        end
    end
    self.scrollView:addEventListener(scrollViewEvent)

    self:changeView(self.mailBtn)
    
    EventBus.getInst():registerEvent(self,NI.ID.USER_MAIL_UPDATE,self.onRefreshMails,false)
end

function MailWindow:refreshScrollView()
    for i=1, #self.items do
        local item = self.items[i]

        if item.setupViewed==false then
            local gpos = self.scrollView:convertToWorldSpace(cc.p(0,0))
            local size = self.scrollView:getContentSize()
            local srect = cc.rect(gpos.x,gpos.y,size.width,size.height)

            gpos = item:convertToWorldSpace(cc.p(0,0))
            size = cc.size(736,95)
            local irect = cc.rect(gpos.x-size.width/2,gpos.y+size.height/2,size.width,size.height)

            if cc.rectIntersectsRect(srect,irect)==true then
                item:setupViews()
            else
                if cc.rectGetMinY(srect)>cc.rectGetMaxY(irect) then
                    break
                end
            end
        end
    end
end

--有邮件来时刷新
function MailWindow:onRefreshMails()
    self:changeView(self.mailBtn)
end

function MailWindow:changeView(button)
    local btns = {self.mailBtn,self.msgBtn}
    local type = 1
    self.itemRowSize = 1
    self.itemColOffset = 0
    self.itemRowOffset = 8
    self.itemSize = cc.size(736,95)

    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
        else
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
        end
    end

    if button==self.mailBtn then
        type = 0
        self.descText:setString("邮件收取后自动删除，最多保存7天")
    elseif button==self.msgBtn then
        type = 2
        self.descText:setString("系统消息保留最新的15条消息")
    end

    local mails = UserDataModel.getInst():getUserMails(type)

    local innerSize,size = self:resetView(#mails,type)

    for i=1, #mails do
        local item = MailItem.create(mails[i],type)
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = self.itemSize.width/2+2+yu*(self.itemSize.width+self.itemColOffset)-2
        local ty = -self.itemSize.height/2+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        item:setPosition(cc.p(tx,ty))
        self.scrollView:addChild(item)
        table.insert(self.items,#self.items+1,item)
    end
    
    self.scrollView:jumpToTop()
    self:refreshScrollView()
end

function MailWindow:resetView(num,type)
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function MailWindow:onMailClick(sender)
    self:changeView(sender)
end

function MailWindow:onMsgClick(sender)
    self:changeView(sender)
end

function MailWindow:onCloseClick()
    MailWindow.hide()
end