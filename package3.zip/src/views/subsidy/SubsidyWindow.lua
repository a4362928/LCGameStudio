SubsidyWindow = class("SubsidyWindow",function()
    return SubWindow:create()
end)

SubsidyWindow.__index = SubsidyWindow
SubsidyWindow._inst = nil

function SubsidyWindow.show(p)
    if SubsidyWindow._inst == nil then
        SubsidyWindow._inst = SubsidyWindow.new()
    end

    p = p and p or GameData.curScene
    SubsidyWindow._inst:_show(p)
end

function SubsidyWindow.hide()
    if SubsidyWindow._inst~=nil then
        SubsidyWindow._inst:_hide()
    end

    SubsidyWindow._inst = nil
end

function SubsidyWindow:ctor()
    --cclog("SubsidyWindow:ctor()")
    self:setupViews()
end

function SubsidyWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/subsidy/subsidy.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    self.rangeText = self.BG:getChildByName("rangeText")
    self.descText = self.BG:getChildByName("descText")
    
    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.getBtn = self.BG:getChildByName("getBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            elseif sender == self.getBtn then
                self:onGetClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    self.getBtn:addTouchEventListener(btnCallback)
    
    self:refresh()
end

function SubsidyWindow:refresh()
    local times = UserModel.getInst().userInfo.grants
    self.getBtn:setTouchEnabled(false)
    self.getBtn:setBright(false)
    
    if times > 0 and UserModel.getInst().user.gold <= 1500 then
        self.getBtn:setTouchEnabled(true)
        self.getBtn:setBright(true)
    end
end

function SubsidyWindow:onGetClick()
    --领取
    GameMessageService.req(MI.ID.GRANTS_GET,nil)
    
    --SubsidyWindow.hide()
end

function SubsidyWindow:onCloseClick()
    SubsidyWindow.hide()
end