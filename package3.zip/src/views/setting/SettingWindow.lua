SettingWindow = class("SettingWindow",function()
    return SubWindow:create()
end)

SettingWindow.__index = SettingWindow
SettingWindow._inst = nil

function SettingWindow.show(p)
    if SettingWindow._inst == nil then
        SettingWindow._inst = SettingWindow.new()
    end

    p = p and p or GameData.curScene
    SettingWindow._inst:_show(p)
end

function SettingWindow.hide()
    if SettingWindow._inst~=nil then
        SettingWindow._inst:_hide()
    end

    SettingWindow._inst = nil
end

function SettingWindow:ctor()
    --cclog("SettingWindow:ctor()")
    self:setupViews()
end

function SettingWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/setting/setting.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    self.effectGroup = self.BG:getChildByName("effectGroup")
    self.effectGroup:setOpacity(255)
    self.musicGroup = self.BG:getChildByName("musicGroup")
    self.musicGroup:setOpacity(255)
    
    local s = self.effectGroup:getContentSize()
    self.effectSlider = ccui.Slider:create()
    self.effectSlider:setTouchEnabled(true)
    self.effectSlider:loadBarTexture("parts/setting/jindutiao1.png")
    self.effectSlider:loadSlidBallTextures("parts/setting/huadongyuan.png", "parts/setting/huadongyuan.png", "")
    self.effectSlider:loadProgressBarTexture("parts/setting/jindutiao.png")
    self.effectSlider:setPosition(s.width/2,s.height/2)
    self.effectGroup:addChild(self.effectSlider)
    
    self.musicSlider = ccui.Slider:create()
    self.musicSlider:setTouchEnabled(true)
    self.musicSlider:loadBarTexture("parts/setting/jindutiao1.png")
    self.musicSlider:loadSlidBallTextures("parts/setting/huadongyuan.png", "parts/setting/huadongyuan.png", "")
    self.musicSlider:loadProgressBarTexture("parts/setting/jindutiao.png")
    self.musicSlider:setPosition(s.width/2,s.height/2)
    self.musicGroup:addChild(self.musicSlider)
    
    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.logoutBtn = self.BG:getChildByName("logoutBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            elseif sender == self.logoutBtn then
                self:onLogoutClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    self.logoutBtn:addTouchEventListener(btnCallback)
    
    local function percentChangedEvent(sender,eventType)
        if eventType == ccui.SliderEventType.percentChanged then
            if sender==self.effectSlider then
                self:onEffectChange(sender)
            elseif sender==self.musicSlider then
                self:onMusicChange(sender)
            end
        end
    end
    self.effectSlider:addEventListener(percentChangedEvent)
    self.musicSlider:addEventListener(percentChangedEvent)
    
    self:refresh()
end

function SettingWindow:refresh()
    self.effectSlider:setPercent(StorageModel.getInst():getEffectVolume())
    self.musicSlider:setPercent(StorageModel.getInst():getMusicVolume())
end

function SettingWindow:onEffectChange(sender)
    local p = sender:getPercent()
    --cclog("effect:%f",p)
    StorageModel.getInst():setEffectVolume(p)
end

function SettingWindow:onMusicChange(sender)
    local p = sender:getPercent()
    --cclog("music:%f",p)
    StorageModel.getInst():setMusicVolume(p)
end

function SettingWindow:onLogoutClick()
    
end

function SettingWindow:onCloseClick()
    StorageModel.getInst():setEffectVolume(StorageModel.getInst():getEffectVolume())
    StorageModel.getInst():setMusicVolume(StorageModel.getInst():getMusicVolume())
    
    SettingWindow.hide()
end