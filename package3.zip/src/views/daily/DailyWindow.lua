DailyWindow = class("DailyWindow",function()
    return SubWindow:create()
end)

DailyWindow.__index = DailyWindow
DailyWindow._inst = nil

function DailyWindow.show(p)
    if DailyWindow._inst == nil then
        DailyWindow._inst = DailyWindow.new()
    end

    p = p and p or GameData.curScene
    DailyWindow._inst:_show(p)
end

function DailyWindow.hide()
    if DailyWindow._inst~=nil then
        DailyWindow._inst:_hide()
    end

    DailyWindow._inst = nil
end

function DailyWindow:ctor()
    --cclog("DailyWindow:ctor()")
    self:setupViews()
end

function DailyWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/daily/daily.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    --self.closeBtn = self.widget:getChildByName("closeBtn")
    self.day1Btn = self.widget:getChildByName("day1Btn")
    self.day2Btn = self.widget:getChildByName("day2Btn")
    self.day3Btn = self.widget:getChildByName("day3Btn")
    self.day4Btn = self.widget:getChildByName("day4Btn")
    self.day5Btn = self.widget:getChildByName("day5Btn")
    self.getBtn = self.widget:getChildByName("getBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.day1Btn then
                self:onDayClick(sender)
            elseif sender == self.day2Btn then
                self:onDayClick(sender)
            elseif sender == self.day3Btn then
                self:onDayClick(sender)
            elseif sender == self.day4Btn then
                self:onDayClick(sender)
            elseif sender == self.day5Btn then
                self:onDayClick(sender)
            elseif sender == self.getBtn then
                self:onGetClick(sender)
            end
        end
    end

    --self.closeBtn:addTouchEventListener(btnCallback)
    self.day1Btn:addTouchEventListener(btnCallback)
    self.day2Btn:addTouchEventListener(btnCallback)
    self.day3Btn:addTouchEventListener(btnCallback)
    self.day4Btn:addTouchEventListener(btnCallback)
    self.day5Btn:addTouchEventListener(btnCallback)
    self.getBtn:addTouchEventListener(btnCallback)
    
    local days = UserModel.getInst().user.continueLoginCount
    self:refreshDays(days)
end

function DailyWindow:refreshDays(day)
    if day>5 then day=5 end
    
    local btns = {self.day1Btn,self.day2Btn,self.day3Btn,self.day4Btn,self.day5Btn}
    local button = btns[day]

    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
        else
            btn:setTouchEnabled(false)
            btn:setHighlighted(false)
        end
    end
end

function DailyWindow:onDayClick()
    DailyWindow.hide()
end

function DailyWindow:onGetClick()
    GameMessageService.req(MI.ID.LOGINS_GET,nil)

    DailyWindow.hide()
end

function DailyWindow:onCloseClick()
    DailyWindow.hide()
end