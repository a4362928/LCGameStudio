Loading = class("Loading",function()
    return cc.Sprite:create("parts/common/1.png")
end)

Loading.__index = Loading

--Loading.widget = nil

function Loading.create()
    local loading = Loading.new()
    return loading
end

function Loading:ctor()
--cclog("Loading:ctor()")
    self.showed = false
end

function Loading:show(p)
    if self.showed==true then
        return
    end
    
    self.showed = true
    
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()
    self:setPosition(visibleSize.width/2,visibleSize.height/2)    
    
    self:setVisible(true)
    
    local animation = cc.Animation:create()
    for i = 1, 20 do
        animation:addSpriteFrameWithFile("parts/common/"..i..".png")
    end
    animation:setDelayPerUnit(0.05)

    local animate = cc.Animate:create(animation)
    local seq = cc.Sequence:create(animate,cc.DelayTime:create(0.2))
    self:runAction(cc.RepeatForever:create(seq))
end

function Loading:hide()
    self.showed = false
    self:stopAllActions()
    self:setVisible(false)
end