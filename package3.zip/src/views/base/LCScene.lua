LCScene = class("LCScene",function()
    return cc.Scene:create()
end)

LCScene.__index = LCScene

function LCScene.create()
    local scene = LCScene.new()
    return scene
end

function LCScene:ctor()

end