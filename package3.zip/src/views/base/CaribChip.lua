CaribChip = class("CaribChip",function()
    return cc.Sprite:createWithSpriteFrameName("100.png")
end)

CaribChip.__index = CaribChip

function CaribChip.create(value)
    local chip = CaribChip.new(value)
    return chip
end

function CaribChip:ctor(value)
    self.value = value
    self.checked = false
    
    local sname = ""
    if value==1 then
        sname = "1.png"
    elseif value==2 then
        sname = "2.png"
    elseif value==5 then
        sname = "5.png"
    elseif value==10 then
        sname = "10.png"
    elseif value==50 then
        sname = "50.png"
    elseif value==100 then
        sname = "100.png"
    elseif value==200 then
        sname = "200.png"   
    elseif value==500 then
        sname = "500.png"
    elseif value==1000 then
        sname = "1k.png"
    elseif value==2000 then
        sname = "2k.png"
    elseif value==5000 then
        sname = "5k.png"
    end
    
    local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(sname)
    if frame then self:setSpriteFrame(frame) end
end