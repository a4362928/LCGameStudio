HeadWrapper = class("HeadWrapper")

HeadWrapper.__index = HeadWrapper

function HeadWrapper.create(group,type)
    local head = HeadWrapper.new(group,type)
    return head
end

function HeadWrapper:ctor(group,type)
    self.group = group
    self.type = type
    
    self:setupViews()
end

function HeadWrapper:setupViews()
    self.nameText = self.group:getChildByName("nameText")
    self.diamondGroup = self.group:getChildByName("diamondGroup")
    self.goldGroup = self.group:getChildByName("goldGroup")
    self.diamondText = self.diamondGroup:getChildByName("diamondText")
    self.goldText = self.goldGroup:getChildByName("goldText")
    
    self.headIcon = cc.Sprite:create("parts/common/default100.png")
    self.headIcon:setScale(0.9,0.9)
    self.headIcon:setPosition(55,75)
    self.group:addChild(self.headIcon)

    self.progressBar = ccui.LoadingBar:create("parts/hall/jinyangtiao .png",0)
    self.progressBar:setPosition(57,11)
    self.group:addChild(self.progressBar)

    self.levelText = ccui.Text:create()
    self.levelText:setFontSize(15)
    self.levelText:setPosition(57,11)
    self.group:addChild(self.levelText)
    
    self:refresh()
end

function HeadWrapper:refresh()
    local curExp,needExp,totalExp,lv = ResourceModel:getLevelInfo(UserModel.getInst().user.exp)
    local p = curExp/needExp*100
    
    self.progressBar:setPercent(p)
    self.levelText:setString("Lv "..lv.."  "..curExp.."/"..needExp)--UserModel.getInst().user.level
    
    self.nameText:setString(UserModel.getInst().user.nickName)
    self.diamondText:setString(StringUtils.toThousandSeparate(UserModel:getInst().user.bang,","))
    self.goldText:setString(StringUtils.toThousandSeparate(UserModel:getInst().user.gold,","))
end