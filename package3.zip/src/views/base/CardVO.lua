CardVO = class("CardVO")

CardVO.__index = CardVO

--CardVO.pid = nil
--CardVO.face = nil
--CardVO.color = nil

function CardVO.create(pid)
    local pvo = CardVO.new(pid)
    return pvo
end

function CardVO:ctor(pid)
    self:setPid(pid)
end

function CardVO:setPid(pid)
    self.pid = pid
    self.color = math.floor(pid / 100)
    self.face = pid % 100
end

function CardVO:reset()
    self.pid = 0
    self.color = 0
    self.face = 0
end

function CardVO:compare(vo)
    if self.face > vo.face then
        return 1
    elseif vo.face > self.face then
        return -1
    else
        --方片<梅花<红桃<黑桃
        local colors = {3,4,1,2}
        local len = #colors

        local c1Index = 0
        local c2Index = 0

        for i=1,len do
            local tmp = colors[i]
            if tmp == self.color then c1Index = i end
            if tmp == vo.color then c2Index = i end
        end

        if c1Index > c2Index then
            return 1
        elseif c2Index > c1Index then
            return -1
        else
            return 0
        end
    end
end

function CardVO:getCharFace()
    if self.face < 11 then
        return tostring(self.face)
    elseif self.face == 11 then
        return "J"
    elseif self.face == 12 then
        return "Q"
    elseif self.face == 13 then
        return "K"
    elseif self.face == 14 then
        return "A"
    end
    
    return " "
end

function CardVO:toString()
    local s = "["

    if self.color == 1 then
        --s += "红桃 "
        s = s .. "Heart"
    elseif self.color == 2 then
        --s += "黑桃 "
        s = s .. "Spade"
    elseif self.color == 3 then
        --s += "方块 "
        s = s .. "Diamond"
    elseif self.color == 4 then
        --s += "梅花 "
        s = s .. "Club"
    end

    local char = self:getCharFace()
    s = s .. " "
    s = s .. char
    s = s .. "]"

    return s
end

function CardVO:toLongString()
    local s = "["

    if self.color == 1 then
        --s += "红桃 "
        s = s .. "Heart"
    elseif self.color == 2 then
        --s += "黑桃 "
        s = s .. "Spade"
    elseif self.color == 3 then
        --s += "方块 "
        s = s .. "Diamond"
    elseif self.color == 4 then
        --s += "梅花 "
        s = s .. "Club"
    end
    
    s = s .. self:getCharFace()

    s = s .. (" Pid:" .. self.pid .."]")
    
    return s
end