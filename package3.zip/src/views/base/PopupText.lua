PopupText = class("PopupText",function()
    return cc.Node:create()
end)

PopupText.__index = PopupText

PopupText.tips = {}

function PopupText.show(content,p)
    local tip = PopupText.create(content)
    local pp = p or GameData.curScene
    
    PopupText.addTip(tip)
    
    if pp then
        pp:addChild(tip)
    end
end

function PopupText.create(content)
    local item = PopupText.new(content)
    return item
end

function PopupText.addTip(tip)
    table.insert(PopupText.tips,#PopupText.tips+1,tip)
end

function PopupText.removeTip(tip)
    for i=1, #PopupText.tips do
	   if PopupText.tips[i]==tip then
            table.remove(PopupText.tips,i)
            break
	   end
    end
    tip:removeFromParent(true)
end

function PopupText:ctor(content)
    self.content = content
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()

    self:setPosition(self.visibleSize.width/2,self.visibleSize.height/2+50)
    
    self:setupViews()
end

function PopupText:setupViews()
    local size = cc.size(self.visibleSize.width,80)
    self.layout = ccui.Layout:create()
    self.layout:setPosition(-size.width/2,-size.height/2)
    self.layout:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    self.layout:setBackGroundColor(cc.c3b(0, 0, 0))
    self.layout:setBackGroundColorOpacity(150)
    self.layout:setContentSize(size)
    
    self:addChild(self.layout)
    
    self.text = ccui.Text:create()
    self.text:setColor(cc.c3b(255,228,1))
    self.text:setFontSize(30)
    self.text:setString(self.content)
    self:addChild(self.text)
    
    local delayTime = 1.5
    local moveTime = 2
    local moveDistance = 120
    local offset = 1
    
    local oactions = {}
    table.insert(oactions,#oactions+1,cc.DelayTime:create(delayTime+offset))
    table.insert(oactions,#oactions+1,cc.FadeOut:create(moveTime-offset))
    self.layout:runAction(cc.Sequence:create(oactions))
    oactions = {}
    table.insert(oactions,#oactions+1,cc.DelayTime:create(delayTime+offset))
    table.insert(oactions,#oactions+1,cc.FadeOut:create(moveTime-offset))
    self.text:runAction(cc.Sequence:create(oactions))
    
    local actions = {}
    local pos = cc.p(self:getPosition())
    pos.y = pos.y+moveDistance
    table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(moveTime,pos)))
    local spa = cc.Spawn:create(actions)
    
    local sactions = {}
    table.insert(sactions,#sactions+1,cc.DelayTime:create(delayTime))
    table.insert(sactions,#sactions+1,spa)
    local function completeHandler()
        PopupText.removeTip(self)
    end
    table.insert(sactions,#sactions+1,cc.CallFunc:create(completeHandler,{}))
    local seq = cc.Sequence:create(sactions)

    self:runAction(seq)
end