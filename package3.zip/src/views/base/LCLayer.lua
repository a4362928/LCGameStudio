LCLayer = class("LCLayer",function()
    return cc.Layer:create()
end)

LCLayer.__index = LCLayer

--LCLayer.widget = nil

function LCLayer.create()
    local scene = LCLayer.new()
    return scene
end

function LCLayer:ctor()
    --cclog("LCLayer:ctor()")
end

function LCLayer:removeEvents()
    --cclog("LCLayer:removeEvents")
    EventBus.getInst():unregisterEvents(self)
    
    ScriptHandlerMgr:getInstance():unregisterScriptHandler(self,cc.Handler.NODE)
    
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self)
end

function LCLayer:setButtonEnable(value,btns)
    for i=1,#btns do
        local btn = btns[i]
        btn:setTouchEnabled(value)
        btn:setBright(value)
    end
end

function LCLayer:setButtonVisible(value,btns)
    for i=1,#btns do
        local btn = btns[i]
        btn:setVisible(value)
    end
end

function LCLayer:delayCall(delay,handler,target,...)
    if not handler then
        return
    end
    
    target = target or self
    
    local function execHandler(t,params)
        if #params==0 then
            handler(target)
        elseif #params==1 then
            handler(target,params[1])
        elseif #params==2 then
            handler(target,params[1],params[2])
        elseif #params==3 then
            handler(target,params[1],params[2],params[3])
        elseif #params==4 then
            handler(target,params[1],params[2],params[3],params[4])
        elseif #params==5 then
            handler(target,params[1],params[2],params[3],params[4],params[5])
        end
    end
    
    local seq = cc.Sequence:create(cc.DelayTime:create(delay),cc.CallFunc:create(execHandler,{...}))
    self:runAction(seq)
end

function LCLayer:_onEnter()
    --cclog("LCLayer:onEnter")
end

function LCLayer:_onEnterTransitionDidFinish()
    --cclog("LCLayer:onEnterTransitionDidFinish")
end

function LCLayer:_onExitTransitionDidStart()
    --cclog("LCLayer:onExitTransitionDidStart")
end

function LCLayer:_onExit()
    --cclog("LCLayer:onExit")
    --取消注册所有事件
    self:removeEvents()
    Alert.clear()
end

function LCLayer:_cleanup()
    --cclog("LCLayer:cleanup")
    
end