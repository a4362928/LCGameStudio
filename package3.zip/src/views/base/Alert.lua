Alert = class("Alert")

Alert.__index = Alert

Alert.OK = 1
Alert.CANCEL = 2
Alert.MALL = 4

Alert._inst = nil
Alert.parent = nil
Alert.content = nil
Alert.title = nil
Alert.flag = nil
Alert.handler = nil
Alert.target = nil

Alert.BG = nil
Alert.closeBtn = nil
Alert.confirmBtn = nil
Alert.cancelBtn = nil
Alert.mallBtn = nil
Alert.contentText = nil
Alert.titleText = nil

--static
function Alert.show(p,content,title,flag,handler,target)
    if Alert._inst~=nil then
        Alert.hide(true)
        return
    end

    if Alert._inst == nil then
        Alert._inst = Alert.new()
    end

    if GameData.curScene~=nil then
        p = GameData.curScene
    end

    Alert._inst:_show(p,content,title,flag,handler,target)
end

--static
function Alert.hide(devent)
    --cclog("Alert:hide")
    devent = devent and devent or false
    if Alert._inst ~= nil then
        if devent and Alert._inst.handler then
            if Alert._inst.target then
                Alert._inst.handler(Alert._inst.target,Alert.CANCEL)
            else
                Alert._inst:handler(Alert.CANCEL)
            end
        end

        Alert._inst:dispose()
        Alert._inst = nil
    end
end

function Alert:ctor()
    --cclog("Alert:ctor")
    self:setupViews()
end

function Alert:setupViews()
    --cclog("Alert:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()
    --loading
    self.ul = cc.Layer:create()
    self.ul:setTouchEnabled(true)

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/alert/alert.csb")
    self.ul:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.confirmBtn = self.BG:getChildByName("confirmBtn")
    self.cancelBtn = self.BG:getChildByName("cancelBtn")
    self.mallBtn = self.BG:getChildByName("mallBtn")
    self.contentText = self.BG:getChildByName("contentText")
    self.titleText = self.BG:getChildByName("titleText")

    self:addListeners()
end

function Alert:addListeners()
    local function closeBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onCloseClick(sender)
        end
    end
    self.closeBtn:addTouchEventListener(closeBtnCallback)

    local function confirmBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onConfirmClick(sender)
        end
    end
    self.confirmBtn:addTouchEventListener(confirmBtnCallback)

    local function cancelBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onCancelClick(sender)
        end
    end
    self.cancelBtn:addTouchEventListener(cancelBtnCallback)

    local function mallBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onMallClick(sender)
        end
    end
    self.mallBtn:addTouchEventListener(mallBtnCallback)
end

function Alert:onCloseClick(sender)
    Alert.hide(true)
end

function Alert:onConfirmClick(sender)
    --cclog("Alert:onConfirmClick")
    if self.handler then
        if self.target then
            self.handler(self.target,Alert.OK)
        else
            self:handler(Alert.OK)
        end
    end

    Alert.hide(false)
end

function Alert:onCancelClick(sender)
    Alert.hide(true)
end

function Alert:onMallClick(sender)
    --cclog("Alert:onMallClick")
    if self.handler then
        if self.target then
            self.handler(self.target,Alert.MALL)
        else
            self:handler(Alert.MALL)
        end
    end

    Alert.hide(false)
end

function Alert:_show(p,content,title,flag,handler,target)
    --cclog("Alert:_show")
    self.parent = p
    self.content = content and content or ""
    self.title = title and title or "提示"
    self.flag = flag and flag or (Alert.OK+Alert.CANCEL)
    self.handler = handler
    self.target = target

    --("content:%s",self.content)
    --cclog("title:%s",self.title)
    --cclog("flag:%d",self.flag)

    self.confirmBtn:setVisible(false)
    self.cancelBtn:setVisible(false)
    self.mallBtn:setVisible(false)

    self.confirmBtn:setEnabled(false)
    self.cancelBtn:setEnabled(false)
    self.mallBtn:setEnabled(false)

    local tx,ty = self.mallBtn:getPosition()
    --ty = ty + 5
    local btns = {}

    if self.flag == (Alert.OK+Alert.CANCEL+Alert.MALL) then
        table.insert(btns,self.confirmBtn)
        table.insert(btns,self.mallBtn)
        table.insert(btns,self.cancelBtn)
    elseif self.flag == (Alert.OK+Alert.CANCEL) then
        table.insert(btns,self.confirmBtn)
        table.insert(btns,self.cancelBtn)
    elseif self.flag == (Alert.OK+Alert.MALL) then
        table.insert(btns,self.mallBtn)
        table.insert(btns,self.confirmBtn)
    elseif self.flag == (Alert.MALL+Alert.CANCEL) then
        table.insert(btns,self.mallBtn)
        table.insert(btns,self.cancelBtn)
    elseif self.flag == (Alert.OK) then
        table.insert(btns,self.confirmBtn)
    elseif self.flag == (Alert.CANCEL) then
        table.insert(btns,self.cancelBtn)
    elseif self.flag == (Alert.MALL) then
        table.insert(btns,self.mallBtn)
    end

    local offset = 120
    local len = #btns
    local tw = len*64+(len-1)*offset
    local bgSize = self.BG:getContentSize()

    for i=1,len do
        btns[i]:setVisible(true)
        btns[i]:setEnabled(true)
        local ttx = bgSize.width/2-tw/2+64/2+(i-1)*(64+offset)
        btns[i]:setPositionX(ttx)
        btns[i]:setPositionY(ty)
    end

    if self.titleText and self.title then
        self.titleText:setString(self.title)
    end

    if self.contentText and self.content then
        self.contentText:setString(self.content)
    end

    --PopupUtil:checkObject(target)
    --PopupUtil:checkObject(p)
    --PopupUtil:checkObject(self.ul)
    if p~=nil and self.ul~=nil then
        p:addChild(self.ul)
    end
end

function Alert:dispose()
    --cclog("Alert:dispose")
    if self.widget and self.widget:getParent() then
        self.widget:removeFromParent(true)
    end

    if self.ul and self.ul:getParent() then
        self.ul:removeFromParent(true)
    end
    
    self.clear()
end

function Alert.clear()
    local a = Alert._inst
    
    if a then
        --cclog("Alert.clear()")
        a.ul = nil
        a.widget = nil
        a.parent = nil
        a.content = nil
        a.title = nil
        a.flag = nil

        a.BG = nil
        a.closeBtn = nil
        a.confirmBtn = nil
        a.cancelBtn = nil
        a.mallBtn = nil
        a.contentText = nil
        a.titleText = nil
        a.handler = nil
        a.target = nil
    end
    
    Alert._inst = nil
end