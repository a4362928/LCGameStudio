SubWindow = class("SubWindow",function()
    return LCLayer.create()
end)

SubWindow.__index = SubWindow

SubWindow._parent = nil

function SubWindow.create()
    local window = SubWindow.new()
    return window
end

function SubWindow:_show(p)
    self._parent = p

    if p then
        p:addChild(self)
    end
end

function SubWindow:_hide()
    --所有注册取消事件
    self:removeEvents()
    self:dispose()

    if self._parent then
        self._parent:removeChild(self,true)
    end

    self._parent = nil
end

function SubWindow:dispose()

end