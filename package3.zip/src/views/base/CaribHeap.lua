require "views/base/CaribChip.lua"

CaribHeap = class("CaribHeap")

CaribHeap.__index = CaribHeap
CaribHeap.MOVE_RATE = 500
CaribHeap.bases = {5000,2000,1000,500,200,100,50,10,5,2,1}

function CaribHeap.create(p,rect,excs,value)
    local heap = CaribHeap.new(p,rect,excs,value)
    return heap
end

function CaribHeap:ctor(p,rect,excs,value)
    self.p = p
    self.rect = rect
    self.excs = excs
    self.chips = {}
    self.chipValue = 0
    self:setValue(value)
end

function CaribHeap:setValue(value)
    self:clear()
    
    self.chipValue = 0
    self:addValue(value)
end

function CaribHeap:addValue(value)
    self.chipValue = self.chipValue + value
    local arr = self.createChips(value)
    for i=1, #arr do
        local chip = arr[i]
        table.insert(self.chips,#self.chips+1,chip)
    end
    return arr
end

function CaribHeap:removeChip(chip)
    local find = false
    for i=1, #self.chips do
    	if chip == self.chips[i] then
    	   find = true
            self.chipValue = self.chipValue - chip.value
            --cclog("CaribHeap:removeChip chipValue:%d",self.chipValue)
    	   chip:release()
    	   chip:removeFromParent(true)
            table.remove(self.chips,i)
    	   break
    	end
    end
    
    if not find then
        chip:release()
        chip:removeFromParent(true)
    end
end

function CaribHeap:clear()
    if not self.chips then return end
    while #self.chips > 0 do
        local chip = self.chips[1]
        self:removeChip(chip)
    end
end

function CaribHeap.createChips(value)
    local ori = value
    local bases = CaribHeap.bases
    local arr = {}

    for i=1, #bases do
        local base = bases[i]
        local nums = value/base
        value = value%base
        for j=1, nums do
            local chip = CaribChip.create(base)
            chip:retain()
            table.insert(arr,#arr+1,chip)
        end
    end
    
    return arr
end

function CaribHeap:createRandomPos()
    local pos = cc.p(0,0)
    --math.randomseed(os.time())
    
    while true do
        local p = math.random(1,100)/100
        local tx = self.rect.x + p*self.rect.width
        p = math.random(1,1000)/1000
        local ty = self.rect.y + p*self.rect.height
        local b = true
        for i=1, #self.excs do
            local exc = self.excs[i]
            if tx > exc.x and tx < (exc.x+exc.width) and ty > exc.y and ty < (exc.y+exc.height) then
                b = false
            end
        end
        
        if b then
            pos.x = tx
            pos.y = ty
            break
        end
    end
    
    return pos
end

function CaribHeap:mergeFrom(value,from)
    local arr = self:addValue(value)
    for i=1, #arr do
        local chip = arr[i]
        chip:setPosition(from)
        self.p:addChild(chip)
        
        local actions = {}
        local to = self:createRandomPos()
        local dur = cc.pGetDistance(to,from)/CaribHeap.MOVE_RATE
        if dur<0.5 then dur=0.5 end
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(dur,to)))
        
        local seq = cc.Sequence:create(actions)
        chip:runAction(seq)
    end
end

function CaribHeap:subTo(values,to,compHandler)
    local bases = self.bases
    local arr = {}

    for i=1, #values do
        local value = values[i]
        for j=1, #bases do
            local base = bases[j]
            local nums = value/base
            value = value%base
            for j=1, nums do
                table.insert(arr,#arr+1,base)
            end
        end
    end
    
    local cs = {}
    for i=1, #arr do
        local c = arr[i]
        local chip = self:getChipByValue(c)
        if chip then
            chip.checked = true
            table.insert(cs,#cs+1,chip)
        end
    end
    
    for i=1, #cs do
        local chip = cs[i]
        local actions = {}
        local p = math.random(1,100)/100
        local from = cc.p(chip:getPosition())
        local dur = cc.pGetDistance(to,from)/CaribHeap.MOVE_RATE
        if dur<0.5 then dur=0.5 end
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.DelayTime:create(0.1*p)))
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(dur,to)))
        local function completeHandler(c)
            self:removeChip(c)
        end
        table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{chip}))
        if i==(#cs) then
            local function lastCompleteHandler()
                if compHandler then
                    compHandler()
                end
            end
            table.insert(actions,#actions+1,cc.CallFunc:create(lastCompleteHandler,{}))
        end

        local seq = cc.Sequence:create(actions)
        chip:runAction(seq)
    end
end

function CaribHeap:createTo(value,from,to)
    local chips = self.createChips(value)

    for i=1, #chips do
        local chip = chips[i]
        chip:setPosition(from)
        self.p:addChild(chip)
        
        local actions = {}
        local p = math.random(1,100)/100
        local dur = cc.pGetDistance(to,from)/CaribHeap.MOVE_RATE
        if dur<0.5 then dur=0.5 end
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.DelayTime:create(0.1*p)))
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(dur,to)))
        local function completeHandler(c)
            self:removeChip(c)
        end
        table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{chip}))

        local seq = cc.Sequence:create(actions)
        chip:runAction(seq)
    end
end

function CaribHeap:getChipByValue(value)
    for i=1, #self.chips do
        local chip = self.chips[i]
        if chip.value == value and not chip.checked then
            return chip
        end
    end
    return nil
end