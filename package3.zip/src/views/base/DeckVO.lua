require "views/base/CardVO.lua"

DeckVO = class("DeckVO")

DeckVO.__index = DeckVO

--DeckVO.type = nil
--DeckVO.vos = nil

function DeckVO.createWithVos(vos,type)
    local deck = DeckVO.new(vos,type)
    return deck
end

function DeckVO.createWithPids(pids,type)
    local vos = DeckVO.createVos(pids)
    return DeckVO.createWithVos(vos,type)
end

function DeckVO.create(type)
    return DeckVO.createWithVos(nil,type)
end

function DeckVO.createVos(pids)
    pids = pids or {}
    local vos = {}
    for i=1, #pids do
        local vo = CardVO.create(pids[i])
        table.insert(vos,#vos+1,vo)
    end
    return vos
end

function DeckVO.sortDeck(vos)
    local function sortFunc(a,b)
        if not a or not b then
            return false
        end
        local num = a:compare(b)
        if num > 0 then
            return true
        else
            return false
        end
        return false
    end

    table.sort(vos,sortFunc)
end

function DeckVO:ctor(vos,type)
    self.type = type
    if vos then
        self:setDeck(vos)
    end
end

function DeckVO:setType(type)
    self.type = type
end

function DeckVO:setDeck(vos,desc)
    desc = desc and desc or false
    self.vos = vos

    if desc then
        self.sortDeck(self.vos)
    end
end

function DeckVO:addVo(vo)
    if not vo then return end

    if not self.vos then
        self.vos = {}
    end
    
    table.insert(self.vos,#self.vos+1,vo)
end

function DeckVO:hasPid(pid)
    for i=1, #self.vos do
        local vo = self.vos[i]
        if vo.pid==pid then
            return true
        end
    end
    return false
end

function DeckVO:fillEmptyWithPids(pids)
    local vos = DeckVO.createVos(pids)
    self:fillEmptyWithVos(vos)
end

function DeckVO:fillEmptyWithVos(vos)
    for i=1, #vos do
        local vo = vos[i]
        local pid = vo.pid
        local empty = self:getNextEmpty()
        if empty and pid >= 102 then
            empty:setPid(pid)
        end
    end
end

function DeckVO:getNextEmpty()
    for i=1, #self.vos do
        local vo = self.vos[i]
        if vo.pid < 102 then
            return vo
        end
    end

    return nil
end

function DeckVO:getRatio()
    local ratio = 0

    if self:testRoyalFlush() then
        --皇家同花顺
        ratio = self.type==CaribDeck.TYPE_SOLO and 100 or 10
    elseif self:testStraightFlush() then
        --同花顺
        ratio = self.type==CaribDeck.TYPE_SOLO and 50 or 8
    elseif self:testFour() then
        --四条
        ratio = self.type==CaribDeck.TYPE_SOLO and 20 or 7
    elseif self:test32() then
        --葫芦
        ratio = self.type==CaribDeck.TYPE_SOLO and 7 or 6
    elseif self:testFlush() then
        --同花
        ratio = self.type==CaribDeck.TYPE_SOLO and 5 or 5
    elseif self:testStraight() then
        --顺子
        ratio = self.type==CaribDeck.TYPE_SOLO and 4 or 4
    elseif self:testThree() then
        --三条
        ratio = self.type==CaribDeck.TYPE_SOLO and 3 or 3
    elseif self:test2Pair() then
        --两对
        ratio = self.type==CaribDeck.TYPE_SOLO and 2 or 2
    elseif self:testPair() then
        --一对
        ratio = self.type==CaribDeck.TYPE_SOLO and 1 or 1
    end

    return ratio
end

function DeckVO:getPokeType(host)
    local type = -1
    if self:testRoyalFlush() then
        --皇家同花顺
        type = 9
    elseif self:testStraightFlush() then
        --同花顺
        type = 8
    elseif self:testFour() then
        --四条
        type = 7
    elseif self:test32() then
        --葫芦
        type = 6
    elseif self:testFlush() then
        --同花
        type = 5
    elseif self:testStraight() then
        --顺子
        type = 4
    elseif self:testThree() then
        --三条
        type = 3
    elseif self:test2Pair() then
        --两对
        type = 2
    elseif self:testPair() then
        --一对
        type = 1
    else
        if not host then
            type = 0
        else
            if self:testHighCard() then
                type = 0
            else
                type = -1
            end
        end
    end

    return type
end

function DeckVO:hasFace(face)
    for i=1, #self.vos do
        local vo = self.vos[i]
        if vo and vo.face == face then
            return true
        end
    end
    return false
end

function DeckVO:getFaces(bDesc)
    local arr = {}
    for i=1, #self.vos do
        local vo = self.vos[i]
        table.insert(arr,#arr+1,tonumber(vo.face))
    end
    
    if bDesc then
        local function sortFunc(a,b)
            if a > b then
                return true
            end
            return false
        end
        table.sort(arr,sortFunc)
    end
    
    return arr
end

function DeckVO:getClone(bDesc)
    local clone = {}
    for i=1, #self.vos do
        table.insert(clone,#clone+1,self.vos[i])
    end

    if bDesc then
        self.sortDeck(clone)
    end

    return clone
end

function DeckVO:compare(vo,host1,host2)
    --判断筹码归属
    if host2 and vo:testUnAK() then
        --对家庄家,不成局
        return 1
    elseif host1 and self:testUnAK() then
        --自己庄家,不成局
        return -1
    else
        local r1 = self:getRatio()
        local r2 = vo:getRatio()
        if r1 > 0 and r2 > 0 then
            if r1 > r2 then
                return 1
            elseif r2 > r1 then
                return -1
            else
                return self:compare2(vo)
            end
        elseif r1 > 0 and r2 == 0 then
            return 1
        elseif r1 == 0 and r2 > 0 then
            return -1
        elseif r1 == 0 and r2 == 0 then
            return self:compare1(vo)
        else
            return self:compare1(vo)
        end
    end
end

function DeckVO:compare1(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    for i=1,#cloneThis do 
        local tmp1 = cloneThis[i]
        local tmp2 = cloneThat[i]
        local v = tmp1:compare(tmp2)
        if v ~= 0 then
            return v
        end
    end
    return 0
end

function DeckVO:compare2(vo)
    local r = vo:getRatio()
    if self.type == CaribDeck.TYPE_SOLO then
        --皇家同花顺
        if r == 100 then
            return self:compareRoyalFlush(vo)
                --同花顺
        elseif r == 50 then
            return self:compareStraightFlush(vo)
                --四条
        elseif r == 20 then
            return self:compareFour(vo)
                --葫芦
        elseif r == 7 then
            return self:compare32(vo)
                --同花
        elseif r == 5 then
            return self:compareFlush(vo)
                --顺子
        elseif r == 4 then
            return self:compareStraight(vo)
                --三条
        elseif r == 3 then
            return self:compareThree(vo)
                --两对
        elseif r == 2 then
            return self:compare2Pair(vo)
                --一对
        elseif r == 1 then
            return self:comparePair(vo)
        end
    else
        --皇家同花顺
        if r == 10 then
            return self:compareRoyalFlush(vo)
                --同花顺
        elseif r == 8 then
            return self:compareStraightFlush(vo)
                --四条
        elseif r == 7 then
            return self:compareFour(vo)
                --葫芦
        elseif r == 6 then
            return self:compare32(vo)
                --同花
        elseif r == 5 then
            return self:compareFlush(vo)
                --顺子
        elseif r == 4 then
            return self:compareStraight(vo)
                --三条
        elseif r == 3 then
            return self:compareThree(vo)
                --两对
        elseif r == 2 then
            return self:compare2Pair(vo)
                --一对
        elseif r == 1 then
            return self:comparePair(vo)
        end
    end

    return 0
end

function DeckVO:compare2Group(arr1,arr2)
    self.sortDeck(arr1)
    self.sortDeck(arr2)

    if #arr1 == #arr2 then
        for i=1, #arr1 do
            local tmp1 = arr1[i]
            local tmp2 = arr2[i]
            local b = tmp1:compare(tmp2)
            if b~=0 then
                return b
            end
        end

        return 0
    end

    return -2
end

function DeckVO:group()
    local map = {}

    for i=1, #self.vos do
        local vo = self.vos[i]
        local key = tonumber(vo.face)
        local v = nil
        if not map[key] then
            v = {}
            map[key] = v
        else
            v = map[key]
        end

        table.insert(v,#v+1,vo)
    end

    return map
end

function DeckVO:getGroupArrays(dict)
    local valueArr = {}
    for k,v in pairs(dict) do
        table.insert(valueArr,#valueArr+1,v)
    end
    return valueArr
end

function DeckVO:getGroupArrayByIndex(dict,index)
    local valueArr = self:getGroupArrays(dict)

    local iindex = index+1
    if iindex < 1 or iindex > #valueArr then
        return nil
    end

    local v = valueArr[iindex]

    return v
end

function DeckVO:getArrayPokeByIndex(arr,index)
    local ii = index+1
    local vo = arr[ii]
    return vo
end

function DeckVO:testUnAK()
    if self:getRatio() == 0 and not self:testHighCard() then
        return true
    end
    return false
end

function DeckVO:compareUnAK()
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    for i=1, #cloneThis do
        local tmp1 = cloneThis[i]
        local tmp2 = cloneThat[i]
        local v = tmp1:compare(tmp2)
        if v ~= 0 then
            return v
        end
    end
    return 0
end

function DeckVO:testHighCard()
    local groupMap = self:group()
    if self.mapTableLen(groupMap) == 5 then
        if self:hasFace(13) and self:hasFace(14) then
            return true
        end
    end
    return false
end

function DeckVO:compareHighCard(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    for i=1, #cloneThis do
        local tmp1 = cloneThis[i]
        local tmp2 = cloneThat[i]
        local v = tmp1:compare(tmp2)
        if v ~= 0 then
            return v
        end
    end
    return 0
end

function DeckVO.tableConcat(ori,arr)
    for i=1, #arr do
    	table.insert(ori,#ori+1,arr[i])
    end
end

function DeckVO.mapTableLen(arr)
    local len = 0
    for k, v in pairs(arr) do
        len = len + 1
    end
    return len
end

function DeckVO:testPair()
    local groupMap = self:group()
    local len = self.mapTableLen(groupMap)
    if self.mapTableLen(groupMap) == 4 then
        if #self:getGroupArrayByIndex(groupMap,0) == 2 or #self:getGroupArrayByIndex(groupMap,1) == 2 or #self:getGroupArrayByIndex(groupMap,2) == 2 or #self:getGroupArrayByIndex(groupMap,3) == 2 then
            return true
        end
    end
    return false
end

function DeckVO:comparePair(vo)
    local groupThis = self:group()
    local groupThat = vo:group()
    local moreVThis = nil
    local lessVThis = nil
    local moreVThat = nil
    local lessVThat = nil
    
    if self.mapTableLen(groupThis) == 4 and self.mapTableLen(groupThat) == 4 then
        if #self:getGroupArrayByIndex(groupThis,0) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            lessVThis = self:getGroupArrayByIndex(groupThis,1)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,2))
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,3))
        elseif #self:getGroupArrayByIndex(groupThis,1) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,1)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,2))
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,3))
        elseif #self:getGroupArrayByIndex(groupThis,2) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,2)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,1))
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,3))
        elseif #self:getGroupArrayByIndex(groupThis,3) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,3)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,1))
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,2))
        end

        if #self:getGroupArrayByIndex(groupThat,0) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            lessVThat = self:getGroupArrayByIndex(groupThat,1)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,2))
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,3))
        elseif #self:getGroupArrayByIndex(groupThat,1) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,1)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,2))
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,3))
        elseif #self:getGroupArrayByIndex(groupThat,2) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,2)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,1))
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,3))
        elseif #self:getGroupArrayByIndex(groupThat,3) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,3)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,1))
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,2))
        end

        self.sortDeck(moreVThis)
        self.sortDeck(moreVThat)
        --先比较1对
        local value = -2
        if self:getArrayPokeByIndex(moreVThis,0).face == self:getArrayPokeByIndex(moreVThat,0).face then
            self.sortDeck(lessVThis)
            self.sortDeck(lessVThat)
            if self:getArrayPokeByIndex(lessVThis,0).face == self:getArrayPokeByIndex(lessVThat,0).face then
                if self:getArrayPokeByIndex(lessVThis,1).face == self:getArrayPokeByIndex(lessVThat,1).face then
                    if self:getArrayPokeByIndex(lessVThis,2).face == self:getArrayPokeByIndex(lessVThat,2).face then
                        return self:compare2Group(moreVThis,moreVThat)
                    else
                        if self:getArrayPokeByIndex(lessVThis,2).face > self:getArrayPokeByIndex(lessVThat,2).face then
                            return 1
                        else
                            return -1
                        end
                    end
                else
                    if self:getArrayPokeByIndex(lessVThis,1).face > self:getArrayPokeByIndex(lessVThat,1).face then
                        return 1
                    else
                        return -1
                    end
                end
            else
                if self:getArrayPokeByIndex(lessVThis,0).face > self:getArrayPokeByIndex(lessVThat,0).face then
                    return 1
                else
                    return -1
                end
            end    
        else
            if self:getArrayPokeByIndex(moreVThis,0).face > self:getArrayPokeByIndex(moreVThat,0).face then
                return 1
            else
                return -1
            end
        end
    end
    return -2
end

--两对
function DeckVO:test2Pair()
    local groupMap = self:group()
    if self.mapTableLen(groupMap) == 3 then
        if #self:getGroupArrayByIndex(groupMap,0) == 2 and #self:getGroupArrayByIndex(groupMap,1) == 2 then
            return true
        end
        if #self:getGroupArrayByIndex(groupMap,0) == 2 and #self:getGroupArrayByIndex(groupMap,2) == 2 then
            return true
        end
        if #self:getGroupArrayByIndex(groupMap,1) == 2 and #self:getGroupArrayByIndex(groupMap,2) == 2 then
            return true
        end
    end
    return false
end

function DeckVO:compare2Pair(vo)
    local groupThis = self:group()
    local groupThat = vo:group()
    local moreVThis = nil
    local lessVThis = nil
    local moreVThat = nil
    local lessVThat = nil
    if self.mapTableLen(groupThis) == 3 and self.mapTableLen(groupThat) == 3 then
        if #self:getGroupArrayByIndex(groupThis,0) == 2 and #self:getGroupArrayByIndex(groupThis,1) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(moreVThis,self:getGroupArrayByIndex(groupThis,1))
            lessVThis = self:getGroupArrayByIndex(groupThis,2)
        elseif #self:getGroupArrayByIndex(groupThis,0) == 2 and #self:getGroupArrayByIndex(groupThis,2) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(moreVThis,self:getGroupArrayByIndex(groupThis,2))
            lessVThis = self:getGroupArrayByIndex(groupThis,1)
        elseif #self:getGroupArrayByIndex(groupThis,1) == 2 and #self:getGroupArrayByIndex(groupThis,2) == 2 then
            moreVThis = self:getGroupArrayByIndex(groupThis,1)
            self.tableConcat(moreVThis,self:getGroupArrayByIndex(groupThis,2))
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
        end

        if #self:getGroupArrayByIndex(groupThat,0) == 2 and #self:getGroupArrayByIndex(groupThat,1) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(moreVThat,self:getGroupArrayByIndex(groupThat,1))
            lessVThat = self:getGroupArrayByIndex(groupThat,2)
        elseif #self:getGroupArrayByIndex(groupThat,0) == 2 and #self:getGroupArrayByIndex(groupThat,2) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(moreVThat,self:getGroupArrayByIndex(groupThat,2))
            lessVThat = self:getGroupArrayByIndex(groupThat,1)
        elseif #self:getGroupArrayByIndex(groupThat,1) == 2 and #self:getGroupArrayByIndex(groupThat,2) == 2 then
            moreVThat = self:getGroupArrayByIndex(groupThat,1)
            self.tableConcat(moreVThat,self:getGroupArrayByIndex(groupThat,2))
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
        end

        --先比较2对
        local value = -2
        self.sortDeck(moreVThis)
        self.sortDeck(moreVThat)

        if self:getArrayPokeByIndex(moreVThis,0).face == self:getArrayPokeByIndex(moreVThat,0).face then
            if self:getArrayPokeByIndex(moreVThis,2).face == self:getArrayPokeByIndex(moreVThat,2).face then
                if self:getArrayPokeByIndex(lessVThis,0).face == self:getArrayPokeByIndex(lessVThat,0).face then
                    return self:compare2Group(moreVThis,moreVThat)
                else
                    if self:getArrayPokeByIndex(lessVThis,0).face > self:getArrayPokeByIndex(lessVThat,0).face then
                        return 1
                    end
                    return -1
                end
            else
                if self:getArrayPokeByIndex(moreVThis,2).face > self:getArrayPokeByIndex(moreVThat,2).face then
                    return 1
                end
                return -1
            end
        else
            if self:getArrayPokeByIndex(moreVThis,0).face > self:getArrayPokeByIndex(moreVThat,0).face then
                return 1
            end
            return -1
        end
    end
    return -2
end

--三条
function DeckVO:testThree()
    local groupMap = self:group()
    if self.mapTableLen(groupMap) == 3 then
        if #self:getGroupArrayByIndex(groupMap,0) == 3 or #self:getGroupArrayByIndex(groupMap,1) == 3 or #self:getGroupArrayByIndex(groupMap,2) == 3 then
            return true
        end
    end
    return false
end

function DeckVO:compareThree(vo)
    local groupThis = self:group()
    local groupThat = vo:group()
    local moreVThis = nil
    local lessVThis = nil
    local moreVThat = nil
    local lessVThat = nil
    if self.mapTableLen(groupThis) == 3 and self.mapTableLen(groupThat) == 3 then
        --var arrThis:Array = groupThis.toArray()
        if #self:getGroupArrayByIndex(groupThis,0) == 3 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            lessVThis = self:getGroupArrayByIndex(groupThis,1)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,2))
        elseif #self:getGroupArrayByIndex(groupThis,1) == 3 then
            moreVThis = self:getGroupArrayByIndex(groupThis,1)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,2))
        elseif #self:getGroupArrayByIndex(groupThis,2) == 3 then
            moreVThis = self:getGroupArrayByIndex(groupThis,2)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
            self.tableConcat(lessVThis,self:getGroupArrayByIndex(groupThis,1))
        end

        --var arrThat:Array = groupThat.toArray()
        if #self:getGroupArrayByIndex(groupThat,0) == 3 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            lessVThat = self:getGroupArrayByIndex(groupThat,1)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,2))
        elseif #self:getGroupArrayByIndex(groupThat,1) == 3 then
            moreVThat = self:getGroupArrayByIndex(groupThat,1)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,2))
        elseif #self:getGroupArrayByIndex(groupThat,2) == 3 then
            moreVThat = self:getGroupArrayByIndex(groupThat,2)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
            self.tableConcat(lessVThat,self:getGroupArrayByIndex(groupThat,1))
        end

        self.sortDeck(moreVThis)
        self.sortDeck(moreVThat)
        --先比较3张
        local value = -2
        if self:getArrayPokeByIndex(moreVThis,0).face == self:getArrayPokeByIndex(moreVThat,0).face then
            self.sortDeck(lessVThis)
            self.sortDeck(lessVThat)
            if self:getArrayPokeByIndex(lessVThis,0).face == self:getArrayPokeByIndex(lessVThat,0).face then
                if self:getArrayPokeByIndex(lessVThis,1).face == self:getArrayPokeByIndex(lessVThat,1).face then
                    return self:compare2Group(lessVThis,lessVThat)
                else
                    if self:getArrayPokeByIndex(lessVThis,1).face > self:getArrayPokeByIndex(lessVThat,1).face then
                        return 1
                    else 
                        return -1
                    end
                end
            else
                if self:getArrayPokeByIndex(lessVThis,0).face > self:getArrayPokeByIndex(lessVThat,0).face then
                    return 1
                else
                    return -1
                end
            end
        else
            if self:getArrayPokeByIndex(moreVThis,0).face > self:getArrayPokeByIndex(moreVThat,0).face then
                return 1
            else
                return -1
                end
        end
    end
    return -2
end

--顺子
function DeckVO:testStraight()
    local arr = self:getFaces(true)

    for i = 2,#arr do 
        local f1 = arr[i-1]
        local f2 = arr[i]
        local id = f1
        local next = f2
        if math.abs(id-next) ~= 1 then
            return false
        end
    end

    if #arr == 5 then
        return true
    end

    return false
end

function DeckVO:compareStraight(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    return self:compare2Group(cloneThis,cloneThat)
end

--同花
function DeckVO:testFlush()
    local color = self:getArrayPokeByIndex(self.vos,0).color
    for i=0, #self.vos-1 do
    	if self:getArrayPokeByIndex(self.vos,i).color ~= color then
    	   return false
	   end
    end

    if #self.vos == 5 then
        return true
    end

    return false
end

function DeckVO:compareFlush(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    return self:compare2Group(cloneThis,cloneThat)
end

--葫芦
function DeckVO:test32()
    local groupMap = self:group()
    if self.mapTableLen(groupMap) == 2 then
        if #self:getGroupArrayByIndex(groupMap,0) == 2 and #self:getGroupArrayByIndex(groupMap,1) == 3 then
            return true
        end
        if #self:getGroupArrayByIndex(groupMap,0) == 3 and #self:getGroupArrayByIndex(groupMap,1) == 2 then
            return true
        end
    end
    return false
end

function DeckVO:compare32(vo)
    local groupThis = self:group()
    local groupThat = vo:group()
    local moreVThis = nil
    local lessVThis = nil
    local moreVThat = nil
    local lessVThat = nil
    if self.mapTableLen(groupThis) == 2 and self.mapTableLen(groupThat) == 2 then
        --var arrThis:Array = groupThis.toArray()
        if #self:getGroupArrayByIndex(groupThis,0) == 3 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            lessVThis = self:getGroupArrayByIndex(groupThis,1)
        elseif #self:getGroupArrayByIndex(groupThis,1) == 3 then
            moreVThis = self:getGroupArrayByIndex(groupThis,1)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
        end

        --var arrThat:Array = groupThat.toArray()
        if #self:getGroupArrayByIndex(groupThat,0) == 3 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            lessVThat = self:getGroupArrayByIndex(groupThat,1)
        elseif #self:getGroupArrayByIndex(groupThat,1) == 3 then
            moreVThat = self:getGroupArrayByIndex(groupThat,1)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
        end

        self.sortDeck(moreVThis)
        self.sortDeck(moreVThat)
        --比较3张
        local value = -2
        if self:getArrayPokeByIndex(moreVThis,0).face == self:getArrayPokeByIndex(moreVThat,0).face then
            --比较1对
            if self:getArrayPokeByIndex(lessVThis,0).face == self:getArrayPokeByIndex(lessVThat,0).face then
                local b = self:compare2Group(moreVThis,moreVThat)
                if b~=0 then
                    return b
                end
                b = self:compare2Group(lessVThis,lessVThat)
                if b~=0 then
                    return b
                end
                return self:compare2Group(moreVThis,moreVThat)
            else
                if self:getArrayPokeByIndex(lessVThis,0).face > self:getArrayPokeByIndex(lessVThat,0).face then
                    return 1
                end
                return -1
            end
        else
            if self:getArrayPokeByIndex(moreVThis,0).face > self:getArrayPokeByIndex(moreVThat,0).face then
                return 1
            else
                return -1
            end
        end
    end
    return -2
end

--四条
function DeckVO:testFour()
    local groupMap = self:group()
    if self.mapTableLen(groupMap) == 2 then
        if #self:getGroupArrayByIndex(groupMap,0) == 1 and #self:getGroupArrayByIndex(groupMap,1) == 4 then
            return true
        end
        if #self:getGroupArrayByIndex(groupMap,0) == 4 and #self:getGroupArrayByIndex(groupMap,1) == 1 then
            return true
        end
    end
    return false
end

function DeckVO:compareFour(vo)
    local groupThis = self:group()
    local groupThat = vo:group()
    local moreVThis = nil
    local lessVThis = nil
    local moreVThat = nil
    local lessVThat = nil
    if self.mapTableLen(groupThis) == 2 and self.mapTableLen(groupThat) == 2 then
        --var arrThis:Array = groupThis.toArray()
        if #self:getGroupArrayByIndex(groupThis,0) == 4 then
            moreVThis = self:getGroupArrayByIndex(groupThis,0)
            lessVThis = self:getGroupArrayByIndex(groupThis,1)
        elseif #self:getGroupArrayByIndex(groupThis,1) == 4 then
            moreVThis = self:getGroupArrayByIndex(groupThis,1)
            lessVThis = self:getGroupArrayByIndex(groupThis,0)
        end

        --var arrThat:Array = groupThat.toArray()
        if #self:getGroupArrayByIndex(groupThat,0) == 4 then
            moreVThat = self:getGroupArrayByIndex(groupThat,0)
            lessVThat = self:getGroupArrayByIndex(groupThat,1)
        elseif #self:getGroupArrayByIndex(groupThat,0) == 4 then
            moreVThat = self:getGroupArrayByIndex(groupThat,1)
            lessVThat = self:getGroupArrayByIndex(groupThat,0)
        end

        self.sortDeck(moreVThis)
        self.sortDeck(moreVThat)
        --比较4条
        local value = -2
        if self:getArrayPokeByIndex(moreVThis,0).face == self:getArrayPokeByIndex(moreVThat,0).face then
            --4条牌面一样大,则先比较另外1张大小
            if self:getArrayPokeByIndex(lessVThis,0).face == self:getArrayPokeByIndex(lessVThat,0).face then
                local b = self:compare2Group(moreVThis,moreVThat)
                if b~=0 then
                    return b
                end
                b = self:compare2Group(lessVThis,lessVThat)
                if b~=0 then
                    return b
                end
                --1张相等,则再比较4条大小,包括花色
                return self:compare2Group(moreVThis,moreVThat)
            else
                if self:getArrayPokeByIndex(lessVThis,0).face > self:getArrayPokeByIndex(lessVThat,0).face then
                    return 1
                end
                return -1
            end
        else
            if self:getArrayPokeByIndex(moreVThis,0).face > self:getArrayPokeByIndex(moreVThat,0).face then
                return 1
            else
                return -1
            end
        end
    end
    return -2
end

--同花顺
function DeckVO:testStraightFlush()
    if self:testFlush() and self:testStraight() then
        return true
    end
    return false
end

function DeckVO:compareStraightFlush(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    return self:getArrayPokeByIndex(cloneThis,0):compare(self:getArrayPokeByIndex(cloneThat,0))
end

--皇家同花顺
function DeckVO:testRoyalFlush()
    if self:testFlush() and self:testStraight() then
        if self:hasFace(14) then
            return true
        end
    end
    return false
end

function DeckVO:compareRoyalFlush(vo)
    local cloneThis = self:getClone(true)
    local cloneThat = vo:getClone(true)
    return self:getArrayPokeByIndex(cloneThis,0):compare(self:getArrayPokeByIndex(cloneThat,0))
end

function DeckVO:getDeckType(host)
    local str = ""
    if self:testRoyalFlush() then
        --皇家同花顺
        str = "皇家同花顺"
    elseif self:testStraightFlush() then
        --同花顺
        str = "同花顺"
    elseif self:testFour() then
        --四条
        str = "四条"
    elseif self:test32() then
        --葫芦
        str = "葫芦"
    elseif self:testFlush() then
        --同花
        str = "同花"
    elseif self:testStraight() then
        --顺子
        str = "顺子"
    elseif  self:testThree() then
        --三条
        str = "三条"
    elseif self:test2Pair() then
        --两对
        str = "两对"
    elseif self:testPair() then
        --一对
        str = "一对"
    elseif self:testUnAK() then
        --无AK
        if not host then
            str = "散牌"
        else
            if self:testHighCard() then
                str = "散牌"
            else
                str = "庄家不成局"
            end
        end
    else
        --有AK
        str = "散牌"
    end

    return str
end

function DeckVO:toDeckString(host)
    local str = self:getDeckType(host)
    return str
end

function DeckVO:toString()
    local str = self:toDeckString()

    str = str.." -> [ "
    for i=1, #self.vos do
    	local card = self.vos[i]
        str = str..card:toString()
        if i < #self.vos then
            str = str..","
        end
    end
    str = str.." ]"

    return str
end

function DeckVO:clear()
    self.vos = nil
end

function DeckVO:dispose()
    self:clear()
end