ScrollNumberDigit = class("ScrollNumberDigit",function()
    return cc.Node:create()
end)

ScrollNumberDigit.__index = ScrollNumberDigit

function ScrollNumberDigit.create(num,owner)
    local item = ScrollNumberDigit.new(num,owner)
    return item
end

function ScrollNumberDigit:ctor(num,owner)
    self.num = num
    self.owner = owner
    self.buffers = {}
    self.uses = {}
    
    self:setNum(num)
end

function ScrollNumberDigit:setNum(num)
    while #self.uses>0 do
        local d = self:getUse()
        self:pushBuffer(d)
    end
    
    local d = self:getBuffer(num)
    d:setPosition(0,0)
    self:pushUse(d)
end

function ScrollNumberDigit:tweenNum(num,dur)
    local d = self:getBuffer(num)
    d:setPosition(0,0)
end

function ScrollNumberDigit:pushUse(s)
    local find = false
    for i=1, #self.uses do
        if self.uses[i]==s then
            find = true
            break
        end
    end

    if find==false then
        table.insert(self.uses,#self.uses+1,s)
    end
end

function ScrollNumberDigit:getUse()
    local s = nil
    if #self.uses>0 then
        s = self.uses[1]
        table.remove(self.uses,1)
    end

    return s
end

function ScrollNumberDigit:getBuffer(num)
    local s = nil
    if #self.buffers>0 then
        s = self.buffers[1]
        s:setTexture(self:getNumStr(num))
        table.remove(self.buffers,1)
    else
        s = cc.Sprite:create(self:getNumStr(num))
        self:addChild(s)
    end
    
    return s
end

function ScrollNumberDigit:pushBuffer(s)
    local find = false
    for i=1, #self.buffers do
    	if self.buffers[i]==s then
    	   find = true
    	   break
    	end
    end
    
    if find==false then
        table.insert(self.buffers,#self.buffers+1,s)
    end
end

function ScrollNumberDigit:getNumStr(num)
    local strs = self.owner.strs
    local str = strs[2]
    if num>0 then
        str = strs[2+num]
    end
    return str
end