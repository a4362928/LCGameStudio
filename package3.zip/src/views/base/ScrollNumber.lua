require "views/base/ScrollNumberDigit.lua"

ScrollNumber = class("ScrollNumber",function()
    return cc.ClippingNode:create(nil)
end)

ScrollNumber.__index = ScrollNumber

function ScrollNumber.create(num,digit,strs,digiSize)
    local item = ScrollNumber.new(num,digit,strs,digiSize)
    return item
end

function ScrollNumber:ctor(num,digit,strs,digiSize)
    self.num = num
    self.digit = digit
    self.strs = strs
    self.digiSize = digiSize
    self.digits = {}
    
    local mask = cc.Sprite:create(strs[1])
    self:setStencil(mask)
    self:setContentSize(mask:getContentSize())
    
    for i=1, digit do
        local d = ScrollNumberDigit.create(0,self)
        self:addChild(d)

        table.insert(self.digits,#self.digits+1,d)
    end
    
    self:setNum(num)
end

function ScrollNumber:setNum(num)
    num = math.abs(num)
    local str = tostring(num)
    local nums = {}
    for i=1, string.len(str) do
        local d = string.sub(str,i,i)
        d = tonumber(d)
        table.insert(nums,#nums+1,d)
    end

    while #nums>#self.digits do
        table.remove(nums,1)
    end

    while #nums<#self.digits do
        table.insert(nums,1,0)
    end

    for i=1, #self.digits do
        local d = self.digits[i]
        local n = nums[i]
        d:setNum(n)
    end
end

function ScrollNumber:setEdges(gap,offset)
    local size = self:getContentSize()
    local dw = size.width/self.digit
    for i=1, #self.digits do
        local d = self.digits[i]
        d:setPosition(offset+(i-1)*(self.digiSize.width+gap),0)
    end
end