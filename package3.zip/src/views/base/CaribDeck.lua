require "views/base/DeckVO.lua"

CaribDeck = class("CaribDeck")

CaribDeck.__index = CaribDeck

CaribDeck.TYPE_SOLO = 1
CaribDeck.TYPE_MULIT = 2

CaribDeck.EVENT_FLIPS_COMPLETE = "event_flips_complete"
CaribDeck.EVENT_FLIPS_BACK_COMPLETE = "event_flips_back_complete"
CaribDeck.EVENT_TIDY_MID = "event_tidy_mid"
CaribDeck.EVENT_TIDY_COMPLETE = "event_tidy_complete"

--CaribDeck.dvo = nil
--CaribDeck.back = nil
--CaribDeck.flipEnabled = nil
--CaribDeck.size = nil
--CaribDeck.gtype = nil

--CaribDeck.cards = {}

--CaribDeck.autoDidy = false
--CaribDeck.fliping = false

function CaribDeck.createWithPids(pids,back,flipEnabled,size,gtype)
    local vos = DeckVO.createVos(pids)
    return CaribDeck.createWithVos(vos,back,flipEnabled,size,gtype)
end

function CaribDeck.createWithVos(vos,back,flipEnabled,size,gtype)
    local deck = CaribDeck.new(vos,back,flipEnabled,size,gtype)
    return deck
end

function CaribDeck.create(back,flipEnabled,size,gtype)
    local deck = CaribDeck.new(nil,back,flipEnabled,size,gtype)
    return deck
end

function CaribDeck.sortDeck(cards,desc)
    local function sortFunc(a,b)
        if not a or not b then
            return false
        end
        local avo = a.pvo
        local bvo = b.pvo
        if not avo or not bvo then
            return false
        end
        
        local num = avo:compare(bvo)
        if num > 0 then
            return true
        else
            return false
        end
        return false
    end

    table.sort(cards,sortFunc)
end

function CaribDeck:ctor(vos,back,flipEnabled,size,gtype)
    self.cards = {}
    self.autoDidy = false
    self.fliping = false
    
    self:setBack(back)
    self:setFlip(flipEnabled)
    self:setSize(size)
    self:setGType(gtype)
    
    EventBus.getInst():registerEvent(self,CaribCard.EVENT_FLIP_COMPLETE,self.onCardFlipComplete,false)
    EventBus.getInst():registerEvent(self,CaribCard.EVENT_FLIP_BACK_COMPLETE,self.onCardFlipBackComplete,false)
    
    if vos then
        self:setDeck(vos)
    end
end

--自动整理牌
function CaribDeck:onCardFlipComplete(eventName,data)
    local card = data[1]
    
    local index = self:getCardIndex(card)
    if index and index>0 and not self:hasUnfliped() then
        self:onCompleteFlip()
    end
end

function CaribDeck:onCardFlipBackComplete(eventName,data)
    local card = data[1]
    
    local index = self:getCardIndex(card)
    if index and index>0 and not self:hasFliped() then
        self:onCompleteFlipBack()
    end
end

function CaribDeck:setBack(back)
    self.back = back
end

function CaribDeck:setFlip(flipEnabled)
    self.flipEnabled = flipEnabled
    
    for i=1, #self.cards do
        self.cards[i]:setFlip(self.flipEnabled)
    end
end

function CaribDeck:setSize(size)
    self.size = size
end

function CaribDeck:setGType(gtype)
    self.gtype = gtype
end

function CaribDeck:setDeckWithPids(pids)
    local vos = DeckVO.createVos(pids)
    self:setDeck(vos)
end

function CaribDeck:setDeck(vos)
    if not self.dvo then
        self.dvo = DeckVO.createWithVos(vos,self.gtype)
    else
        self.dvo:setDeck(vos)
    end

    self:createCards()
end

function CaribDeck:createCards()
    self:clear()

    local vos = self.dvo.vos

    for i=1, #vos do
        local vo = vos[i]
        local card = CaribCard.createWithVo(vo,self.back,self.flipEnabled,self.size)
        table.insert(self.cards,#self.cards+1,card)
    end
end

--填充空白牌
function CaribDeck:fillEmptyWithPids(pids)
    if not self.dvo then return end
    
    local oris = pids
    pids = {}
    for i=1, #oris do
        local pid = oris[i]
        if not self.dvo:hasPid(pid) then
            table.insert(pids,#pids+1,pid)
        end
    end
    
    local index = 1
    local empty = self.dvo:getNextEmpty()
    while empty do
        if index>(#pids) then break end
        local pid = pids[index]
        empty:setPid(pid)
        empty = self.dvo:getNextEmpty()
        index = index + 1
    end
end

function CaribDeck:hasEmptyCard()
    if self.dvo then
        local empty = self.dvo:getNextEmpty()
        if empty~=nil then
            return true
        end
        return false
    end
    return true
end

function CaribDeck:addCard(card,back,flipEnabled)
    if not card then return end
    back = back and back or self.back
    flipEnabled = flipEnabled and flipEnabled or self.flipEnabled
    
    if not self.dvo then
        self.dvo = DeckVO.create(self.gtype)
    end
    self.dvo:addVo(card.pvo)
    
    card:setBack(back)
    card:setFlip(flipEnabled)
    table.insert(self.cards,#self.cards+1,card)
    
    if #self.cards > 5 then
        ccerror("牌组超过了5张牌")
    end
end

function CaribDeck:addPid(pid,back,flipEnabled)

end

function CaribDeck:addVo(vo,back,flipEnabled)

end

function CaribDeck:getCardIndex(card)
    for i=1, #self.cards do
    	if self.cards[i]==card then
    	   return i
    	end
    end
    return 0
end

function CaribDeck:addChildCards(p,pos,type)
    for i=1, #self.cards do
    	local card = self.cards[i]
    	card:setPosition(pos.x+i*70,pos.y)
    	p:addChild(card)
    end
end

function CaribDeck:removeChildCards()

end

function CaribDeck:setAutoTidy(autoDidy)
    self.autoDidy = autoDidy
end

function CaribDeck:flip(gap,delay,autoDidy)
    if self.fliping then
        return
    end
    
    self.fliping = true
    self:setAutoTidy(autoDidy)
    
    local function stepHandler(card)
        self:onStepFlip(card)
    end
    local function completeHandler(event)
        local card = event._usedata[1]
        if card == self.cards[#self.cards] then
            self:onCompleteFlip(card)
        end
    end
    for i=1, #self.cards do
    	local card = self.cards[i]
    	local actions = {}
    	local d = gap*(i-1)+delay
        table.insert(actions,#actions+1,cc.DelayTime:create(d))
        table.insert(actions,#actions+1,cc.CallFunc:create(stepHandler,{card}))
    	if i==#self.cards then
            --注册翻转完成事件
            --[[local listener = cc.EventListenerCustom:create(CaribCard.EVENT_FLIP_COMPLETE,completeHandler)
            local eventDispatcher = card:getEventDispatcher()
            eventDispatcher:addEventListenerWithFixedPriority(listener, 1)]]
    	end
    	
        local seq = cc.Sequence:create(actions)
        card:runAction(seq)
    end
end

function CaribDeck:onStepFlip(card)
    --cclog("onStepFlip")
    card:flip()
end

function CaribDeck:onCompleteFlip(card)
    cclog("onCompleteFlip")
    self.fliping = false
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribDeck.EVENT_FLIPS_COMPLETE)
    event._usedata = CaribCard.EVENT_FLIPS_COMPLETE--string.format("%d","")
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    EventBus.getInst():postEvent(CaribDeck.EVENT_FLIPS_COMPLETE,{self})
    
    if self.autoDidy then
        self:tidy()
    end
end

function CaribDeck:tidy(delay)
    --cclog("CaribDeck:tidy")
    local cardPos = {}
    local centerIndex = math.ceil(#self.cards/2)
    local centerCard = self.cards[centerIndex]
    local centerPos = cc.vertex2F(centerCard:getPositionX(),centerCard:getPositionY())
    local function midHandler()
        self:onTidyMid(cardPos)
    end
    for i=1, #self.cards do 
    	local actions = {}
        local card = self.cards[i]
        table.insert(cardPos,#cardPos+1,cc.vertex2F(card:getPositionX(),card:getPositionY()))
        table.insert(actions,#actions+1,cc.EaseBackIn:create(cc.MoveTo:create(0.4,centerPos)))
        if i == #self.cards then
            table.insert(actions,#actions+1,cc.DelayTime:create(0.1))
            table.insert(actions,#actions+1,cc.CallFunc:create(midHandler,{}))
        end
        local seq = cc.Sequence:create(actions)
        card:runAction(seq)
    end
end

function CaribDeck:onTidyMid(cardPos)
    --cclog("CaribDeck:onTidyMid")
    local centerIndex = math.ceil(#self.cards/2)
    local centerCard = self.cards[#self.cards]
    CaribDeck.sortDeck(self.cards)
    local function completeHandler()
        self:onTidyComplete()
    end
    for i=1, #self.cards do
        local pos = cardPos[i]
        local card = self.cards[i]
        if card:getParent() then
            card:setLocalZOrder(1000+i)
        end
        
        local actions = {}
        table.insert(actions,#actions+1,cc.DelayTime:create(0.1))
        table.insert(actions,#actions+1,cc.EaseBackOut:create(cc.MoveTo:create(0.4,pos)))
        if i==#self.cards then
            table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{}))
        end
        local seq = cc.Sequence:create(actions)
        card:runAction(seq)
    end
    
    --centerCard:setLocalZOrder(1000+#self.cards)
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribDeck.EVENT_TIDY_MID)
    event._usedata = CaribCard.EVENT_TIDY_MID--string.format("%d","")
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    EventBus.getInst():postEvent(CaribDeck.EVENT_TIDY_MID,{self})
end

function CaribDeck:onTidyComplete()
    --发送事件
    --[[local event = cc.EventCustom:new(CaribDeck.EVENT_TIDY_COMPLETE)
    event._usedata = CaribCard.EVENT_TIDY_COMPLETE--string.format("%d","")
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    EventBus.getInst():postEvent(CaribDeck.EVENT_TIDY_COMPLETE,{self})
end

function CaribDeck:flipBack(gap,delay)
    if self.fliping then
        return
    end

    self.fliping = true

    local function stepHandler(card)
        self:onStepFlipBack(card)
    end
    local function completeHandler(event)
        local card = event._usedata[1]
        if card == self.cards[#self.cards] then
            self:onCompleteFlipBack(card)
        end
    end
    for i=1, #self.cards do
        local card = self.cards[i]
        local actions = {}
        local d = gap*(i-1)+delay
        table.insert(actions,#actions+1,cc.DelayTime:create(d))
        table.insert(actions,#actions+1,cc.CallFunc:create(stepHandler,{card}))
        if i==#self.cards then
            --注册翻转完成事件
            --[[local listener = cc.EventListenerCustom:create(CaribCard.EVENT_FLIP_BACK_COMPLETE,completeHandler)
            local eventDispatcher = card:getEventDispatcher()
            eventDispatcher:addEventListenerWithFixedPriority(listener, 1)]]
        end
        local seq = cc.Sequence:create(actions)
        card:runAction(seq)
    end
end

function CaribDeck:onStepFlipBack(card)
    cclog("onStepFlipBack")
    card:flipBack()
end

function CaribDeck:onCompleteFlipBack(card)
    cclog("onCompleteFlipBack")

    self.fliping = false
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribDeck.EVENT_FLIPS_BACK_COMPLETE)
    event._usedata = CaribCard.EVENT_FLIPS_BACK_COMPLETE--string.format("%d","")
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    EventBus.getInst():postEvent(CaribDeck.EVENT_FLIPS_BACK_COMPLETE,{self})
end

function CaribDeck:hasUnfliped()
    for i=1, #self.cards do
    	local card = self.cards[i]
    	if card and card:isUnfliped() then
    	   return true
	   end
    end
    return false
end

function CaribDeck:hasFliped()
    for i=1, #self.cards do
        local card = self.cards[i]
        if card and not card:isUnfliped() then
           return true
       end
    end
    return false
end

function CaribDeck:clear()
    while #self.cards > 0 do
        local card = self.cards[1]
        card:release()
        card:removeFromParent(true)
        table.remove(self.cards,1)
    end
end

function CaribDeck:dispose()
    if self.dvo then
        self.dvo:dispose()
    end
    
    EventBus.getInst():unregisterEvents(self)
    
    self:clear()
end