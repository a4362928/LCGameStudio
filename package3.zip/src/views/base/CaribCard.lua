require "views/base/CardVO.lua"

CaribCard = class("CaribCard",function()
    return cc.Node:create()
end)

CaribCard.__index = CaribCard

CaribCard.COLOR_NONE = 0
CaribCard.COLOR_HEART = 1
CaribCard.COLOR_SPADE = 2
CaribCard.COLOR_DIAMOND = 3
CaribCard.COLOR_CLUB = 4

CaribCard.EVENT_FLIP_START = "event_flip_start"
CaribCard.EVENT_FLIP_MID = "event_flip_mid"
CaribCard.EVENT_FLIP_COMPLETE = "event_flip_complete"

CaribCard.EVENT_FLIP_BACK_START = "event_flip_back_start"
CaribCard.EVENT_FLIP_BACK_MID = "event_flip_back_mid"
CaribCard.EVENT_FLIP_BACK_COMPLETE = "event_flip_back_complete"

--CaribCard.pvo = nil
--CaribCard.back = nil
--CaribCard.flipEnabled = nil
--CaribCard.size = nil

--CaribCard.bg = nil
--CaribCard.face1Sprite = nil
--CaribCard.face2Sprite = nil
--CaribCard.colorSprite = nil

--牌是否正在翻转
--CaribCard.fliping = false

function CaribCard.createWithPid(pid,back,flipEnabled,size)
    local vo = CardVO.create(pid)
    return CaribCard.createWithVo(vo,back,flipEnabled,size)
end

function CaribCard.createWithVo(vo,back,flipEnabled,size)
    local card = CaribCard.new(vo,back,flipEnabled,size)
    card:retain()
    return card
end

function CaribCard:ctor(vo,back,flipEnabled,size)
    size = size or GameConstant.CARD_SIZE
    self.fliping = false

    self:setPvo(vo)
    self:setFlip(flipEnabled)
    self.size = size
    self:setBack(back)
end

--变灰色
function CaribCard:gray()
    if not self.back then return end
    
    if self.bg then
        self.bg:setSpriteFrame(cc.SpriteFrameCache:getInstance():getSpriteFrame("beimian-1.png"))
    end
end

function CaribCard:flip()
    if not self.back or self.fliping then
        return
    end
    if self.pvo and self.pvo.pid < 102 then
        return
    end
    
    self.fliping = true
    
    local function halfHandler()
        self:onHalfFlip()
    end
    local seq = cc.Sequence:create(cc.RotateBy:create(0.15,0.0,90.0),cc.CallFunc:create(halfHandler,{}))
    self:runAction(seq)
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_START)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_START,{self})
end

function CaribCard:onHalfFlip()
    --cclog("CaribCard:onHalfFlip")
    self:setBack(false)
    self:setScaleX(-1)

    local function allHandler()
        self:onAllFlip()
    end
    local seq = cc.Sequence:create(cc.RotateBy:create(0.15,0.0,90.0),cc.CallFunc:create(allHandler,{}))
    self:runAction(seq)
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_MID)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_MID,{self})
end

function CaribCard:onAllFlip()
    --cclog("CaribCard:onAllFlip")
    --self:setScaleX(-1)
    self:setRotation(0)
    self:setFlip(false)
    self.fliping = false
    
    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_COMPLETE)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_COMPLETE,{self})
end

function CaribCard:flipBack()
    if self.back or self.fliping then
        return
    end

    self.fliping = true

    local function halfHandler()
        self:onHalfFlipBack()
    end
    local seq = cc.Sequence:create(cc.RotateBy:create(0.15,0.0,-90.0),cc.CallFunc:create(halfHandler,{}))
    self:runAction(seq)

    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_BACK_START)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_BACK_START,{self})
end

function CaribCard:onHalfFlipBack()
    --cclog("CaribCard:onHalfFlipBack")
    self:setBack(true)
    self:setScaleX(1)

    local function allHandler()
        self:onAllFlipBack()
    end
    local seq = cc.Sequence:create(cc.RotateBy:create(0.15,0.0,-90.0),cc.CallFunc:create(allHandler,{}))
    self:runAction(seq)

    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_BACK_MID)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_BACK_MID,{self})
end

function CaribCard:onAllFlipBack()
    --cclog("CaribCard:onAllFlipBack")
    --self:setScaleX(-1)
    self:setRotation(0)
    self:setFlip(true)
    self.fliping = false

    --发送事件
    --[[local event = cc.EventCustom:new(CaribCard.EVENT_FLIP_BACK_COMPLETE)
    event._usedata = {self}--string.format("%d","")
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:dispatchEvent(event)]]
    
    EventBus:postEvent(CaribCard.EVENT_FLIP_BACK_COMPLETE,{self})
end

function CaribCard:isUnfliped()
    if self.back or self.fliping then
        return true
    end
    return false
end

function CaribCard:setPvo(pvo)
    self.pvo = pvo
end

function CaribCard:setPid(pid)
    if not self.pvo then
        self.pvo = CardVO.create(pid)
    else
        self.pvo:setPid(pid)
    end
end

function CaribCard:setFlip(flipEnabled)
    self.flipEnabled = flipEnabled

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self)
    
    if self.flipEnabled then
        local function onTouchBegan(touch,event)
            return self:onTouchBegan(touch,event)
        end

        local function onTouchMoved(touch,event)
            return self:onTouchMoved(touch,event)
        end

        local function onTouchEnded(touch,event)
            return self:onTouchEnded(touch,event)
        end

        local function onTouchCancelled(touch,event)
            return self:onTouchCancelled(touch,event)
        end

        local eventDispatcher = self:getEventDispatcher()
        local touchListener = cc.EventListenerTouchOneByOne:create()
        touchListener:setSwallowTouches(true)
        touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
        touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
        touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
        touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
        eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)
        --eventDispatcher:resumeEventListenersForTarget(self,true)
    else
        --eventDispatcher:pauseEventListenersForTarget(self,true)
    end
end

--缓动大小
function CaribCard:tweenSize(dur,size)
    self.oldSize = self.size
    self.newSize = size
    self.curTweenSizeDur = 0
    self.tweenSizeDur = dur
    local function tweenHandler(dt)
        self.curTweenSizeDur = self.curTweenSizeDur + dt
        local p = self.curTweenSizeDur/self.tweenSizeDur
        local ow = self.newSize.width-self.oldSize.width
        local tw = self.oldSize.width+ow*p
        local oh = self.newSize.height-self.oldSize.height
        local th = self.oldSize.height+oh*p
        local tSize = cc.size(tw,th)
        self:setSize(tSize)
        if p >= 1 then
            self:setSize(self.newSize)
            if self.sizeTweenScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.sizeTweenScheduler) end
        end
    end
    
    if self.sizeTweenScheduler then cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.sizeTweenScheduler) end
    self.sizeTweenScheduler = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tweenHandler, 0,false)
end



function CaribCard:setSize(size)
    self.size = size
    
    if self.back then
        local oriSize = self.bg:getContentSize()
        local sx = self.size.width/oriSize.width
        local sy = self.size.height/oriSize.height
        self.bg:setScale(sx,sy)
        self.bg:setAnchorPoint(0.5,0.5)

        self:setContentSize(self.bg:getContentSize())
    else
        local oriSize = self.bg:getContentSize()
        local sx = self.size.width/oriSize.width
        local sy = self.size.height/oriSize.height
        self.bg:setScale(sx,sy)
        self.bg:setAnchorPoint(0.5,0.5)

        self:setContentSize(self.bg:getContentSize())

        local bgSize = self.size
        local paddingL = 4
        local paddingR = 8
        local paddingT = 4
        local paddingB = 4

        if self.size.width >= GameConstant.CARD_SIZE.width then
            local biaozhun = 90
            self.face1Sprite:setAnchorPoint(0,1)
            self.face1Sprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
            self.face1Sprite:setPosition(-bgSize.width/2+paddingL,bgSize.height/2-paddingT)

            self.face2Sprite:setAnchorPoint(1,0)
            self.face2Sprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
            self.face2Sprite:setPosition(bgSize.width/2-paddingR+6,-bgSize.height/2+paddingB)

            biaozhun = 70
            self.colorSprite:setAnchorPoint(0.5,0.5)
            self.colorSprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
        else
            paddingL = 3
            paddingR = 3
            paddingT = 3
            paddingB = 3

            self.face1Sprite:setAnchorPoint(0,1)
            self.face1Sprite:setPosition(-bgSize.width/2+paddingL,bgSize.height/2-paddingT)

            self.colorSprite:setAnchorPoint(0.5,0.5)
            self.colorSprite:setScale(0.3)
            self.colorSprite:setPosition(bgSize.width/5-3,-bgSize.height/5)
        end
    end
end

function CaribCard:setBack(back)
    self.back = back
    
    self:clear()

    if self.back then
        self.bg = cc.Sprite:createWithSpriteFrameName(self:getPokeBackSpriteName())
        local oriSize = self.bg:getContentSize()
        local sx = self.size.width/oriSize.width
        local sy = self.size.height/oriSize.height
        self.bg:setScale(sx,sy)
        self.bg:setAnchorPoint(0.5,0.5)
        self:addChild(self.bg)
        
        self:setContentSize(self.bg:getContentSize())
    else
        self.bg = cc.Sprite:createWithSpriteFrameName(self:getPokeFrontSpriteName())
        local oriSize = self.bg:getContentSize()
        local sx = self.size.width/oriSize.width
        local sy = self.size.height/oriSize.height
        self.bg:setScale(sx,sy)
        self.bg:setAnchorPoint(0.5,0.5)
        self:addChild(self.bg)
        
        self:setContentSize(self.bg:getContentSize())
        
        local bgSize = self.size
        local paddingL = 4
        local paddingR = 8
        local paddingT = 4
        local paddingB = 4
        
        if self.size.width >= GameConstant.CARD_SIZE.width then
            self.face1Sprite = cc.Sprite:createWithSpriteFrameName(self:getFaceSpriteName())
            self.face2Sprite = cc.Sprite:createWithSpriteFrameName(self:getFaceSpriteName())
            self.colorSprite = cc.Sprite:createWithSpriteFrameName(self:getColorSpriteName())
            
            local biaozhun = 90
            self.face1Sprite:setAnchorPoint(0,1)
            self.face1Sprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
            self.face1Sprite:setPosition(-bgSize.width/2+paddingL,bgSize.height/2-paddingT)
            
            self.face2Sprite:setAnchorPoint(1,0)
            self.face2Sprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
            self.face2Sprite:setPosition(bgSize.width/2-paddingR+6,-bgSize.height/2+paddingB)
            
            biaozhun = 70
            self.colorSprite:setAnchorPoint(0.5,0.5)
            self.colorSprite:setScale(bgSize.width/biaozhun,bgSize.width/biaozhun)
            
            self:addChild(self.face1Sprite)
            self:addChild(self.face2Sprite)
            self:addChild(self.colorSprite)
        else
            paddingL = 3
            paddingR = 3
            paddingT = 3
            paddingB = 3
            
            self.face1Sprite = cc.Sprite:createWithSpriteFrameName(self:getFaceSpriteName())
            self.colorSprite = cc.Sprite:createWithSpriteFrameName(self:getColorSpriteName())
            
            self.face1Sprite:setAnchorPoint(0,1)
            self.face1Sprite:setPosition(-bgSize.width/2+paddingL,bgSize.height/2-paddingT)
            
            self.colorSprite:setAnchorPoint(0.5,0.5)
            self.colorSprite:setScale(0.3)
            self.colorSprite:setPosition(bgSize.width/5-3,-bgSize.height/5)
            
            self:addChild(self.face1Sprite)
            self:addChild(self.colorSprite)
        end
    end
end

function CaribCard:getPokeBackSpriteName()
    --[[if self.type == CaribCard.TYPE_SMALL then
        return "pokeBackSmall.png"
    elseif self.type == CaribCard.TYPE_MID then
        return "pokeBackMid.png"
    elseif self.type == CaribCard.TYPE_NORMAL then
        return "pokeBack.png"
    end]]

    return "beimian.png"
end

function CaribCard:getPokeFrontSpriteName()
    --[[if self.type == CaribCard.TYPE_SMALL then
        return "pokeFrontSmall.png"
    elseif self.type == CaribCard.TYPE_MID then
        return "pokeFrontMid.png"
    elseif self.type == CaribCard.TYPE_NORMAL then
        return "pokeFront.png"
    end]]

    return "zhengmian.png"
end

function CaribCard:getColorSpriteName()
    local sname = ""
    if self.pvo.color == CaribCard.COLOR_HEART then
        sname = "hongtao.png"
    elseif self.pvo.color == CaribCard.COLOR_SPADE then
        sname = "heitao.png"
    elseif self.pvo.color == CaribCard.COLOR_DIAMOND then
        sname = "fangkuai.png"
    elseif self.pvo.color == CaribCard.COLOR_CLUB then
        sname = "meihua.png"
    end
    return sname
end

function CaribCard:getFaceSpriteName()
    local prefix = "-1"
    if self.pvo.color == CaribCard.COLOR_HEART or self.pvo.color == CaribCard.COLOR_DIAMOND then 
        prefix = "" 
    end

    local str = string.lower(self.pvo:getCharFace())..prefix..".png"

    return str
end

function CaribCard:onTouchBegan(touch,event)
    local target = event:getCurrentTarget()
    local locationInNode = target:convertToNodeSpace(touch:getLocation())
    local ap = self.bg:getAnchorPoint()
    local s = self.bg:getContentSize()
    local rect = cc.rect(-s.width*ap.x, -s.height*ap.y, s.width, s.height)
    
    if cc.rectContainsPoint(rect, locationInNode) then
        --cclog("CaribCard:onTouchBegan")
        local b = self.back
        self:flip()
        if b then
            EventBus.getInst():postEvent(NI.ID.CARD_TRY_FLIP,{self,self.fliping})
        end
        return true
    end
    return false 
end

function CaribCard:onTouchMoved(touch,event)
--cclog("CaribCard:onTouchMoved")
end

function CaribCard:onTouchEnded(touch,event)
--cclog("CaribCard:onTouchEnded")
end

function CaribCard:onTouchCancelled(touch,event)
--cclog("CaribCard:onTouchEnded")
end

function CaribCard:clear()
    if self.bg and self.bg:getParent() then
        self.bg:removeFromParent(true)
    end
    
    if self.face1Sprite and self.face1Sprite:getParent() then
        self.face1Sprite:removeFromParent(true)
    end
    
    if self.face2Sprite and self.face2Sprite:getParent() then
        self.face2Sprite:removeFromParent(true)
    end
    
    if self.colorSprite and self.colorSprite:getParent() then
        self.colorSprite:removeFromParent(true)
    end
    
    self.bg = nil
    self.face1Sprite = nil
    self.face2Sprite = nil
    self.colorSprite = nil
end