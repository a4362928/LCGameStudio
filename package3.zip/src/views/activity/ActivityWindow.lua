ActivityWindow = class("ActivityWindow",function()
    return SubWindow:create()
end)

ActivityWindow.__index = ActivityWindow
ActivityWindow._inst = nil

function ActivityWindow.show(p)
    if ActivityWindow._inst == nil then
        ActivityWindow._inst = ActivityWindow.new()
    end

    p = p and p or GameData.curScene
    ActivityWindow._inst:_show(p)
end

function ActivityWindow.hide()
    if ActivityWindow._inst~=nil then
        ActivityWindow._inst:_hide()
    end

    ActivityWindow._inst = nil
end

function ActivityWindow:ctor()
    --cclog("ActivityWindow:ctor()")
    self.eventButtons = {}
    
    self:setupViews()
end

function ActivityWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/activity/activity.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    self.scrollView = self.BG:getChildByName("scrollView")
    self.titleText = self.BG:getChildByName("titleText")
    self.dateText = self.BG:getChildByName("dateText")
    self.descText = self.BG:getChildByName("descText")
    self.statusText = self.BG:getChildByName("statusText")
    
    self.closeBtn = self.BG:getChildByName("closeBtn")
    self.getBtn = self.BG:getChildByName("getBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            elseif sender == self.getBtn then
                self:onGetClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    self.getBtn:addTouchEventListener(btnCallback)
    
    self:refreshEvents()
end

function ActivityWindow:refreshEvents()
    local events = ResourceModel.getInst():getActivitys()
    while #events < 4 do
        table.insert(events,#events+1,{id=999})
    end
    
    local function eventBtnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onEventClick(sender)
        end
    end
    
    self.itemRowSize = 1
    self.itemColOffset = 0
    self.itemRowOffset = -1
    self.itemSize = cc.size(219,88)
    
    local innerSize,size = self:resetScrollView(#events)
    
    for i=1, #events do
        local e = events[i]
        local btn = ccui.Button:create("parts/activity/changfangxindi .png","parts/activity/changfangxindi -1.png","parts/activity/changfangxindi -1.png",ccui.TextureResType.localType)
        btn.act = e
        btn:addTouchEventListener(eventBtnCallback)
        
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = self.itemSize.width/2+2+yu*(self.itemSize.width+self.itemColOffset)-3
        local ty = -self.itemSize.height/2+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)+1
        btn:setPosition(cc.p(tx,ty))
        btn:setTitleFontSize(30)
        if e.id~=999 then
            btn:setTitleText(e.name)
        else
            btn:setTitleText("暂无活动")
            btn:setTouchEnabled(false)
        end
        btn:setTitleColor(cc.c3b(255,255,255))
        self.scrollView:addChild(btn)
        
        table.insert(self.eventButtons,#self.eventButtons+1,btn)
    end
    
    if #self.eventButtons>0 then
        self:selectEvent(self.eventButtons[1])
    end
end

function ActivityWindow:resetScrollView(num)
    self.eventButtons = {}
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-2

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function ActivityWindow:selectEvent(button)
    local btns = self.eventButtons
    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTitleColor(cc.c3b(0,0,0))
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
            self.selectedBtn = btn
        else
            btn:setTitleColor(cc.c3b(255,255,255))
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
            if btn.act.id==999 then
                btn:setTouchEnabled(false)
            end
        end
    end
    
    local edata = button.act
    
    if edata then
        if edata.id~=999 then
            self.titleText:setString(edata.name)
            local desc = edata.descs
            if desc==nil then desc = "" end
            self.descText:setString(desc)
            
            local d = ""
            if edata.startTime==nil and edata.endTime==nil then
                d = "永久"
            elseif edata.startTime==nil and edata.endTime~=nil then
                d = "即日起至"
                d = d..os.date("%Y-%m-%d %X",edata.endTime/1000)
            elseif edata.startTime~=nil and edata.endTime==nil then 
                d = os.date("%Y-%m-%d %X",edata.startTime/1000)
                d = d.."起开始"
            elseif edata.startTime~=nil and edata.endTime~=nil then
                d = os.date("%Y-%m-%d %X",edata.startTime/1000)
                d = d.." 至 "..os.date("%Y-%m-%d %X",edata.endTime/1000)
                self.dateText:setString(d)
            end
            
            local userAct = UserDataModel.getInst():getUserAct(edata.id)
            --领取状态0未完成,1已完成未领取,2已领取
            self.getBtn:setTouchEnabled(false)
            self.getBtn:setBright(false)
            self.statusText:setString("未达成")
            if userAct then
                if userAct.status==0 then
                    self.statusText:setString("未达成")
                elseif userAct.status==1 then
                    self.getBtn:setTouchEnabled(true)
                    self.getBtn:setBright(true)
                    self.statusText:setString("已达成")
                elseif userAct.status==2 then
                    self.statusText:setString("已领取")
                end
            end
        else
            self.titleText:setString("")
            self.descText:setString("")
            self.dateText:setString("")
        end
    end
end

function ActivityWindow:onEventClick(sender)
    self:selectEvent(sender)
end

function ActivityWindow:onGetClick()
    if self.selectedBtn then
        local act = self.selectedBtn.act
        local userAct = UserDataModel.getInst():getUserAct(act.id)
        if userAct and userAct.status==1 then
            --获取奖励
            act.status = 2
            GameMessageService.req(MI.ID.ACTIVITY_AWARD_GET,{userAct.id})
            --刷新
            self:selectEvent(self.selectedBtn)
        end
    end
end

function ActivityWindow:onCloseClick()
    ActivityWindow.hide()
end