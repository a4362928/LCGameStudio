HelpWindow = class("HelpWindow",function()
    return SubWindow:create()
end)

HelpWindow.__index = HelpWindow
HelpWindow._inst = nil

function HelpWindow.show(p)
    if HelpWindow._inst == nil then
        HelpWindow._inst = HelpWindow.new()
    end

    p = p and p or GameData.curScene
    HelpWindow._inst:_show(p)
end

function HelpWindow.hide()
    if HelpWindow._inst~=nil then
        HelpWindow._inst:_hide()
    end

    HelpWindow._inst = nil
end

function HelpWindow:ctor()
    --cclog("HelpWindow:ctor()")
    self:setupViews()
end

function HelpWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/help/help.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    self.closeBtn = self.BG:getChildByName("closeBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
end

function HelpWindow:onCloseClick()
    HelpWindow.hide()
end