MultiTimer = class("MultiTimer")

MultiTimer.__index = MultiTimer

function MultiTimer.create(group)
    local seat = MultiTimer.new(group)
    return seat
end

function MultiTimer:ctor(group)
    self.group = group
    self.timerText = self.group:getChildByName("timerText")
    self.timerText:setString("0")
end

function MultiTimer:show(value)
    if value==nil then value = true end

    if self.group~=nil then
        self.group:setVisible(value)
    end
end

function MultiTimer:setTimeText(time)
    if self.timerText~=nil then
        local str = time..""
        if string.len(str) == 1 then
            str = "0"..str
        end

        self.timerText:setString(str)
    end
end

function MultiTimer:restart(count,warnCount)
    if warnCount==nil then warnCount = 0 end
    --先停止
    self:stop()

    self.count = count
    self.warnCount = warnCount
    self.totalCount = count

    if self.warnCount <= 0 then
        self.warnCount = math.floor(count/2)
    end

    --[[self.timer ||= new Timer(990)
    if(!self.timer.hasEventListener(TimerEvent.TIMER)) 
    {
    self.timer.addEventListener(TimerEvent.TIMER,onTimer)
    }
    self.timer.repeatCount = count
    self.timer.start()]]
    local function onUpdateEvent(interval)
        self:onUpdate(interval)
    end
    
    self.group:scheduleUpdateWithPriorityLua(onUpdateEvent,0)

    --设置初始计时器时间
    self:setTimeText(count)

    self._running = true
end

function MultiTimer:onUpdate(interval)
    self.totalInterval = self.totalInterval + interval

    if self.totalInterval >= 1.0 then
        self.totalInterval = self.totalInterval-1.0

        self:stepTime()
    end
    --cclog("MultiTimer:onUpdate %s",self.totalInterval)
end

function MultiTimer:stepTime()
    self.count = self.count-1
    --cclog("MultiTimer:stepTime:%s",self.count)
    --步进
    EventBus.getInst():postEvent(NI.ID.INNOCLOCK_TIMER,{})
    self:setTimeText(self.count)

    if self.count <= self.warnCount then
        --短时间警告
        EventBus.getInst():postEvent(NI.ID.INNOCLOCK_SHORT_WARN,{})
    end

    if self.count <= 0 then
        --计时完毕
        EventBus.getInst():postEvent(NI.ID.INNOCLOCK_COMPLETE,{})

        self:stop()
        self:show(false)
    end
end

function MultiTimer:stop()
    self.count = 0
    self.totalCount = 0

    --[[if(timer)
    {
    timer.stop()
    if(timer.hasEventListener(TimerEvent.TIMER)) timer.removeEventListener(TimerEvent.TIMER,onTimer)
    }
    timer = null]]
    self.group:unscheduleUpdate()
    self:resetInterval()

    self._running = false
    self._pause = false
end

function MultiTimer:pause()
    if self._pause then
        return
    end

    self._pause = true
    self.group:unscheduleUpdate()
    --[[if(timer)
    {
    _pause = true
    timer.stop()
    if(timer.hasEventListener(TimerEvent.TIMER)) timer.removeEventListener(TimerEvent.TIMER,onTimer)
    }]]
end

function MultiTimer:resume()
    if not self._pause then
        return
    end

    self._pause = false
    local function onUpdateEvent(interval)
        self:onUpdate(interval)
    end
    self.group:scheduleUpdateWithPriorityLua(onUpdateEvent)
    --[[if(timer)
    {
    _pause = false
    timer.start()
    if(timer.hasEventListener(TimerEvent.TIMER)) timer.removeEventListener(TimerEvent.TIMER,onTimer)
    }]]
end

function MultiTimer:resetInterval()
    self.totalInterval = 0
end

function MultiTimer:dispose()
    EventBus.getInst():unregisterEvents(self)
end