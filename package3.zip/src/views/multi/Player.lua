Player = class("Player")

Player.__index = Player

--Player.sys = false
--Player.uid = nil

--Player.nickName = ""

--Player.status = nil

-- 头像地址 */
--Player.headUrl = ""

--Player.level = 0

-- 对局次数 */
--Player.battleNum = 0

--Player.gold = 0
--Player.title = ""
-- vip卡 的道具pid，如果没有vip道具状态为null */
--Player.vip = nil
--Player.vipLevel = 0
--平台数据
--Player.pfVO = nil

function Player.create(obj)
    local seat = Player.new(obj)
    return seat
end

function Player:ctor(obj)
    self.uid = obj.uid
    self.nickName = obj.nickName
    self.nickName = self.nickName or ""
    self.status = obj.status
    self.headUrl = obj.headUrl
    self.headUrl = self.headUrl or ""
    self.level = obj.level
    self.battleNum = obj.battleNum
    self.gold = obj.gold
    --称号
    self.title = obj.title
    self.title = self.title or ""
    self.vip = obj.vip
    self.vip = self.vip or 0
    self.vipLevel = self.vip % 700
    --平台数据
    self.pfVO = {}
end