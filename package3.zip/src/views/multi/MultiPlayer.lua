require "views/multi/Player.lua"

MultiPlayer = class("MultiPlayer")

MultiPlayer.__index = MultiPlayer

--MultiPlayer.uid = nil
--MultiPlayer.nickName = nil
--MultiPlayer.status = nil
-- 头像地址 */
--MultiPlayer.headUrl = nil
--MultiPlayer.level = nil
-- 对局次数 */
--MultiPlayer.battleNum = nil
--MultiPlayer.gold = nil
--MultiPlayer.player = nil

-- 座位编号 */
--MultiPlayer.siteId = nil
-- 下注类型 */
--MultiPlayer.betType = nil
-- 是否抽奖（彩金） */
--MultiPlayer.lottery = nil

--MultiPlayer.title = nil
--MultiPlayer.ach = nil
-- vip卡 的道具pid，如果没有vip道具状态为null */
--MultiPlayer.vip = nil
--MultiPlayer.vipLevel = nil

function MultiPlayer.create(user)
    local seat = MultiPlayer.new(user)
    return seat
end

function MultiPlayer:ctor(obj)
    self.player = Player.create(obj.siteVo)
    self.uid = self.player.uid
    self.nickName = self.player.nickName
    self.status = self.player.status
    self.headUrl = self.player.headUrl
    self.level = self.player.level
    self.battleNum = self.player.battleNum
    self.gold = self.player.gold
    --称号
    self.title = self.player.title
    self.vip = self.player.vip
    self.vipLevel = self.player.vipLevel
    --座位信息
    if obj.si~=nil then
        self.siteId = obj.si.siteId
        --判断是否加注
        self.betType = obj.si.betType
        --判断是否押注彩金
        self.lottery = obj.si.lottery
    else
        cclog("该用户没有座位信息:"..self.player:toString())
    end
end

function MultiPlayer:setBetType(type)
    self.betType = type
end

function MultiPlayer:getAllinBet(base)
    local yu = self.user.gold - base
    local allin = GameConstant.ALLIN_RATE * base

    return math.min(yu,all)
end

function MultiPlayer:getStatusString()
    local str = ""
    if self.status==GameConstant.USER_STATUS_NORMAL then
        str = "在线"
    elseif self.status==GameConstant.USER_STATUS_PLAY then
        str = "正在玩"
    elseif self.status==GameConstant.USER_STATUS_WAIT then
        str = "等待"
    elseif self.status==GameConstant.USER_STATUS_READY then
        str = "准备"
    elseif self.status==GameConstant.USER_STATUS_LOOK then
        str = "旁观"
    elseif self.status==GameConstant.USER_STATUS_RAISE then
        str = "加注"
    elseif self.status==GameConstant.USER_STATUS_FOLD then
        str = "弃牌"
    elseif self.status==GameConstant.USER_STATUS_QUIT then
        str = "离线"
    end

    str = self.status..">"..str

    return str
end

function MultiPlayer:toString()
    return "["..self.nickName.."("..self.uid.."),状态:"..self:getStatusString()..",座位号:"..self.siteId.."]"
end

function MultiPlayer:dispose()
    EventBus.getInst():unregisterEvents(self)
end