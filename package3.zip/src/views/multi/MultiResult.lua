MultiResult = class("MultiResult")
MultiResult.__index = MultiResult

--MultiResult.uid = 0

--/** 输赢的金币 */
--MultiResult.gold = 0

--/** 是否是庄家 */
--MultiResult.host = nil

--MultiResult.status = nil

--/** 是否中了彩金 */
--MultiResult.bingo = nil
--/** 中得的彩金数量 */
--MultiResult.pot = nil
--/** 下注数 */
--MultiResult.sumBet = nil
--MultiResult.betGold = nil
--MultiResult.betType = nil

--[[/** 牌型 */
/** -1-花牌 */
/** 0-花牌(有A、K) */
/** 1-一对 */
/** 2-两对 */
/** 3-三条 */
/** 4-顺子 */
/** 5-同花 */
/** 6-葫芦 */
/** 7-四条 */
/** 8-同花顺 */
/** 9-皇家同花顺 */
/** 10-5条 */]]
--MultiResult.cardType = nil

--/** 牌型数组 */
--MultiResult.cards = nil

--/** 最大牌分数 */
--MultiResult.maxCardScore = nil

--/** 最大牌的花色 */
--MultiResult.maxCardColor = nil
--/** 是否抽奖（彩金） */
--MultiResult.lottery = nil

--/** 该牌型对应的倍数 */
--MultiResult.cardMultiple = nil

--/** 输赢倍率 */
--MultiResult.multiple = nil

--/** 底注 */
--MultiResult.baseBet = nil
--//弃牌
--MultiResult.fold = false
--//赢取
--MultiResult.win = false

function MultiResult.create(obj,hosUid)
    local result = MultiResult.new(obj,hosUid)
    return result
end

function MultiResult:ctor(obj,hosUid)
    self.uid = obj.uid
    self.gold = obj.gold
    self.betType = obj.betType
    self.cards = obj.cards
    self.fold = obj.fold
    self.host = false
    
    if hosUid==self.uid then
        self.host = true
    end

    if self.betType == 0 and not self.host then
        self.fold = true
    end

    if self.gold >= 0 then
        self.win = true
    end
end

function MultiResult:getDeck()
    local str = ""

    local dvo = DeckVO.createWithPids(self.cards,CaribDeck.TYPE_MULIT)
    local t = dvo:getDeckType(self.host)
    dvo:dispose()
    return t
    
    --[[if self.cardType==-1 then
        if not self.host then
            str = "散牌"
        else
            str = "庄家不成局"
        end
    elseif self.cardType==0 then
        str = "散牌"
    elseif self.cardType==1 then
        str = "一对"
    elseif self.cardType==2 then
        str = "两对"
    elseif self.cardType==3 then
        str = "三条"
    elseif self.cardType==4 then
        str = "顺子"
    elseif self.cardType==5 then
        str = "同花"
    elseif self.cardType==6 then
        str = "葫芦"
    elseif self.cardType==7 then
        str = "四条"
    elseif self.cardType==8 then
        str = "同花顺"
    elseif self.cardType==9 then
        str = "皇家同花顺"
    elseif self.cardType==10 then
        str = "五条"
    end

    return str]]
end

function MultiResult:toString()
    local cardString = "{"
    for i=1,#self.cards do
        cardString = cardString..self.cards[i]
        if i~=#self.cards then
            cardString = cardString..","
        else
            cardString = cardString.."}"
        end
    end
    local str = "[".."uid:"..self.uid..",输赢金币:"..self.gold..",加注:"..self.betType..",弃牌:"..(self.fold and "true" or "false")..",牌:"..cardString..",牌型:"..self:getDeck()..(self.host and ",庄家" or "").."]"  
    return str
end