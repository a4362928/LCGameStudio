MultiHeaps = class("MultiHeaps")

MultiHeaps.__index = MultiHeaps

function MultiHeaps.create(heapGroup,multi)
    local seat = MultiHeaps.new(heapGroup,multi)
    return seat
end

function MultiHeaps:ctor(heapGroup,multi)
    self.heapGroup = heapGroup
    self.multi = multi
    self.userModel = UserModel.getInst()
    self.deskModel = DeskModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    
    self:initHeap()
end

function MultiHeaps:subTo(delay,values,to,compHandler)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.subTo,self.heap,values,to,compHandler)
    end
end

function MultiHeaps:createTo(delay,value,from,to)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.createTo,self.heap,value,from,to)
    end
end

function MultiHeaps:mergeFrom(delay,value,from)
    if self.heap then
        DelayUtils.delayCall(delay,self.heap.mergeFrom,self.heap,value,from)
    end
end

function MultiHeaps:initHeap()
    if not self.heap then
        local excs = {}
        local s = cc.size(150,150)
        local exc = cc.rect((self.visibleSize.width-s.width)/2,(self.visibleSize.height-s.height)/2+20,s.width,s.height)
        table.insert(excs,#excs+1,exc)
        s = cc.size(400,200)
        local rect = cc.rect((self.visibleSize.width-s.width)/2-10,(self.visibleSize.height-s.height)/2-10,s.width,s.height)
        self.heap = CaribHeap.create(self.heapGroup,rect,excs,0)
    end
end

function MultiHeaps:betBases()
    local maxNums,users = self.deskModel:getUsersNum(false)
    for i=1, #users do
        local user = users[i]
        local seat = self.multi.seats:getSeat(user.uid)
        if self.deskModel:getBuck()~=user.uid then
            if seat then
                self.heap:mergeFrom(self.deskModel:getBaseChip(),cc.p(seat.group:getPosition()))
                seat:seatBet(self.deskModel:getBaseChip(),true)
            elseif user.uid == self.userModel.uid then
                self.heap:mergeFrom(self.deskModel:getBaseChip(),cc.p(self.visibleSize.width/2,-10))
                self.multi.owner:seatBet(self.deskModel:getBaseChip(),true)
            end
        end
    end
end

function MultiHeaps:dispose()
    EventBus.getInst():unregisterEvents(self)
end