MultiSeats = class("MultiSeats")

MultiSeats.__index = MultiSeats

function MultiSeats.create(seatGroups,multi)
    local seat = MultiSeats.new(seatGroups,multi)
    return seat
end

function MultiSeats:ctor(seatGroups,multi)
    self.multi = multi
    self.userModel = UserModel.getInst()
    self.deskModel = DeskModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.seats = {}

    for i=1, #seatGroups do
        table.insert(self.seats,#self.seats+1,MultiSeat.create(seatGroups[i],i,multi))
    end
end

function MultiSeats:refresh()
    --cclog("Multi:refresh() %d %s",self.userModel.status,GameConstant.USER_STATUS_LOOK)
    if self.userModel.status == GameConstant.USER_STATUS_LOOK then
        self:setAllSeatMode(GameConstant.SEAT_MODE_SEAT,true)
    else
        self:setAllSeatMode(GameConstant.SEAT_MODE_EMPTY,true)
        --4号座位隐藏
        self:showOwnerSeat(false)
    end

    local oldNum = self.deskModel:getUsersNum()
    --布置座位
    for i=1,self.deskModel:getUsersNum() do
        local player = self.deskModel.users[i]
        local seat = nil
        if player.uid ~= self.userModel.uid then
            --cclog("Multi:refresh %s,%s",self.userModel.siteId,player.siteId)
            seat = self:calcSeat(self.userModel.siteId,player.siteId)
            if seat~=nil then
                seat:showPlayer(player)
                seat:setMode(GameConstant.SEAT_MODE_USER)
                --设置准备状态
                if player.status == GameConstant.USER_STATUS_READY then
                    seat:seatReady(true)
                end
                --设置离线状态
                if player.status == GameConstant.USER_STATUS_QUIT then
                    seat:seatTip("quit")
                end
                if player.uid == self.deskModel:getBuck() then 
                    seat:seatTip("empty")
                end
            else
                cclog("玩家座位异常:"..player:toString())
            end
        else
            cclog("用户自己:"..player:toString())
        end
    end
    --座位数量变更
    self.multi:seatNumChange(oldNum,self.deskModel:getUsersNum())
end

function MultiSeats:calcSeat(ownersid,playersid)
    --cclog("Multi:calcSeat:%s %s",ownersid,playersid)
    local seat = nil
    if ownersid == 0 then
        seat = self.seats[playersid]
    else
        local index = playersid-ownersid+4
        if index < 1 then
            index = index+6
        end
        index = index%6
        if index == 0 then
            index = 6
        end
        seat = self.seats[index]
    end

    return seat
end

function MultiSeats:getRealSid(clickSid)
    local seat = nil
    for i=1,#self.seats do
        seat = self.seats[i]
        if seat:hasPlayer() then
            break
        else
            seat = nil
        end
    end

    if seat==nil then
        return clickSid
    end

    local realSid = seat.player.siteId + clickSid - seat.sid
    if realSid < 1 then
        realSid = realSid+6
    end

    realSid = realSid % 6

    if realSid == 0 then
        realSid = 6
    end

    return realSid
end

function MultiSeats:getSeat(uid)
    for i=1,#self.seats do
        local seat = self.seats[i]
        if seat:hasPlayer() and seat:isPlayer(uid) then
            return seat
        end
    end

    return nil
end

function MultiSeats:getFreeSeatid(bContainQuit)
    local freeSeat = nil
    for i=1,#self.seats do
        local seat = self.seats[i]
        if seat:hasPlayer()==false then
            freeSeat = seat
            break
        end
    end

    if freeSeat==nil and bContainQuit then
        for i=1,#self.seats do
            local seat = self.seats[i]
            if seat:hasPlayer() and seat.player.status==GameConstant.USER_STATUS_QUIT then
                freeSeat = seat
                break
            end
        end
    end

    if freeSeat==nil then
        return 0
    end

    return self:getRealSid(freeSeat.sid)
end

function MultiSeats:setAllSeatMode(mode,bReset)
    for i=1,#self.seats do
        local seat = self.seats[i]
        seat:setMode(mode)

        if bReset then
            seat:clearPlayer()
        end
    end
end

function MultiSeats:showOwnerSeat(value)
    local seat = self.seats[4]
    if seat~=nil then
        seat:show(value)
    end
end

function MultiSeats:shiftQuitUsers()
    local player = self.deskModel:shiftQuitUser()
    while player~=nil do
        local seat = self:getSeat(player.uid)
        if seat~=nil then
            seat.deck:dispose()
            seat.deck = nil

            seat:clearPlayer()

            if self.userModel.status == GameConstant.USER_STATUS_LOOK then
                seat:setMode(GameConstant.SEAT_MODE_SEAT)
            else 
                seat:setMode(GameConstant.SEAT_MODE_EMPTY)
            end
        else
            cclog("该离线的玩家已经不在座位上")
        end

        player = self.deskModel:shiftQuitUser()
    end
end

function MultiSeats:flips()
    for i=1, #self.seats do
        self.seats[i]:flip()
    end
end

function MultiSeats:resets()
    for i=1, #self.seats do
        self.seats[i]:reset()
    end
end

function MultiSeats:dispose()
    EventBus.getInst():unregisterEvents(self)
end