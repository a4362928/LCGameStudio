MultiResults = class("MultiResults")

MultiResults.__index = MultiResults

function MultiResults.create(multi)
    local seat = MultiResults.new(multi)
    return seat
end

function MultiResults:ctor(multi)
    self.multi = multi
    self.userModel = UserModel.getInst()
    self.deskModel = DeskModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.results = {}
    self.ownerResult = nil
end

function MultiResults:setResult(obj)
    self:clear()
    
    local hosUid = obj.host
    local rs = obj.users
    for i=1,#rs do
        local rvo = MultiResult.create(rs[i],hosUid)

        table.insert(self.results,rvo)

        if rvo.uid == self.userModel.uid then
            self.ownerResult = rvo
        end
    end
end

function MultiResults:getCards(uid)
    for i=1, #self.results do
        local r = self.results[i]
        if r.uid == uid then
            return r.cards
        end
    end
    return nil
end

function MultiResults:getResult(uid)
    for i=1, #self.results do
        local r = self.results[i]
        if r.uid==uid then
            return r
        end
    end
    
    return nil
end

function MultiResults:getResults(lose)
    local buckUid = self.deskModel:getBuck()
    local rs = {}
    for i=1, #self.results do
        local r = self.results[i]
        --排除庄家
        if r.uid ~= buckUid then
            if lose~=nil then
                if lose then
                    if r.fold or r.gold < 0 then
                        table.insert(rs,#rs+1,r)
                    end
                else
                    if not r.fold and r.gold >= 0 then
                        table.insert(rs,#rs+1,r)
                    end
                end
            else
                table.insert(rs,#rs+1,r)
            end
        end
    end
    return rs
end

--庄家是否不成局
function MultiResults:isHostUnAK()
    local buckUid = self.deskModel:getBuck()
    local r = self:getResult(buckUid) 
    if r.cardType==-1 then
        return true
    else
        return false
    end
    return nil
end

function MultiResults:isFold(uid)
    local r = self:getResult(uid) 
    if r then
        return r.fold
    end
    return nil
end

--结算动画
function MultiResults:cash()
    if self:cashLose()==0 then
        self:cashWin(1)
    end
end

--结算输动画
function MultiResults:cashLose()
    cclog("MultiResults:cashLose")
    --庄家位置
    local buckUid = self.deskModel:getBuck()
    local to = cc.p(0,0)
    local seat = self.multi.seats:getSeat(buckUid)
    local buckR = self:getResult(buckUid)
    if seat then
        seat:seatBet(buckR.gold,true)
        to = seat:getPosition()
    elseif buckUid==self.userModel.uid then
        self.multi.owner:seatBet(buckR.gold,true)
        to = self.multi.owner:getPosition()
    end
    --已排除庄家
    local loses = self:getResults(true)
    for i=1, #loses do
        local r = loses[i]
        --净输金额
        local profit = r.gold
        --底注金额
        local base = self.deskModel:getBaseChip()
        --加注金额
        local raise = base*r.betType
        --额外溢出金额
        local yu = 0
        --不是弃牌用户
        if not r.fold then
            yu = - base - raise - profit
        end
        cclog("loser %d %d(溢出)=-%d(底注)-%d(加注)-%d(净输)",r.uid,yu,base,raise,profit)
        --显示输金额
        local seat = self.multi.seats:getSeat(r.uid)
        local from = cc.p(0,0)
        if seat then
            seat:seatBet(profit,true)
            seat:seatLose()
            from = seat:getPosition()
        elseif r.uid==self.userModel.uid then
            self.multi.owner:seatBet(profit,true)
            from = self.multi.owner:getPosition()
        end
        
        --显示筹码动画
        --底注与加注移到庄家
        local values = {}
        if base > 0 then table.insert(values,#values+1,base) end
        if raise > 0 then table.insert(values,#values+1,raise) end
        if #values > 0 then
            if i==(#loses) then
                local function completeHandler()
                    cclog("cashlose complete!!")
                    if self:cashWin(0)==0 then
                        EventBus.getInst():postEvent(NI.ID.CASH_COMPLETE,{})
                    end
                end
                self.multi.heaps:subTo(1,values,to,completeHandler)
            else
                self.multi.heaps:subTo(1,values,to,nil)
            end
        end
        --额外溢出的从玩家移到庄家处
        if yu > 0 then
            self.multi.heaps:createTo(1,yu,from,to)
        end
    end
    
    return #loses
end

--结算赢动画
function MultiResults:cashWin(delay)
    cclog("MultiResults:cashWin")
    --庄家位置
    local buckUid = self.deskModel:getBuck()
    local from = cc.p(0,0)
    local seat = self.multi.seats:getSeat(buckUid)
    if seat then
        to = seat:getPosition()
    elseif buckUid==self.userModel.uid then
        to = self.multi.owner:getPosition()
    end
    --已排除庄家
    local wins = self:getResults(false)
    for i=1, #wins do
        local r = wins[i]
        --净赢金额
        local profit = r.gold
        --底注金额
        local base = self.deskModel:getBaseChip()
        --加注金额
        local raise = base*r.betType
        --额外溢出金额
        local yu = 0
        --不是弃牌用户
        if not r.fold then
            yu = profit - base - raise
        end
        if yu < 0 then yu = 0 end
        cclog("winer %d %d(溢出)=%d(净赢)-%d(底注)-%d(加注)",r.uid,yu,profit,base,raise)
        --显示赢金额
        local seat = self.multi.seats:getSeat(r.uid)
        local to = cc.p(0,0)
        if seat then
            seat:seatBet(profit,true)
            seat:seatWin()
            to = seat:getPosition()
        elseif r.uid==self.userModel.uid then
            self.multi.owner:seatBet(profit,true)
            to = self.multi.owner:getPosition()
        end

        --显示筹码动画
        --底注与加注移回玩家
        local values = {}
        if base > 0 then table.insert(values,#values+1,base) end
        if raise > 0 then table.insert(values,#values+1,raise) end
        if #values > 0 then
            if i==(#wins) then
                local function completeHandler()
                    cclog("cashwin complete!!")
                    EventBus.getInst():postEvent(NI.ID.CASH_COMPLETE,{})
                end
                self.multi.heaps:subTo(delay,values,to,completeHandler)
            else
                self.multi.heaps:subTo(delay,values,to,nil)
            end
        end
        --额外溢出的从庄家移到玩家处
        if yu > 0 then
            self.multi.heaps:createTo(delay,yu,from,to)
        end
    end
    
    return #wins
end

function MultiResults:clear()
    while #self.results>0 do
        table.remove(self.results,1)
    end
    self.results = {}
end

function MultiResults:toString()
    if self.results==nil or #self.results==0 then
        return "\n↓结果为空\n↑"
    end

    local str = "\n↓\n"

    for i=1,#self.results do
        str = str.."结果"..i..":"..self.results[i]:toString()
        str = str.."\n"
    end

    str=str.."↑"

    return str
end

function MultiResults:dispose()
    EventBus.getInst():unregisterEvents(self)
end