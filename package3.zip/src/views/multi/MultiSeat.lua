require "views/multi/MultiTip.lua"

MultiSeat = class("MultiSeat")

MultiSeat.__index = MultiSeat

function MultiSeat.create(group,index,multi)
    local seat = MultiSeat.new(group,index,multi)
    return seat
end

function MultiSeat:ctor(group,index,multi)
    self.seatIndex = index
    self.group = group
    self.multi = multi
    self.tips = {}
    self.opened = false
    self.bet = 0
    
    self.nameText = self.group:getChildByName("nameText")
    self.cardGroup = self.group:getChildByName("cardGroup")
    self.betGroup = self.group:getChildByName("betGroup")
    self.goldGroup = self.group:getChildByName("goldGroup")
    self.resultGroup = self.group:getChildByName("resultGroup")
    self.winBG = self.resultGroup:getChildByName("winBG")
    self.loseBG = self.resultGroup:getChildByName("loseBG")
    self.doubleGroup = self.group:getChildByName("doubleGroup")
    self.doubleGlow = self.group:getChildByName("doubleGlow")
    self.betText = self.betGroup:getChildByName("betText")
    self.goldText = self.goldGroup:getChildByName("goldText")
    self.anFlag = self.group:getChildByName("anFlag")
    self.buckFlag = self.group:getChildByName("buckFlag")
    self.readyFlag = self.group:getChildByName("readyFlag")
    self.typeGroup = self.group:getChildByName("typeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    
    EventBus.getInst():registerEvent(self,CaribDeck.EVENT_TIDY_COMPLETE,self.onDeckTidyComplete,false)
    
    self:reset()
end

--全部牌展示完毕
function MultiSeat:onDeckTidyComplete(eventName,data)
    if self.deck and self.deck == data[1] then
        --显示牌型
        self:showType()
    end
end

--显示牌型
function MultiSeat:showType()
    if self.deck and self.deck.dvo then
        self.typeGroup:setVisible(true)
        self.typeText:setString(self.deck.dvo:getDeckType())
    end
end

function MultiSeat:showPlayer(player)
    --相同用户不刷新
    if self.player and player and self.player.uid == player.uid then
        return
    end

    self:clearPlayer()

    self.player = player

    --头像
    self:seatHeadImage(player.headUrl)
    --称号
    local r = self.player.title
    if r==nil then r = "" end
    --self.rankText:setString(" ")
    --名称
    --self.nameText.text = player.toString()
    --"Lv."..self.player.level.." "..
    self.nameText:setString(self.player.nickName)
    self.goldText:setString(StringUtils.toThousandSeparate(self.player.gold,","))
    --设置用户状态
    self:seatTip("empty")
    if self.player.status == GameConstant.USER_STATUS_QUIT then
        self:seatTip("quit")
    end
    if self.player.status == GameConstant.USER_STATUS_RAISE then
        self:seatTip("raise")
    end
    if self.player.status == GameConstant.USER_STATUS_FOLD then
        self:seatTip("fold")
    end
    if self.player.status == GameConstant.USER_STATUS_READY then
        self:seatTip("ready")
    end
end

function MultiSeat:clearPlayer()
    self.player = nil

    self.nameText:setString("")
    self.goldText:setString("")
end

function MultiSeat:hasPlayer()
    return self.player~=nil and true or false
end

function MultiSeat:isPlayer(uid)
    if self.player~=nil and self.player.uid == uid then
        return true
    end

    return false
end

function MultiSeat:seatHeadImage(url)
    
end

function MultiSeat:setMode(mode)
    --无用户,也不可以点击坐下
    self.group:setVisible(false)
    
    if mode==GameConstant.SEAT_MODE_EMPTY then
        self.nameText:setVisible(false)
        self.goldGroup:setVisible(false)
        --显示用户信息
    elseif mode==GameConstant.SEAT_MODE_USER then
        self.nameText:setVisible(true)
        self.goldGroup:setVisible(true)
        self.group:setVisible(true)
        --可以点击坐下
    elseif mode==GameConstant.SEAT_MODE_SEAT then
        self.nameText:setVisible(false)
        self.goldGroup:setVisible(false)
    end
end

function MultiSeat:show(value)
    self.group:setVisible(value)
end

--发牌给其他玩家
function MultiSeat:deal(card,immediate)
    if not card or not self:hasPlayer() then
        return
    end
    
    if not self.deck then
        self.deck = CaribDeck.create(true,false,GameConstant.CARD_SIZE,CaribDeck.TYPE_MULIT)
        self.deck:setAutoTidy(true)
    end
    self.deck:addCard(card)
    
    if not immediate then
        local pos = self.cardGroup:convertToWorldSpace(self:getCardPosition(card,16,#self.deck.cards,5))
        pos = card:getParent():convertToNodeSpace(pos)

        local actions = {}
        local time = 0.7
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(time,pos)))
        table.insert(actions,#actions+1,cc.RotateTo:create(time,0))
        local spa = cc.Spawn:create(actions)
        local seqActions = {}
        table.insert(seqActions,#seqActions+1,spa)
        local function completeHandler(card)
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)
        end
        --完成移动
        table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeHandler,{card}))
        if #self.deck.cards == 5 then
            EventBus.getInst():registerEvent(self,NI.ID.CARD_SEAT_DEAL_COMPLETE,self.onSeatDealComplete,true)

            local function completeEventHandler(ss)
                EventBus.getInst():postEvent(NI.ID.CARD_SEAT_DEAL_COMPLETE,{})
            end
            --最后一张牌完成移动
            table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeEventHandler,{}))
        end
        local seq = cc.Sequence:create(seqActions)
        card:runAction(seq)
    else
        local pos = self:getCardPosition(card,16,#self.deck.cards,5)
        if self.seatIndex==5 or self.seatIndex==6 then
            pos = self:getCardPosition(card,16,6-#self.deck.cards,5)
        end
        card:setPosition(pos)
        
        --[[local zorder = #self.deck.cards
        if self.seatIndex==5 or self.seatIndex==6 then
            zorder = 6-#self.deck.cards
        end]]
        
        self.cardGroup:addChild(card)
        
        if #self.deck.cards == 5 then
            self:onSeatDealComplete(nil,nil)
        end
    end
end

--发牌完毕
function MultiSeat:onSeatDealComplete(eventName,msg)
    --如果是庄家则打开牌
    if DeskModel.getInst():isBuck(self.player.uid) then
        cclog("打开庄家的牌")
        local pids = DeskModel.getInst():getBuckPid()
        for i=1, #pids do
            local index = (#self.deck.cards+1)-i
            local card = self.deck.cards[index]
            --设置牌
            card:setPid(pids[i])
            --打开
            card:flip()
        end
    end
end

--标识已看牌
function MultiSeat:openCards()
    if not self.opened then
        self.opened = true

        local tr = 50
        for i=1, #self.deck.cards do
            local card = self.deck.cards[i]
            local r = (i-1)*tr/(#self.deck.cards)
            local seq =cc.Sequence:create(cc.RotateTo:create(0.5,r))
            card:runAction(seq)
        end
    end
end

--打开牌
function MultiSeat:flip()
    if not self.player then
        --ccerror("MultiSeat:flip->无用户")
        return
    end
    
    if self.multi.results:isFold(self.player.uid) then
        return
    end
    
    --cclog("MultiSeat:flip %d",self.player.uid)
    --填充并翻开牌
    local pids = self.multi.results:getCards(self.player.uid)
    self.deck:fillEmptyWithPids(pids)
    self.deck:flip(0.1,0,true)
end

--移除牌
function MultiSeat:removeCards()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end

--变灰色
function MultiSeat:grayCards()
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:gray()
    end
end

--准备
function MultiSeat:seatReady(value)
    --cclog("MultiSeat:seatReady %s",value)
    self.readyFlag:setVisible(value)
end

function MultiSeat:seatDouble(value)
    self.doubleGlow:stopAllActions()
    self.doubleGlow:setVisible(value)
    self.doubleGroup:setVisible(value)
    
    if value==true then
        local seq = cc.Sequence:create(cc.RotateBy:create(1.5,90))
        self.doubleGlow:runAction(cc.RepeatForever:create(seq))
    end
end

--获取位置
function MultiSeat:getPosition()
    local pos = cc.p(0,0)
    if self.group then
        pos = cc.p(self.group:getPosition())
    end
    return pos
end

--加注
function MultiSeat:seatBet(value,set0)
    self.betGroup:setVisible(true)
    
    local dur = 1.5
    if set0==nil then set0=false end
    if set0==true then
        self.bet = 0
        dur = 2
    end
    
    self.oldBet = self.bet
    
    self.bet = self.bet + value
    
    --显示动画
    local function completeHandler()
        --cclog("completeHandler")
        self.betText:setString(self.bet)
    end
    TweenUtils.tweenTextNumber(self.betText,dur,self.oldBet,self.bet,completeHandler)
end

--显示庄家标识
function MultiSeat:seatBuck(value)
    self.buckFlag:setVisible(value)
end

--提示信息
function MultiSeat:seatTip(value)
    --cclog("MultiSeat:seatTip")
    self:addTip(value)
end

function MultiSeat:seatWin()
    self.resultGroup:setVisible(true)
    self.winBG:setVisible(true)
    self.loseBG:setVisible(false)
end

function MultiSeat:seatLose()
    self.resultGroup:setVisible(true)
    self.winBG:setVisible(false)
    self.loseBG:setVisible(true)
end

function MultiSeat:addTip(value)
    local content = ""
    if value=="raise" then
        content = "加注"
    elseif value=="fold" then
        content = "弃牌"
    elseif value=="open" then
        content = "看牌"
    elseif value=="double" then
        content = "加倍"
    elseif value=="nodouble" then
        content = "不加倍"
    end
    
    if not content or content=="" then return end
    local tip = MultiTip.create(content,self.seatIndex)
    tip:setPosition(180,105)
    if self.seatIndex==5 or self.seatIndex==6 then
        tip:setPosition(-53,105)
    end
    self.group:addChild(tip)
    
    local function completeHandler(tip)
        if tip then self:removeTip(tip) end
    end
    local actions = {}
    table.insert(actions,#actions+1,cc.MoveBy:create(0.5,cc.p(0,20)))
    table.insert(actions,#actions+1,cc.DelayTime:create(1))
    table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{tip}))
    
    local seq = cc.Sequence:create(actions)
    tip:runAction(seq)
    
    table.insert(self.tips,#self.tips+1,tip)
end

function MultiSeat:removeTip(tip)
    if not tip then
        return
    end
    for i=1, #self.tips do
        if self.tips[i]==tip then
            tip:removeFromParent(true)
            table.remove(self.tips,i)
           break
    	end
    end
end

function MultiSeat:removeTips()
    while #self.tips > 0 do
        self:removeTip(self.tips[1])
    end
end

function MultiSeat:seatFold()
    self:seatTip("fold")
    --变灰
    self:grayCards()
    --收起
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        --停止移动
        card:stopAllActions()
        local globalPos = card:convertToWorldSpace(cc.p(0,0))
        local localPos = self.cardGroup:convertToNodeSpace(globalPos)
        card:setPosition(localPos)
        card:removeFromParent(false)
        self.cardGroup:addChild(card)
        
        local pos = self:getCardPosition(card,10,i,#self.deck.cards)
        if self.seatIndex==5 or self.seatIndex==6 then
            pos = self:getCardPosition(card,10,6-i,#self.deck.cards)
        end
        local actions = {}
        table.insert(actions,#actions+1,cc.MoveTo:create(0.5,pos))
        table.insert(actions,#actions+1,cc.RotateTo:create(0.5,0))
        local spa = cc.Spawn:create(actions)
        card:runAction(spa)
    end
end

function MultiSeat:getCardPosition(card,gap,index,total)
    local csize = card.size
    local gsize = self.cardGroup:getLayoutSize()
    local pos = cc.p(card:getPosition())
    pos.y = gsize.height/2
    pos.x = csize.width/2+(index-1)*gap
    if self.seatIndex == 5 or self.seatIndex == 6 then
        pos.x = gsize.width-csize.width/2-(index-1)*gap
    end
    return pos
end

function MultiSeat:reset()
    self.bet = 0
    self.opened = false
    
    self.cardGroup:setOpacity(0)
    self.resultGroup:setOpacity(0)
    self.betGroup:setVisible(false)
    self.doubleGroup:setVisible(false)
    self.resultGroup:setVisible(false)
    self.doubleGlow:setVisible(false)
    self.anFlag:setVisible(false)
    self.buckFlag:setVisible(false)
    self.readyFlag:setVisible(false)
    self.typeGroup:setVisible(false)
    
    self:seatReady(false)
    self:seatDouble(false)
    self:removeTips()
    self:removeCards()
end