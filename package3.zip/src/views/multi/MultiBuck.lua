MultiBuck = class("MultiBuck")

MultiBuck.__index = MultiBuck

function MultiBuck.create(multi)
    local seat = MultiBuck.new(multi)
    return seat
end

function MultiBuck:ctor(multi)
    self.multi = multi
    self.userModel = UserModel.getInst()
    self.deskModel = DeskModel.getInst()
end

--显示庄家标识
function MultiBuck:refresh()
    self.multi.owner:seatBuck(false)
    for i=1, #self.multi.seats do
        local seat = self.multi.seats[i]
        seat:seatBuck(false)
    end

    local buckUid = self.deskModel:getBuck()
    local seat = self.multi.seats:getSeat(buckUid)
    if seat then
        seat:seatBuck(true)
    elseif self.userModel.uid==buckUid then
        self.multi.owner:seatBuck(true)
    end
end

function MultiBuck:dispose()
    EventBus.getInst():unregisterEvents(self)
end