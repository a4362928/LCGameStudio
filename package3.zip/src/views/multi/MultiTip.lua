MultiTip = class("MultiTip",function()
    return cc.Sprite:createWithSpriteFrameName("liaotianchuankou.png")
end)

MultiTip.__index = MultiTip

function MultiTip.create(content,index)
    local seat = MultiTip.new(content,index)
    return seat
end

function MultiTip:ctor(content,index)
    
    if index > 4 then
        self:setScaleX(-1)
    end
    local size = self:getContentSize()
    local contentLabel = cc.Label:create()
    contentLabel:setScaleX(self:getScaleX())
    contentLabel:setSystemFontSize(20)
    contentLabel:setPosition(size.width/2,size.height/2+5)
    contentLabel:setString(content)
    contentLabel:setColor(cc.c3b(255,255,255))
    self:addChild(contentLabel)
end