MultiOwner = class("MultiOwner")

MultiOwner.__index = MultiOwner

function MultiOwner.create(group,ownerGroup,multi)
    local seat = MultiOwner.new(group,ownerGroup,multi)
    return seat
end

function MultiOwner:ctor(group,ownerGroup,multi)
    self.group = group
    self.multi = multi
    self.ownerGroup = ownerGroup
    self.userModel = UserModel.getInst()
    self.deskModel = DeskModel.getInst()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.jackpot = false
    self.opened = false
    self.bet = 0
    self.tips = {}
    
    self.nameText = self.group:getChildByName("nameText")
    self.diamondGroup = self.group:getChildByName("diamondGroup")
    self.goldGroup = self.group:getChildByName("goldGroup")
    self.cardGroup = self.ownerGroup:getChildByName("cardGroup")
    self.betGroup = self.ownerGroup:getChildByName("betGroup")
    self.doubleGroup = self.ownerGroup:getChildByName("doubleGroup")
    self.doubleGlow = self.ownerGroup:getChildByName("doubleGlow")
    self.goldText = self.goldGroup:getChildByName("goldText")
    self.diamondText = self.diamondGroup:getChildByName("diamondText")
    self.betText = self.betGroup:getChildByName("betText")
    self.anFlag = self.ownerGroup:getChildByName("anFlag")
    self.buckFlag = self.ownerGroup:getChildByName("buckFlag")
    --self.readyFlag = self.group:getChildByName("readyFlag")
    self.typeGroup = self.ownerGroup:getChildByName("typeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    
    EventBus.getInst():registerEvent(self,CaribDeck.EVENT_TIDY_COMPLETE,self.onDeckTidyComplete,false)

    self:reset()
end

--全部牌展示完毕
function MultiOwner:onDeckTidyComplete(eventName,data)
    if self.deck and self.deck == data[1] then
        --显示牌型
        self:showType()
    end
end

--显示牌型
function MultiOwner:showType()
    if self.deck and self.deck.dvo then
        self.typeGroup:setVisible(true)
        self.typeText:setString(self.deck.dvo:getDeckType())
    end
end

--刷新信息
function MultiOwner:refresh()
    self.nameText:setString(self.userModel.user.nickName)
    self.goldText:setString(StringUtils.toThousandSeparate(self.userModel.user.gold,","))
    self.diamondText:setString(StringUtils.toThousandSeparate(self.userModel.user.bang,","))
end

--加倍状态
function MultiOwner:seatDouble(value)
    self.doubleGlow:stopAllActions()
    self.doubleGlow:setVisible(value)
    self.doubleGroup:setVisible(value)

    if value then
        local seq = cc.Sequence:create(cc.RotateBy:create(1.5,90))
        self.doubleGlow:runAction(cc.RepeatForever:create(seq))
    end
end

--获取位置
function MultiOwner:getPosition()
    local pos = cc.p(self.visibleSize.width/2,-10)
    return pos
end

--变灰色
function MultiOwner:grayCards()
    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:gray()
    end
end

--加注
function MultiOwner:seatBet(value,set0)
    self.betGroup:setVisible(true)
    
    local dur = 1.5
    if set0==nil then set0=false end
    if set0==true then
        self.bet = 0
        dur = 2
    end
    
    self.oldBet = self.bet
    
    self.bet = self.bet + value
    
    --显示动画
    local function completeHandler()
        --cclog("completeHandler")
        self.betText:setString(self.bet)
    end
    TweenUtils.tweenTextNumber(self.betText,dur,self.oldBet,self.bet,completeHandler)
end

--显示庄家标识
function MultiOwner:seatBuck(value)
    self.buckFlag:setVisible(value)
end

--提示信息
function MultiOwner:seatTip(value)
    --cclog("MultiOwner:seatTip")
    --self:addTip(value)
end

function MultiOwner:addTip(value)
    local content = ""
    if value=="raise" then
        content = "加注"
    elseif value=="fold" then
        content = "弃牌"
    elseif value=="open" then
        content = "看牌"
    elseif value=="double" then
        content = "加倍"
    elseif value=="nodouble" then
        content = "不加倍"
    end

    if not content or content=="" then return end
    local tip = MultiTip.create(content,0)
    tip:setPosition(180,105)
    self.group:addChild(tip)

    local function completeHandler(tip)
        if tip then self:removeTip(tip) end
    end
    local actions = {}
    table.insert(actions,#actions+1,cc.MoveBy:create(0.5,cc.p(0,20)))
    table.insert(actions,#actions+1,cc.DelayTime:create(1))
    table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{tip}))

    local seq = cc.Sequence:create(actions)
    tip:runAction(seq)

    table.insert(self.tips,#self.tips+1,tip)
end

function MultiOwner:removeTip(tip)
    if not tip then
        return
    end
    for i=1, #self.tips do
        if self.tips[i]==tip then
            tip:removeFromParent(true)
            table.remove(self.tips,i)
            break
        end
    end
end

function MultiOwner:removeTips()
    while #self.tips > 0 do
        self:removeTip(self.tips[1])
    end
end

function MultiOwner:seatFold()
    self:seatTip("fold")
    if self.opened==false then
        --变灰
        self:grayCards()
        --收起
        for i=1, #self.deck.cards do
            local card = self.deck.cards[i]
            --停止移动
            card:stopAllActions()
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)

            local pos = self:getCardPosition(card,5,i,#self.deck.cards)
            local actions = {}
            table.insert(actions,#actions+1,cc.MoveTo:create(0.5,pos))
            table.insert(actions,#actions+1,cc.RotateTo:create(0.5,0))
            local spa = cc.Spawn:create(actions)
            card:runAction(spa)
        end
    end
end

function MultiOwner:getCardPosition(card,gap,index,total)
    local csize = card.size
    local gsize = self.cardGroup:getLayoutSize()
    local pos = cc.p(card:getPosition())
    pos.y = gsize.height/2
    pos.x = (gsize.width-(csize.width+gap)*5-gap)/2+(index-1)*(csize.width+gap)+csize.width/2+gap
    return pos
end

--给自己发牌
function MultiOwner:deal(card,immediate)
    if not card then
        return
    end

    if not self.deck then
        self.deck = CaribDeck.create(true,false,GameConstant.MULTI_OWNER_CARD_SIZE,CaribDeck.TYPE_MULIT)
        self.deck:setAutoTidy(true)
    end
    self.deck:addCard(card)

    if not immediate then
        local pos = self.cardGroup:convertToWorldSpace(self:getCardPosition(card,25,#self.deck.cards,5))
        pos = card:getParent():convertToNodeSpace(pos)

        local actions = {}
        local time = 0.7
        table.insert(actions,#actions+1,cc.EaseSineOut:create(cc.MoveTo:create(time,pos)))
        table.insert(actions,#actions+1,cc.RotateTo:create(time,0))
        local spa = cc.Spawn:create(actions)
        local seqActions = {}
        table.insert(seqActions,#seqActions+1,spa)
        local function completeHandler(card)
            local globalPos = card:convertToWorldSpace(cc.p(0,0))
            local localPos = self.cardGroup:convertToNodeSpace(globalPos)
            card:setPosition(localPos)
            card:removeFromParent(false)
            self.cardGroup:addChild(card)
        end
        --完成移动
        table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeHandler,{card}))
        if #self.deck.cards == 5 then
            EventBus.getInst():registerEvent(self,NI.ID.CARD_OWNER_DEAL_COMPLETE,self.onOwnerDealComplete,true)

            local function completeEventHandler(ss)
                EventBus.getInst():postEvent(NI.ID.CARD_OWNER_DEAL_COMPLETE,{})
            end
            --最后一张牌完成移动
            table.insert(seqActions,#seqActions+1,cc.CallFunc:create(completeEventHandler,{}))
        end
        local seq = cc.Sequence:create(seqActions)
        card:runAction(seq)
        
        card:tweenSize(time,self.deck.size)
    else
        local pos = self:getCardPosition(card,25,#self.deck.cards,5)
        card:setPosition(pos)

        self.cardGroup:addChild(card)
        if #self.deck.cards == 5 then
            self.multi:delayCall(0.1,self.onOwnerDealComplete,self)
        end

        card:setSize(self.deck.size)
    end
end

--自己发牌完毕
function MultiOwner:onOwnerDealComplete(eventName,msg)
    cclog("Multi:onOwnerDealComplete")
    --剩余扑克牌收拢
    self.multi.dealer:uncover()
    --如果自己是庄家则打开牌
    if self.deskModel:isBuck(self.userModel.uid) then
        cclog("打开庄家的牌")
        local pids = self.deskModel:getBuckPid()
        for i=1, #pids do
            local index = (#self.deck.cards+1)-i
            local card = self.deck.cards[index]
            --设置牌
            card:setPid(pids[i])
            --打开
            card:flip()
        end
        --启用操作按钮
        self.multi:setButtonEnable(true,{self.multi.doubleBtn,self.multi.nodoubleBtn})
    else
        --设置牌可以操作
        for i=1, #self.deck.cards do
            local card = self.deck.cards[i]
            card:setFlip(true)
        end
        --启用操作按钮
        self.multi:setButtonEnable(true,{self.multi.bet2Btn,self.multi.bet5Btn,self.multi.allinBtn,self.multi.openBtn,self.multi.foldBtn})
    end
end

--打开牌
function MultiOwner:flip()
    if self.multi.results:isFold(self.userModel.uid) then
        return
    end

    --填充并翻开牌
    if self.deck:hasEmptyCard()==true then
        local pids = self.multi.results:getCards(self.userModel.uid)
        self.deck:fillEmptyWithPids(pids)
    end
    self.deck:flip(0.1,0,true)
end

--移除牌
function MultiOwner:removeCards()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end

function MultiOwner:reset()
    self.jackpot = false
    self.opened = false
    self.bet = 0
    
    self.cardGroup:setOpacity(0)
    self.betGroup:setVisible(false)
    self.doubleGroup:setVisible(false)
    self.doubleGlow:setVisible(false)
    self.anFlag:setVisible(false)
    self.buckFlag:setVisible(false)
    --self.readyFlag:setVisible(false)
    self.typeGroup:setVisible(false)
    
    self:seatDouble(false)
    self:removeTips()
    self:removeCards()
end

function MultiOwner:dispose()
    EventBus.getInst():unregisterEvents(self)
end