require "views/multi/MultiSeat.lua"
require "views/multi/MultiOwner.lua"
require "views/multi/MultiDealer.lua"
require "views/multi/MultiHeaps.lua"
require "views/multi/MultiSeats.lua"
require "views/multi/MultiTimer.lua"
require "views/multi/MultiBuck.lua"
require "views/multi/MultiMenu.lua"
require "views/multi/MultiResults.lua"
require "views/multi/MultiResult.lua"

Multi = class("Multi",function()
    return LCLayer.create()
end)

Multi.__index = Multi

function Multi.create()
    --cclog("Multi:create")
    local scene = LCScene.create()
    local layer = Multi.new()
    scene:addChild(layer)

    GameData.curLayer = layer
    GameData.curScene = scene
    return scene
end

function Multi:ctor()
    self.deskModel = DeskModel.getInst()
    self.userModel = UserModel.getInst()
    
    --cclog("Multi:ctor()")
    local function onNodeEvent(eventType)
        if eventType=="cleanup" then
            self:cleanup()
        elseif eventType == "enter" then
            self:onEnter()
        elseif eventType=="enterTransitionFinish" then
            self:onEnterTransitionDidFinish()
        elseif eventType == "exitTransitionStart" then
            self:onExitTransitionDidStart()
        elseif eventType=="exit" then
            self:onExit()
        end
    end

    ScriptHandlerMgr:getInstance():registerScriptHandler(self,onNodeEvent,cc.Handler.NODE)

    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchMoved(touch,event)
        return self:onTouchMoved(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local function onTouchCancelled(touch,event)
        return self:onTouchCancelled(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    touchListener:registerScriptHandler(onTouchCancelled,cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    --eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)

    local function onKeyReleased(touch,event)
        return self:onKeyReleased(touch,event)
    end
    
    local keyListener = cc.EventListenerKeyboard:create()
    keyListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(keyListener, self)

    self:setupViews()
end

function Multi:setupViews()
    --cclog("Multi:setupViews")
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/multi/multi.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((self.visibleSize.width - ulSize.width)/2,(self.visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)
    
    self.BG = self.widget:getChildByName("BG")
    --groups
    self.menuGroup = self.widget:getChildByName("menuGroup")
    self.userGroup = self.widget:getChildByName("userGroup")
    self.ownerGroup = self.widget:getChildByName("ownerGroup")
    self.timerGroup = self.widget:getChildByName("timerGroup")
    self.seat1Group = self.widget:getChildByName("seat1Group")
    self.seat2Group = self.widget:getChildByName("seat2Group")
    self.seat3Group = self.widget:getChildByName("seat3Group")
    self.seat4Group = self.widget:getChildByName("seat4Group")
    self.seat5Group = self.widget:getChildByName("seat5Group")
    self.seat6Group = self.widget:getChildByName("seat6Group")
    self.jackpotGroup = self.widget:getChildByName("jackpotGroup")
    self.dealsGroup = self.widget:getChildByName("dealsGroup")
    self.heapGroup = self.widget:getChildByName("heapGroup")

    --buttons
    self.menuBtn = self.widget:getChildByName("menuBtn")
    self.chatBtn = self.widget:getChildByName("chatBtn")
    self.mallBtn = self.widget:getChildByName("mallBtn")
    self.readyBtn = self.widget:getChildByName("readyBtn")
    self.jackpotBtn = self.widget:getChildByName("jackpotBtn")
    self.bet2Btn = self.widget:getChildByName("bet2Btn")
    self.bet5Btn = self.widget:getChildByName("bet5Btn")
    self.allinBtn = self.widget:getChildByName("allinBtn")
    self.foldBtn = self.widget:getChildByName("foldBtn")
    self.openBtn = self.widget:getChildByName("openBtn")
    self.doubleBtn = self.widget:getChildByName("doubleBtn")
    self.nodoubleBtn = self.widget:getChildByName("nodoubleBtn")
    
    self.timerText = self.timerGroup:getChildByName("timerText")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.menuBtn then
                self:onMenuClick(sender)
            elseif sender == self.chatBtn then
                self:onChatClick(sender)
            elseif sender == self.mallBtn then
                self:onMallClick(sender)
            elseif sender == self.readyBtn then
                self:onReadyClick(sender)
            elseif sender == self.jackpotBtn then
                self:onJackpotClick(sender)
            elseif sender == self.bet2Btn then
                self:onBet2Click(sender)
            elseif sender == self.bet5Btn then
                self:onBet5Click(sender)
            elseif sender == self.allinBtn then
                self:onAllinClick(sender)
            elseif sender == self.foldBtn then
                self:onFoldClick(sender)
            elseif sender == self.openBtn then
                self:onOpenClick(sender)
            elseif sender == self.doubleBtn then
                self:onDoubleClick(sender)
            elseif sender == self.nodoubleBtn then
                self:onNodoubleClick(sender)
            end
        end
    end

    self.menuBtn:addTouchEventListener(btnCallback)
    self.chatBtn:addTouchEventListener(btnCallback)
    self.mallBtn:addTouchEventListener(btnCallback)
    self.readyBtn:addTouchEventListener(btnCallback)
    self.jackpotBtn:addTouchEventListener(btnCallback)
    self.bet2Btn:addTouchEventListener(btnCallback)
    self.bet5Btn:addTouchEventListener(btnCallback)
    self.allinBtn:addTouchEventListener(btnCallback)
    self.foldBtn:addTouchEventListener(btnCallback)
    self.openBtn:addTouchEventListener(btnCallback)
    self.doubleBtn:addTouchEventListener(btnCallback)
    self.nodoubleBtn:addTouchEventListener(btnCallback)
    
    --服务器消息
    --主动消息
    EventBus.getInst():registerEvent(self,MI.ID.DESK_OUT,self.onOutDeskResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_STANDUP,self.onStandupResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_SITDOWN,self.onSitdownResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_READY,self.onReadyResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_JACKPOT,self.onJackpotResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_RAISE,self.onRaiseResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_HOST_RAISE,self.onHostRaiseResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_OPEN,self.onOpenResult)
    EventBus.getInst():registerEvent(self,MI.ID.MULIT_FOLD,self.onFoldResult)

    --命令消息
    EventBus.getInst():registerEvent(self,MI.ID.C_DESK_OUT,self.onCOutDeskResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_DESK_INTO,self.onCIntoDeskResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_STANDUP,self.onCStandupResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_READY,self.onCReadyResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_RAISE,self.onCRaiseResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_HOST_RAISE,self.onCHostRaiseResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_OPEN,self.onCOpenResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_FOLD,self.onCFoldResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_START,self.onCStartResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_START_LOOK,self.onCStartLookResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_MULIT_OVER,self.onCOverResult)
    EventBus.getInst():registerEvent(self,MI.ID.C_START_TIMER_RESET,self.onCStartTimerResetResult)

    --通知事件
    EventBus.getInst():registerEvent(self,NI.ID.INNOCLOCK_COMPLETE,self.onClockComplete)
    EventBus.getInst():registerEvent(self,NI.ID.USER_STATUS_CHANGE,self.onUserStatusChange)
    EventBus.getInst():registerEvent(self,NI.ID.CARD_TRY_FLIP,self.onCardTryFlip)
    EventBus.getInst():registerEvent(self,NI.ID.CASH_COMPLETE,self.onCashComplete)
    
    --菜单
    self.menu = MultiMenu.create(self.menuGroup,self)
    self.head = HeadWrapper.create(self.userGroup,3)
    self.notice = NoticeWidget.create(self,3)
    --初始化座位
    self.seats = MultiSeats.create({self.seat1Group,self.seat2Group,self.seat3Group,self.seat4Group,self.seat5Group,self.seat6Group},self)
    --用户自己
    self.owner = MultiOwner.create(self.userGroup,self.ownerGroup,self)
    self.owner:refresh()
    --发牌器
    self.dealer = MultiDealer.create(self.dealsGroup,self)
    --筹码
    self.heaps = MultiHeaps.create(self.heapGroup,self)
    --结果
    self.results = MultiResults.create(self)
    --计时器
    self.clock = MultiTimer.create(self.timerGroup)
    self.clock:show(false)
    --庄家标识
    self.buck = MultiBuck.create(self)
    --初始化房间
    self:refreshDesk()
end

function Multi:refreshDesk()
    --隐藏庄家操作按钮
    self:setButtonVisible(false,{self.doubleBtn,self.nodoubleBtn})
    --隐藏闲家操作按钮
    self:setButtonVisible(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.foldBtn,self.openBtn})
    --更新用户状态
    local ostatus = self.userModel:getStatus()
    if self.deskModel:hasUser(self.userModel.uid) then
        local user = self.deskModel:getUser(self.userModel.uid)
        self.userModel:setStatus(user.status)
        self.userModel.siteId = user.siteId
    else
        self.userModel:setStatus(GameConstant.USER_STATUS_LOOK)
        self.userModel.siteId = 0
    end
    --用户状态改变
    self:userStatusChange(ostatus,self.userModel:getStatus())
    --更新座位状态
    self.seats:refresh()
    --庄家标识
    if self.deskModel:getStatus() == GameConstant.DESK_STATUS_PLAYING then
        self.buck:refresh()
    end
    --桌子本桌状态
    --cclog("状态桌子:%s",self.deskModel:getStatus())
    if self.deskModel:getStatus() == GameConstant.DESK_STATUS_PLAYING then
        --进入房间可以获取到
        self.clock:restart(self.deskModel.usedTime,0)
        self.clock:show(true)
        --创建牌,庄家显示一张牌,其他玩家显示5张暗牌
        --self:createPlayersDeck({},self.deskModel:getBuck(),self.deskModel.hostCid)
        --创建筹码
        --self:createPlayersHeap(false,true)
    elseif self.deskModel:getStatus() == GameConstant.DESK_STATUS_WAIT then
        --当用户的状态!=3时,显示快速开始按钮
        if self.deskModel.leftStartTime > 0 then
            --开始倒计时
            self.clock:restart(self.deskModel.leftStartTime,0)
            self.clock:show(true)
        end
    end
end

function Multi:seatNumChange(prevNum,num)
    --更新按钮状态
    if prevNum ~= num then
        self:userStatusChange(self.userModel:getStatus(),self.userModel:getStatus())
    end
end

function Multi:userStatusChange(prevStatus,status)
    if status == GameConstant.USER_STATUS_LOOK then
        --旁观
        --隐藏所有按钮
        --self:showAllButtons(false)
        --隐藏所有按钮
        --self:setButtonEnable(false,{self.allopenBtn,self.raiseBtn,self.foldBtn,self.ratio2Btn,self.ratio3Btn,self.ratio4Btn,self.ratio5Btn,self.ratio6Btn,self.ratio7Btn})
        --self:disableAllButtons()
        --self:setButtonEnable(false,{self.standBtn})
    else
        --非旁观
        --self:showAllButtons(true)
        --隐藏所有按钮
        --self:setButtonEnable(false,{self.allopenBtn,self.raiseBtn,self.foldBtn,self.ratio2Btn,self.ratio3Btn,self.ratio4Btn,self.ratio5Btn,self.ratio6Btn,self.ratio7Btn})
        --隐藏开始按钮
        --self:startEnabled(false)
        self:setButtonVisible(false,{self.readyBtn,self.jackpotBtn,self.doubleBtn,self.nodoubleBtn,self.bet2Btn,self.bet5Btn,self.allinBtn,self.openBtn,self.foldBtn})
        self:setButtonEnable(true,{self.readyBtn,self.jackpotBtn,self.doubleBtn,self.nodoubleBtn,self.bet2Btn,self.bet5Btn,self.allinBtn,self.openBtn,self.foldBtn})
        --等待
        if status == GameConstant.USER_STATUS_WAIT then
            --启用站起按钮
            --self:setButtonEnable(true,{self.standBtn})
            if prevStatus == GameConstant.USER_STATUS_PLAY then
                --if not self.readyed then
                    self:setButtonVisible(true,{self.readyBtn})
                --end
            else
                --if not self.readyed then
                    self:setButtonVisible(true,{self.readyBtn})
                --end
            end
            --如果玩家处于等待状态，但是桌子是玩牌状态，则隐藏开始按钮
            if self.deskModel:getStatus() == GameConstant.DESK_STATUS_PLAYING then
                self:setButtonVisible(false,{self.readyBtn})
            end
            --用户处于等待状态，自动检测已经勾选的彩金按钮,如果不满足条件则取消彩金，并且提示玩家
            --this.checkJackpot()
            --准备
        elseif status == GameConstant.USER_STATUS_READY then
            --隐藏开始按钮
            self:setButtonVisible(false,{self.readyBtn})
            --游戏中
        elseif status == GameConstant.USER_STATUS_PLAY then
            --禁用站起按钮
            --self:setButtonEnable(false,{self.standBtn})
            --隐藏开始按钮
            --self:startEnabled(false)
            self:setButtonVisible(false,{self.readyBtn})
            --启用打开全部按钮
            if self.deskModel:getBuck() ~= self.userModel.uid then
                self:setButtonVisible(true,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.openBtn,self.foldBtn})
                self:setButtonEnable(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.openBtn,self.foldBtn})
                self:setButtonVisible(false,{self.doubleBtn,self.nodoubleBtn})
            else
                self:setButtonVisible(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.openBtn,self.foldBtn})
                self:setButtonVisible(true,{self.doubleBtn,self.nodoubleBtn})
                self:setButtonEnable(false,{self.doubleBtn,self.nodoubleBtn})
            end
        end
    end
end

function Multi:onClockComplete(eventName,data)
    --计时器置为0
    self.clock:setTimeText(0)
    self.clock:show(true)
    --隐藏准备按钮
    self.readyBtn:setVisible(false)
end

function Multi:onUserStatusChange(eventName,data)
    local ostatus = data.oldStatus
    local status = data.newStatus
    
    self:userStatusChange(tonumber(ostatus),tonumber(status))
end

function Multi:onCardTryFlip(eventName,data)
    local card = data[1]
    self:addWillFlip(card)
    
    if self.owner.opened==false then
        --玩家看牌
        GameMessageService.req(MI.ID.MULIT_OPEN)
        self.owner.opened = true
    end
end

function Multi:addWillFlip(card)
    if card and card.back and not card.fliping then
        if not self.willFilpCards then
            self.willFilpCards = {}
        end

        local function hasWill(card)
            for i=1, #self.willFilpCards do
                if self.willFilpCards[i]==card then
                    return true
                end
            end
            return false
        end

        if not hasWill(card) then
            table.insert(self.willFilpCards,#self.willFilpCards+1,card)
        else
            return
        end
    end
end

--结算动画完毕
function Multi:onCashComplete()
    cclog("onCashComplete")
    --刷新状态
    self:userStatusChange(self.userModel:getStatus(),self.userModel:getStatus())
    
    self.owner:refresh()
end

function Multi:onMenuClick(sender)
    self.menu:show(self)
end

function Multi:onChatClick(sender)
    if self.chat==nil then
        self.chat = ChatWidget.create()
    end
    self.chat:show(self)
end

function Multi:onMallClick(sender)
    MallWindow.show()
end

function Multi:onReadyClick(sender)
    GameMessageService.req(MI.ID.MULIT_READY)
    
    self:setButtonVisible(false,{self.readyBtn,self.jackpotBtn})
end

function Multi:onJackpotClick(sender)
    GameMessageService.req(MI.ID.MULIT_JACKPOT,{self.owner.jackpot})
    
    self.owner.jackpot = not self.owner.jackpot
    self:setButtonEnable(false,{self.jackpotBtn})
end

function Multi:onBet2Click(sender)
    GameMessageService.req(MI.ID.MULIT_RAISE,{2})
    
    self:betRaise(2)
end

function Multi:onBet5Click(sender)
    GameMessageService.req(MI.ID.MULIT_RAISE,{5})
    
    self:betRaise(5)
end

function Multi:onAllinClick(sender)
    GameMessageService.req(MI.ID.MULIT_RAISE,{0})

    self:betRaise(0)
end

function Multi:betRaise(rate)
    self:setButtonEnable(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.foldBtn,self.openBtn})
    
    local value = self.deskModel:getBaseChip()*rate
    if rate == 0 then
        value = self.userModel:getAllinBet(self.deskModel:getBaseChip())
    end
    
    --牌不能再操作
    self.owner.deck:setFlip(false)
    --筹码
    self.owner:seatBet(value,false)
    self.heaps.heap:mergeFrom(value,self.owner:getPosition())
end

function Multi:onFoldClick(sender)
    GameMessageService.req(MI.ID.MULIT_FOLD)

    self:setButtonVisible(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.foldBtn,self.openBtn})
    self:setButtonEnable(false,{self.bet2Btn,self.bet5Btn,self.allinBtn,self.foldBtn,self.openBtn})
end

function Multi:onOpenClick(sender)
    --玩家看牌
    if self.owner.opened==false then
        GameMessageService.req(MI.ID.MULIT_OPEN)
        self.owner.opened = true
        --标记将要打开所有牌
        for i=1, #self.owner.deck.cards do
            local card = self.owner.deck.cards[i]
            --不能翻牌
            card:setFlip(false)
            self:addWillFlip(card)
        end
    else
        self.owner:flip()
    end
    
    --禁用看牌按钮
    self:setButtonEnable(false,{self.openBtn})
end

function Multi:onDoubleClick(sender)
    GameMessageService.req(MI.ID.MULIT_HOST_RAISE,{true})
    
    --隐藏是否加倍按钮
    self:setButtonVisible(false,{self.doubleBtn,self.nodoubleBtn})
    self:setButtonEnable(false,{self.doubleBtn,self.nodoubleBtn})
    
    --显示加倍标识
    self.owner:seatDouble(true)
end

function Multi:onNodoubleClick(sender)
    GameMessageService.req(MI.ID.MULIT_HOST_RAISE,{false})
    
    --隐藏是否加倍按钮
    self:setButtonVisible(false,{self.doubleBtn,self.nodoubleBtn})
    self:setButtonEnable(false,{self.doubleBtn,self.nodoubleBtn})
    
    --隐藏加倍标识
    self.owner:seatDouble(false)
end

function Multi:onOutDeskResult(eventName,msg)
    if msg.state == 0 then
        --更改用户状态
        self.userModel:setStatus(GameConstant.USER_STATUS_NORMAL)
        self.deskModel:removeUser(self.userModel.uid)
        self:exitG()
    end
end

function Multi:exitG()
    cc.Director:getInstance():setDepthTest(true)
    cc.Director:getInstance():replaceScene(cc.TransitionFade:create(GameConstant.SCENE_FADE_TIME,Hall.create()))

    self.userModel:setStatus(GameConstant.USER_STATUS_NORMAL)
end

function Multi:onStandupResult(eventName,msg)
    if msg.state==0 then

    end
end

function Multi:onSitdownResult(eventName,msg)
    if msg.state==0 then

    end
end

function Multi:onReadyResult(eventName,msg)
    if msg.state == 0 then
        --显示准备状态
        if self.userModel.status ~= GameConstant.USER_STATUS_PLAY then
            self.userModel:setStatus(GameConstant.USER_STATUS_READY)
        end
    end
end

function Multi:onJackpotResult(eventName,msg)
    self:setButtonEnable(true,{self.jackpotBtn})
end

function Multi:onRaiseResult(eventName,msg)
    if msg.state==0 then
        
    end
end

function Multi:onHostRaiseResult(eventName,msg)
    if msg.state==0 then
        --自己是庄家 加倍
    end
end

function Multi:onOpenResult(eventName,msg)
    if msg.state==0 then
        local cards = msg.result
        --设置玩家已看牌
        self.owner.opened = true
        --设置所有牌面
        if cards then
            for i=1, #self.owner.deck.cards do
                local card = self.owner.deck.cards[i]
                local pid = tonumber(cards[i])
                if pid >= 102 then
                    card:setPid(pid)
                end
            end
        end
        --打开玩家点击的牌
        if self.willFilpCards and cards then
            for i=1, #self.willFilpCards do
                local card = self.willFilpCards[i]
                card:flip()
            end
        end
        
        self.willFilpCards = nil
    end
end

function Multi:onFoldResult(eventName,msg)
    if msg.state==0 then
        self.owner:seatFold()
    end
end

function Multi:onCOutDeskResult(eventName,msg)
    if msg.state==0 then
        local oldNum = self.deskModel:getUsersNum(true)
        local uid = msg.result[1]
        local seat = nil
        if self.deskModel:getUserStatus(uid) == GameConstant.USER_STATUS_PLAY and self.deskModel:getStatus() == GameConstant.DESK_STATUS_PLAYING then
            cclog("玩家离线:"..uid)

            self.deskModel:setUserStatus(uid,GameConstant.USER_STATUS_QUIT)
            --牌局正在进行
            seat = self.seats:getSeat(uid)
            if seat~=nil then
                seat:seatTip("quit")
            else 
                cclog("没有找到退出座位:"..uid)
            end
        else
            self.deskModel:removeUser(uid)
            --牌局未开始,清除玩家
            seat = self.seats:getSeat(uid)
            if seat~=nil then
                cclog("玩家:"..seat.player:toString().."退出桌子")
                seat:clearPlayer()
                if self.userModel.status == GameConstant.USER_STATUS_LOOK then
                    seat:setMode(GameConstant.SEAT_MODE_SEAT)
                else
                    seat:setMode(GameConstant.SEAT_MODE_EMPTY)
                end
            else 
                cclog("没有找到退出座位:"..uid)
            end
        end

        cclog(self.deskModel:toUsersString())

        --座位变更
        self:seatNumChange(oldNum,self.deskModel:getUsersNum(true))
    end
end

function Multi:onCIntoDeskResult(eventName,msg)
    if msg.state==0 then
        --更改用户状态
        local player = MultiPlayer.create(msg.result[1])

        local oldNum = self.deskModel:getUsersNum(false)

        if player.siteId > 0 and player.siteId <= 6 then
            --处理强制退出，然后又进来的用户
            local oplayer = self.deskModel:getUser(player.uid)
            local seat = nil
            if oplayer~=nil then
                --清除原来座位的信息，但是不清除牌
                seat = self.seats:getSeat(oplayer.uid)
                if seat~=nil then
                    seat:clearPlayer()
                end
                self.deskModel:removeUser(oplayer.uid)
            end

            self.deskModel:addUser(player)
            self.deskModel:setUserStatus(player.uid,GameConstant.USER_STATUS_WAIT)

            seat = self.seats:calcSeat(self.userModel.siteId,player.siteId)
            if seat~=nil then
                if seat:hasPlayer() then
                    cclog("该座位原本有玩家坐着:"..seat:toString())
                end
                seat:showPlayer(player)
                seat:setMode(GameConstant.SEAT_MODE_USER)
                if self.deskModel:getStatus() == GameConstant.DESK_STATUS_PLAYING then
                    seat:seatTip("wait")
                end

                cclog("玩家:"..seat.player:toString().."进入桌子")
            end
        else
            player.status = GameConstant.USER_STATUS_LOOK
        end

        cclog(self.deskModel:toUsersString())

        --座位变更
        self:seatNumChange(oldNum,self.deskModel:getUsersNum())
    end
end

function Multi:onCStandupResult(eventName,msg)
    if msg.state==0 then

    end
end

function Multi:onCReadyResult(eventName,msg)
    if msg.state == 0 then
        local uid = msg.result[1]
        local jackpot = msg.result[2]
        --cclog("GameMainLayer:onCReadyResult:%s %s",uid,jackpot)
        self.deskModel:setUserStatus(uid,GameConstant.USER_STATUS_READY,false)

        local seat = self.seats:getSeat(uid)
        if seat~=nil then
            seat:removeCards()
            seat:seatReady(true)
        else 
            cclog("没有找到准备座位:"..uid)
        end
    end
end

function Multi:onCRaiseResult(eventName,msg)
    if msg.state==0 then
        local uid = msg.result[1]
        local ratio = msg.result[2]
        local value = ratio*self.deskModel:getBaseChip()

        self.deskModel:setUserStatus(uid,GameConstant.USER_STATUS_RAISE,false)
        local seat = self.seats:getSeat(uid)
        if seat~=nil then
            if ratio == 0 then
                value = seat.player:getAllinBet(self.deskModel:getBaseChip())
            end
            --显示加注提示
            seat:seatTip("raise")
            --筹码
            seat:seatBet(value,false)
            self.heaps.heap:mergeFrom(value,cc.p(seat.group:getPosition()))
            --是否暗注
        elseif uid == self.userModel.uid then
            --[[if ratio == 0 then
                value = self.userModel:getAllinBet(self.deskModel:getBaseChip())
            end
            --筹码
            self.owner:seatBet(value,true)
            self.heaps.heap:mergeFrom(value,cc.p(self.visibleSize.width/2,-10))]]
        else 
            cclog("没有找到加注座位:"..uid)
        end
    end
end

function Multi:onCHostRaiseResult(eventName,msg)
    --显示加倍状态
    if msg.state==0 then
        local double = msg.result[1]
        --cclog("%s",double)
        local buckUid = self.deskModel:getBuck()
        
        self.owner:seatDouble(false)
        for i=1, #self.seats.seats do
            local seat = self.seats.seats[i]
            seat:seatDouble(false)
        end
        
        local seat = self.seats:getSeat(buckUid)
        if seat then
            if double then
                seat:seatDouble(true)
                seat:seatTip("double")
            else
                seat:seatDouble(false)
                seat:seatTip("nodouble")
            end
        elseif self.userModel.uid == buckUid then
            if double then
                self.owner:seatDouble(true)
                seat.owner:seatTip("double")
            else
                self.owner:seatDouble(false)
                seat.owner:seatTip("nodouble")
            end
        end
    end
end

function Multi:onCOpenResult(eventName,msg)
    if msg.state==0 then
        local uid = msg.result[1]
        local seat = self.seats:getSeat(uid)
        if seat then
            seat:seatTip("open")
            seat:openCards()
        end
    end
end

function Multi:onCFoldResult(eventName,msg)
    if msg.state==0 then
        local uid = msg.result[1]
        local pids = msg.result[2]

        --离线用户状态不设置
        self.deskModel:setUserStatus(uid,GameConstant.USER_STATUS_FOLD,false)

        local seat = self.seats:getSeat(uid)

        if seat~=nil then 
            --弃牌
            if self.userModel.uid ~= uid then
                seat:seatFold()
            end

            if seat.player.status == GameConstant.USER_STATUS_QUIT then
                seat:seatTip("quit")
            else
                seat:seatTip("fold")
            end
        else 
            cclog("没有找到弃牌座位:"..uid)
        end
    end
end

function Multi:onCStartResult(eventName,msg)
    if msg.state==0 then
        local buckUid = msg.result[1]
        local buckPids = msg.result[2]
        --游戏开始后清除已经离线的用户
        self.seats:shiftQuitUsers()
        --设置当前庄家
        self.deskModel:setBuck(buckUid,buckPids)
        --玩牌状态
        self.deskModel:setStatus(GameConstant.DESK_STATUS_PLAYING)
        self.deskModel:setUsersStatus(GameConstant.USER_STATUS_PLAY,false)
        self.userModel:setStatus(GameConstant.USER_STATUS_PLAY)
        --重置座位
        self.owner:reset()
        self.seats:resets()
        --设置庄家标识
        self.buck:refresh()
        --展开牌
        self.dealer:cover()
        --下注筹码
        self.heaps:betBases()
        --重新计时
        self.clock:restart(30,0)
        self.clock:show(true)
    end
end

function Multi:onCStartLookResult(eventName,msg)
    if msg.state==0 then
        
    end
end

function Multi:onCOverResult(eventName,msg)
    if msg.state==0 then
        local arr = msg.result[1]
        
        --存储结果
        self.results:setResult(arr)
        cclog(self.results:toString())

        --设置桌子状态
        self.deskModel:setStatus(GameConstant.DESK_STATUS_WAIT)
        --设置用户状态
        self.deskModel:setUsersStatus(GameConstant.USER_STATUS_WAIT,false)
        self.userModel:setStatus(GameConstant.USER_STATUS_WAIT)

        --重新计时
        self.clock:restart(15)
        self.clock:show(true)

        --显示所有玩家的牌,除了弃牌的
        self.seats:flips()
        self.owner:flip()
        --结算动画
        self.results:cash()
    end
end

function Multi:onCStartTimerResetResult(eventName,msg)
    if msg.state==0 then
        local time = msg.result[1]
        if time> 0 then
            self.clock:restart(time,0)
            self.clock:show(true)
        end
    end
end

function Multi:onEnter()
--cclog("Multi:onEnter")
    self:_onEnter()
end

function Multi:onEnterTransitionDidFinish()
--cclog("Multi:onEnterTransitionDidFinish")
    self:_onEnterTransitionDidFinish()
end

function Multi:onExitTransitionDidStart()
--cclog("Multi:onExitTransitionDidStart")
    self:_onExitTransitionDidStart()
end

function Multi:onExit()
--cclog("Multi:onExit")
    self:_onExit()
    self.userModel:setStatus(GameConstant.USER_STATUS_NORMAL)
    
    self.menu:dispose()
    self.notice:dispose()
    self.seats:dispose()
    self.owner:dispose()
    self.dealer:dispose()
    self.heaps:dispose()
    self.results:dispose()
    self.clock:dispose()
    self.buck:dispose()
    if self.chat then
        self.chat:dispose()
    end
    
    self.menu = nil
    self.notice = nil
    self.seats = nil
    self.owner = nil
    self.dealer = nil
    self.heaps = nil
    self.results = nil
    self.clock = nil
    self.buck = nil
    self.chat = nil
end

function Multi:cleanup()
--cclog("Multi:cleanup")
    self:_cleanup()
end

function Multi:onTouchBegan()
--cclog("Multi:onTouchBegan")
end

function Multi:onTouchMoved()
--cclog("Multi:onTouchMoved")
end

function Multi:onTouchEnded()
--cclog("Multi:onTouchEnded")
end

function Multi:onTouchCancelled()
--cclog("Multi:onTouchEnded")
end

function Multi:onKeyReleased(keyCode, event)
--cclog("Multi:onKeyReleased")
    if keyCode==cc.KeyCode.KEY_BACK or keyCode==cc.KeyCode.KEY_MENU then
        self:onMenuClick(nil)
    end
end