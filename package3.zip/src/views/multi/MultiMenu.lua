MultiMenu = class("MultiMenu")

MultiMenu.__index = MultiMenu

function MultiMenu.create(group,multi)
    local seat = MultiMenu.new(group,multi)
    return seat
end

function MultiMenu:show(p)
    if self:isVisible()==true then
        self:hide()
        return
    end
    
    self.group:setVisible(true)
    
    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end
    
    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self.group)
end

function MultiMenu:isVisible()
    return self.group:isVisible()
end

function MultiMenu:hide()
    self.group:setVisible(false)
    
    local eventDispatcher = self.group:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self.group)
end

function MultiMenu:ctor(group,multi)
    self.group = group
    self.multi = multi
    self.group:setVisible(false)
    
    self.quitBtn = self.group:getChildByName("quitBtn")
    self.changeBtn = self.group:getChildByName("changeBtn")
    self.ptypeBtn = self.group:getChildByName("ptypeBtn")
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.quitBtn then
                self:onQuitClick(sender)
            elseif sender == self.changeBtn then
                self:onChangeDeskClick(sender)
            elseif sender == self.ptypeBtn then
                self:onPTypeClick(sender)
            end
        end
    end
    self.quitBtn:addTouchEventListener(btnCallback)
    self.changeBtn:addTouchEventListener(btnCallback)
    self.ptypeBtn:addTouchEventListener(btnCallback)
end

function MultiMenu:onQuitClick(sender)
    GameMessageService.req(MI.ID.DESK_OUT)
    
    self:hide()
end

function MultiMenu:onChangeDeskClick(sender)
    self:hide()
end

function MultiMenu:onPTypeClick(sender)
    if self.cardType==nil then
        self.cardType = CardTypeWidget.create(CaribDeck.TYPE_MULIT)
    end
    self.cardType:show(self.multi)
    
    self:hide()
end

function MultiMenu:onTouchBegan()
    return true
end

function MultiMenu:onTouchEnded(touch,event)
    local pos = touch:getLocationInView()
    local size = self.group:getContentSize()
    if pos.x > 0 and pos.x < size.width and pos.y > 0 and pos.y < size.height then
        
    else
        self:hide()
    end
end

function MultiMenu:dispose()
    EventBus.getInst():unregisterEvents(self)
    
    if self.cardType then
        self.cardType:dispose()
    end
    self.cardType = nil
end