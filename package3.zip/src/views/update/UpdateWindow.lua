UpdateWindow = class("UpdateWindow",function()
    return SubWindow:create()
end)

UpdateWindow.__index = UpdateWindow
UpdateWindow._inst = nil

function UpdateWindow.show(p)
    if UpdateWindow._inst == nil then
        UpdateWindow._inst = UpdateWindow.new()
    end

    p = p and p or GameData.curScene
    UpdateWindow._inst:_show(p)
end

function UpdateWindow.hide()
    if UpdateWindow._inst~=nil then
        UpdateWindow._inst:_hide()
    end

    UpdateWindow._inst = nil
end

function UpdateWindow:ctor()
    self:setupViews()
end

function UpdateWindow:setupViews()
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/update/update.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    self.progressBar = self.BG:getChildByName("progressBar")
    self.progressText = self.BG:getChildByName("progressText")

    self.cancelBtn = self.BG:getChildByName("cancelBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.cancelBtn then
                self:onCancelClick(sender)
            end
        end
    end

    self.cancelBtn:addTouchEventListener(btnCallback)
    
    self.progressBar:setPercent(0)
    self.progressText:setString("0%")
    
    self:startUpdate()
end

--开始更新
function UpdateWindow:startUpdate()
    cclog("开始更新")
    local versionPath = "https://raw.githubusercontent.com/a4362928/LCGameStudio/master/fzcarib.version?r="..math.random(0,99999)
    local packagePath = "https://raw.githubusercontent.com/a4362928/LCGameStudio/master/package1.zip"
    
    --cc.FileUtils
    local fileUtils = cc.FileUtils:getInstance()
    local pathToSave = fileUtils:getWritablePath()
    
    local realPath = pathToSave-- .. "/package"
    
    local searchPaths = fileUtils:getSearchPaths()
    table.insert(searchPaths,1,realPath)
    table.insert(searchPaths,1,realPath.."/src")
    table.insert(searchPaths,1,realPath.."/res")
    table.insert(searchPaths,1,realPath.."/res/hd")
    
    local function onError(errorCode)
        if errorCode == cc.ASSETSMANAGER_NO_NEW_VERSION then
            cclog("no new version")
        elseif errorCode == cc.ASSETSMANAGER_NETWORK then
            Alert.show(self,"网络连接失败，请检查网络","提示",Alert.OK+Alert.CANCEL,self.onNetFailedHandler,self)
        end
    end

    local function onProgress( percent )
        cclog("prohress %f",percent)
    end

    local function onSuccess()
        cclog("downloading ok")
    end
    
    local assetsManager = cc.AssetsManager:new(packagePath,versionPath,pathToSave)
    assetsManager:retain()
    assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
    assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
    assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS )
    assetsManager:setConnectionTimeout(3)
    
    assetsManager:update()
end

function ConnectCommand:onNetFailedHandler(detail)
    if detail == Alert.OK or detail == Alert.CANCEL then
        cc.Director:getInstance():endToLua()
    end
end

function UpdateWindow:onCancelClick()
    UpdateWindow.hide()
    
    cc.Director:getInstance():endToLua()
end