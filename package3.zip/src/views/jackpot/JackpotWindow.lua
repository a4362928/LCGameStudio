require "views/jackpot/JackpotItem.lua"

JackpotWindow = class("JackpotWindow",function()
    return SubWindow:create()
end)

JackpotWindow.__index = JackpotWindow
JackpotWindow._inst = nil

function JackpotWindow.show(p)
    if JackpotWindow._inst == nil then
        JackpotWindow._inst = JackpotWindow.new()
    end

    p = p and p or GameData.curScene
    JackpotWindow._inst:_show(p)
end

function JackpotWindow.hide()
    if JackpotWindow._inst~=nil then
        JackpotWindow._inst:_hide()
    end

    JackpotWindow._inst = nil
end

function JackpotWindow:ctor()
    --cclog("JackpotWindow:ctor()")
    self:setupViews()
end

function JackpotWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/jackpot/jackpot.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")

    self.closeBtn = self.BG:getChildByName("closeBtn")
    
    self.soloGroup = self.BG:getChildByName("soloGroup")
    self.multiGroup = self.BG:getChildByName("multiGroup")
    
    --[[self.Image_10 = self.BG:getChildByName("Image_11")
    
    local pos1 = self.Image_10:convertToWorldSpace(cc.p(0,0))
    pos1 = self.multiGroup:convertToNodeSpace(pos1)
    cclog("hehehe: %f %f",pos1.x,pos1.y)]]

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
    
    self.soloItem = JackpotItem.create(self.soloGroup,1)
    self.multiItem = JackpotItem.create(self.multiGroup,2)
    
    self.soloItem:setJackpot(GlobalDataModel.getInst():getSoloJackpot())
    self.multiItem:setJackpot(GlobalDataModel.getInst():getMultiJackpot())
    
    self.soloItem:setValues(UserDataModel.getInst():getUserSoloJackpot())
    self.multiItem:setValues(UserDataModel.getInst():getUserMultiJackpot())
end

function JackpotWindow:onCloseClick()
    JackpotWindow.hide()
end

function JackpotWindow:dispose()
    self.soloItem:dispose()
    self.multiItem:dispose()
    
    self.soloItem = nil
    self.multiItem = nil
end