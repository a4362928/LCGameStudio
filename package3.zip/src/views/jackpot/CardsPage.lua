CardsPage = class("CardsPage",function()
    return ccui.Layout:create()
end)

CardsPage.__index = CardsPage

function CardsPage.create(pids,size)
    local pvo = CardsPage.new(pids,size)
    return pvo
end

function CardsPage:ctor(pids,size)
    self.pids = pids
    self.size = size
    self.setupViewed = false
    self:setContentSize(size)

    --self:setupViews()
end

function CardsPage:setupViews()
    if self.setupViewed==true then
        return
    end
    self.setupViewed = true
    --cclog("CardsPage:setupViews")
    self.deck = CaribDeck.create(false,false,GameConstant.CARD_SIZE,CaribDeck.TYPE_SOLO)
    self.deck:setDeckWithPids(self.pids)

    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:setPosition((i-1)*50+GameConstant.CARD_SIZE.width/2+6,self.size.height/2)
        self:addChild(card)
    end
end

function CardsPage:dispose()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end