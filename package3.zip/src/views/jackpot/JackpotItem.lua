require "views/jackpot/CardsPage.lua"

JackpotItem = class("JackpotItem")

JackpotItem.__index = JackpotItem

function JackpotItem.create(group,type)
    local pvo = JackpotItem.new(group,type)
    return pvo
end

function JackpotItem:ctor(group,type)
    self.group = group
    self.type = type
    self.pages = {}
    
    self.totalText = self.group:getChildByName("totalText")
    self.maxTypeText = self.group:getChildByName("maxTypeText")
    self.pageView = self.group:getChildByName("pageView")
    self.awardText = self.group:getChildByName("awardText")
    
    self.typeGroup = self.group:getChildByName("typeGroup")
    self.typeText = self.typeGroup:getChildByName("typeText")
    self.typeGroup:setVisible(false)
    
    self.awardText:setString("该牌获得的奖金:0")
    
    local function pageViewEvent(sender, eventType)
        if eventType == ccui.PageViewEventType.turning then
            local page = sender:getPage(sender:getCurPageIndex())
            if page then
                self:showCurPage(page)
                self:refreshViewNext()
            end
        end
    end 

    self.pageView:addEventListener(pageViewEvent)
end

function JackpotItem:setValues(total,vos)
    self.totalText:setString("历史领取彩金:"..StringUtils.toThousandSeparate(total,","))
    for i=1, #vos do
        local vo = vos[i]
        local page = CardsPage.create(vo.cards,cc.size(253,140))
        page.vo = vo
        --{pot=0,cards={{},{}}}
        if page then
            if i==1 then
                self:showCurPage(page)
            end
            self.pageView:addPage(page)
            table.insert(self.pages,#self.pages+1,page)
        end
    end
    
    self:refreshViewNext()
end

function JackpotItem:showCurPage(page)
    local vo = page.vo
    local dvo = nil
    if self.type==1 then
        dvo = DeckVO.createWithPids(vo.cards,CaribDeck.TYPE_SOLO)
    elseif self.type==2 then
        dvo = DeckVO.createWithPids(vo.cards,CaribDeck.TYPE_MULIT)
    end
    self.awardText:setString("该牌获得的奖金:"..StringUtils.toThousandSeparate(vo.pot,","))
    self.typeGroup:setVisible(true)
    self.typeText:setString(dvo:getDeckType())
    
    dvo:dispose()
    dvo = nil
end

function JackpotItem:refreshViewNext()
    local curIndex = self.pageView:getCurPageIndex()
    local totalIndex = #self.pageView:getPages()
    local nextIndex = curIndex + 1
    if nextIndex>=totalIndex then nextIndex = totalIndex end
    
    local curPage = self.pageView:getPage(curIndex)
    if curPage then
        curPage:setupViews()
    end
    
    local nextPage = self.pageView:getPage(nextIndex)
    if nextPage then
        nextPage:setupViews()
    end
end

function JackpotItem:setJackpot(num)
    self.jackpotNum = ScrollNumber.create(num,9,GameConstant.JACKPOT_NUMS,cc.size(25,33))
    local size = self.jackpotNum:getContentSize()
    if self.type==1 then
        self.jackpotNum:setPosition(300.5+size.width/2,392.5+size.height/2)
    elseif self.type==2 then
        self.jackpotNum:setPosition(-42.5+size.width/2,320.5+size.height/2)
    end
    self.jackpotNum:setEdges(12,-148)
    self.group:addChild(self.jackpotNum)
end

function JackpotItem:dispose()
    while #self.pages>0 do
        local page = self.pages[1]
        page:dispose()
        table.remove(self.pages,1)
    end
end