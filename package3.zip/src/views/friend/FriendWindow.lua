FriendWindow = class("FriendWindow",function()
    return SubWindow:create()
end)

FriendWindow.__index = FriendWindow
FriendWindow._inst = nil

function FriendWindow.show(p)
    if FriendWindow._inst == nil then
        FriendWindow._inst = FriendWindow.new()
    end

    p = p and p or GameData.curScene
    FriendWindow._inst:_show(p)
end

function FriendWindow.hide()
    if FriendWindow._inst~=nil then
        FriendWindow._inst:_hide()
    end

    FriendWindow._inst = nil
end

function FriendWindow:ctor()
    --cclog("FriendWindow:ctor()")
    self:setupViews()
end

function FriendWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/friend/friend.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")

    self.closeBtn = self.BG:getChildByName("closeBtn")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.closeBtn then
                self:onCloseClick(sender)
            end
        end
    end

    self.closeBtn:addTouchEventListener(btnCallback)
end

function FriendWindow:onCloseClick()
    FriendWindow.hide()
end