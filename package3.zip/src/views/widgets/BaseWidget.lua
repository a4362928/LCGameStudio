BaseWidget = class("BaseWidget",function()
    return cc.Node:create()
end)

BaseWidget.__index = BaseWidget

function BaseWidget.create()
    local chat = BaseWidget.new()
    return chat
end

function BaseWidget:ctor()
    self:retain()
end

function BaseWidget:show(p)
    self._parent = p

    if p then
        p:addChild(self)
    end
    
    local function onTouchBegan(touch,event)
        return self:onTouchBegan(touch,event)
    end

    local function onTouchEnded(touch,event)
        return self:onTouchEnded(touch,event)
    end

    local touchListener = cc.EventListenerTouchOneByOne:create()
    touchListener:setSwallowTouches(true)
    touchListener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    touchListener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(touchListener, self)
end

function BaseWidget:onTouchBegan()
    return true
end

function BaseWidget:onTouchEnded(touch,event)
    local pos = touch:getLocationInView()
    pos = touch:getLocation()
    local size = self:getContentSize()
    local p = cc.p(self:getPosition())
    local rect = cc.rect(p.x-size.width/2,p.y-size.height/2,size.width,size.height)

    --cclog("pos %f %f",pos.x,pos.y)
    --cclog("rect %f %f %f %f %s",rect.x,rect.y,rect.width,rect.height,cc.rectContainsPoint(rect,pos))
    if cc.rectContainsPoint(rect,pos) then
        
    else
        self:hide()
    end
end

function BaseWidget:hide()
    if self._parent then
        self._parent:removeChild(self,true)
    end

    self._parent = nil
end

function BaseWidget:dispose()
    --所有注册取消事件
    EventBus.getInst():unregisterEvents(self)
    
    self:hide()
    self:release()
end