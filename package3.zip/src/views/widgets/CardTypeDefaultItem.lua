CardTypeDefaultItem = class("CardTypeDefaultItem",function()
    return cc.Node:create()
end)

CardTypeDefaultItem.__index = CardTypeDefaultItem

function CardTypeDefaultItem.create(vo,gtype)
    local item = CardTypeDefaultItem.new(vo,gtype)
    return item
end

function CardTypeDefaultItem:ctor(vo,gtype)
    self.vo = vo
    self.gtype = gtype

    self:setupViews()
end

function CardTypeDefaultItem:setupViews()
    self.bgSize = cc.size(310,60)

    self.bg = ccui.Layout:create()
    self.bg:setTouchEnabled(false)
    self.bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    self.bg:setBackGroundColor(cc.c3b(0,0,0))
    self.bg:setBackGroundColorOpacity(0)
    self.bg:setContentSize(self.bgSize)
    self:addChild(self.bg)
    
    --牌
    self.deck = CaribDeck.create(false,false,GameConstant.CARD_SIZE,self.gtype)
    self.deck:setDeckWithPids(self.vo.pids)

    for i=1, #self.deck.cards do
        local card = self.deck.cards[i]
        card:setPosition((i-1)*(GameConstant.CARD_SIZE.width+1)+GameConstant.CARD_SIZE.width/2,self.bgSize.height/2)
        self:addChild(card)
    end
    
    --牌型文本
    self.typeText = ccui.Text:create()
    self.typeText:setAnchorPoint(0,0.5)
    self.typeText:setFontSize(22)
    if self.vo.id==10 then
        self.typeText:setFontSize(18)
    end
    self.typeText:setColor(cc.c3b(255,228,1))
    self.typeText:setPosition(210,self.bgSize.height/2)
    self.typeText:setString(self.deck.dvo:getDeckType())
    self:addChild(self.typeText)
end

function CardTypeDefaultItem:dispose()
    if self.deck then
        self.deck:dispose()
        self.deck = nil
    end
end