require "views/widgets/BaseWidget.lua"
require "views/widgets/ChatDefaultItem.lua"

ChatWidget = class("ChatWidget",function()
    return BaseWidget.create()
end)

ChatWidget.__index = ChatWidget

function ChatWidget.create()
    local chat = ChatWidget.new()
    return chat
end

function ChatWidget:ctor()
    self:setupViews()
end

function ChatWidget:setupViews()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()

    self.bg = cc.Sprite:create("parts/chat/liaotiankuang.png")
    self:addChild(self.bg)
    
    local bgSize = self.bg:getContentSize()
    self:setContentSize(bgSize)
    
    self:setPosition(self.visibleSize.width-bgSize.width/2,self.visibleSize.height/2)
    
    self.textsBtn = ccui.Button:create("parts/chat/xinxi-1.png","parts/chat/xinxi.png","parts/chat/xinxi.png")
    self.textsBtn:setPosition(290,43)
    
    self.facesBtn = ccui.Button:create("parts/chat/biaoqing.png","parts/chat/biaoqing-1.png","parts/chat/biaoqing-1.png")
    self.facesBtn:setPosition(352,43)
    
    self.bg:addChild(self.textsBtn)
    self.bg:addChild(self.facesBtn)
    
    self.scrollSize = cc.size(350,365)
    self.scrollView = ccui.ScrollView:create()
    self.scrollView:setDirection(ccui.ScrollViewDir.vertical)
    self.scrollView:setContentSize(self.scrollSize)
    self.scrollView:setInnerContainerSize(self.scrollSize)
    self.scrollView:setPosition(24,91)
    self.scrollView:setClippingEnabled(true)
    self.scrollView:setBounceEnabled(true)
    self.bg:addChild(self.scrollView)
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.textsBtn then
                self:onTextsClick(sender)
            elseif sender == self.facesBtn then
                self:onFacesClick(sender)
            end
        end
    end

    self.textsBtn:addTouchEventListener(btnCallback)
    self.facesBtn:addTouchEventListener(btnCallback)
    
    self:changeView(self.textsBtn)
end

function ChatWidget:changeView(button)
    local btns = {self.textsBtn,self.facesBtn}
    local type = 1
    self.itemRowSize = 0
    self.itemColOffset = 0
    self.itemRowOffset = 0
    self.itemSize = cc.size(0,0)

    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
        else
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
        end
    end

    if button==self.textsBtn then
        type = 1
        self.itemRowSize = 1
        self.itemColOffset = 67
        self.itemRowOffset = 2
        self.itemSize = cc.size(350,60)
    elseif button==self.facesBtn then
        type = 2
        self.itemRowSize = 5
        self.itemColOffset = 7
        self.itemRowOffset = 7
        self.itemSize = cc.size(64,64)
    end

    local items = self:getDefaults(type)

    local innerSize,size = self:resetView(#items,type)

    for i=1, #items do
        local item = ChatDefaultItem.create(items[i],type,self.itemSize)
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = yu*(self.itemSize.width+self.itemColOffset)
        local ty = -self.itemSize.height+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        if type==1 then

        elseif type==2 then
        
        end
        item:setPosition(cc.p(tx,ty))
        self.scrollView:addChild(item)
    end

    self.scrollView:jumpToTop()
end

function ChatWidget:getDefaults(type)
    local arr = {}
    if type==1 then
        arr = {
            {id=1,text="快点吧，等到花儿都谢了"},
            {id=2,text="一手好牌，天助我也"},
            {id=3,text="嘿嘿，这把拼人品了"},
            {id=4,text="天啦，这牌也太烂了"},
            {id=5,text="你牌太好了吧，走啥黄道运啊"},
            {id=6,text="哎，怎么会是这样啊"},
            {id=7,text="不要走，决战都天亮"}
        }
    elseif type==2 then
        for i=1, 30 do
            table.insert(arr,#arr+1,{id=i,icon=i..".png"})
        end
    end
    return arr
end

function ChatWidget:resetView(num,type)
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function ChatWidget:onTextsClick(sender)
    self:changeView(sender)
end

function ChatWidget:onFacesClick(sender)
    self:changeView(sender)
end