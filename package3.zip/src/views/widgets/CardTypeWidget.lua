require "views/widgets/BaseWidget.lua"
require "views/widgets/CardTypeDefaultItem.lua"

CardTypeWidget = class("CardTypeWidget",function()
    return BaseWidget.create()
end)

CardTypeWidget.__index = CardTypeWidget

function CardTypeWidget.create(gtype)
    local chat = CardTypeWidget.new(gtype)
    return chat
end

function CardTypeWidget:ctor(gtype)
    self.gtype = gtype
    
    self:setupViews()
end

function CardTypeWidget:setupViews()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()
    self.items = {}

    self.bg = cc.Sprite:create("parts/multi/paixingdikuang.png")
    self:addChild(self.bg)

    local bgSize = self.bg:getContentSize()
    self:setContentSize(bgSize)

    self:setPosition(bgSize.width/2,self.visibleSize.height-bgSize.height/2)

    self.scrollSize = cc.size(306,375)
    self.scrollView = ccui.ScrollView:create()
    self.scrollView:setDirection(ccui.ScrollViewDir.vertical)
    self.scrollView:setContentSize(self.scrollSize)
    self.scrollView:setInnerContainerSize(self.scrollSize)
    self.scrollView:setPosition(27,30)
    self.scrollView:setClippingEnabled(true)
    self.scrollView:setBounceEnabled(true)
    self.bg:addChild(self.scrollView)

    self:changeView()
end

function CardTypeWidget:changeView()
    self.itemRowSize = 1
    self.itemColOffset = 0
    self.itemRowOffset = 19
    self.itemSize = cc.size(310,60)

    local vos = self:getDefaults()

    local innerSize,size = self:resetView(#vos)

    for i=1, #vos do
        local item = CardTypeDefaultItem.create(vos[i],self.gtype)
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = yu*(self.itemSize.width+self.itemColOffset)
        local ty = -self.itemSize.height+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        item:setPosition(cc.p(tx,ty))
        self.scrollView:addChild(item)
        table.insert(self.items,#self.items+1,item)
    end

    self.scrollView:jumpToTop()
end

function CardTypeWidget:getDefaults()
    local arr = {
        {id=1,type="散牌",pids={102,203,304,405,107}},
        {id=2,type="一对",pids={102,202,304,405,107}},
        {id=3,type="两对",pids={102,202,303,403,107}},
        {id=4,type="三条",pids={102,202,302,405,107}},
        {id=5,type="顺子",pids={102,203,304,405,106}},
        {id=6,type="同花",pids={102,103,104,105,107}},
        {id=7,type="葫芦",pids={102,202,302,403,103}},
        {id=8,type="四条",pids={102,202,302,402,107}},
        {id=9,type="同花顺",pids={102,103,104,105,106}},
        {id=10,type="皇家同花顺",pids={110,111,112,113,114}}
    }

    return arr
end

function CardTypeWidget:resetView(num)
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function CardTypeWidget:dispose()
    while #self.items>0 do
        local item = self.items[1]
        item:dispose()
        table.remove(self.items,1)
    end

    self:hide()
    self:release()
end