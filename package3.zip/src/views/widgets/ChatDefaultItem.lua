ChatDefaultItem = class("ChatDefaultItem",function()
    return cc.Node:create()
end)

ChatDefaultItem.__index = ChatDefaultItem

function ChatDefaultItem.create(vo,type,size)
    local item = ChatDefaultItem.new(vo,type,size)
    return item
end

function ChatDefaultItem:ctor(vo,type,size)
    self.vo = vo
    self.type = type
    self.size = size

    self:setupViews()
end

function ChatDefaultItem:setupViews()
    self.bg = ccui.Layout:create()
    self.bg:setTouchEnabled(false)
    self.bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    self.bg:setBackGroundColor(cc.c3b(0,0,0))
    self.bg:setBackGroundColorOpacity(100)
    self.bg:setContentSize(self.size)
    self:addChild(self.bg)
    
    if self.type==1 then
        self.msgText = ccui.Text:create()
        self.msgText:setAnchorPoint(0,0.5)
        self.msgText:setPosition(8,self.size.height/2)
        self.msgText:setFontSize(24)
        self.msgText:setString(self.vo.text)
        self:addChild(self.msgText)
        
        --self.btn = ccui.Button:create("parts/chat/bg.png","parts/chat/bg.png","parts/chat/bg.png",ccui.TextureResType.localType)
        --self.btn:setPosition(self.size.width/2,self.size.height/2)
        --self.btn:setTitleFontSize(24)
        --self.btn:setTitleText(self.vo.text)
        --self:addChild(self.btn)
    elseif self.type==2 then
        self.icon = cc.Sprite:create("parts/chat/"..self.vo.icon)
        self.icon:setPosition(self.size.width/2,self.size.height/2)
        self:addChild(self.icon)
        
        --self.btn = ccui.Button:create("parts/chat/"..self.vo.icon,"parts/chat/"..self.vo.icon,"parts/chat/"..self.vo.icon,ccui.TextureResType.localType)
        --self.btn:setPosition(self.size.width/2,self.size.height/2)
        --self:addChild(self.btn)
    end
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClick(sender)
        end
    end

    --self.btn:addTouchEventListener(btnCallback)
end

function ChatDefaultItem:onClick(sender)
    cclog("onClick")
end