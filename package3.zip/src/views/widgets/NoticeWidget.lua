require "views/widgets/BaseWidget.lua"

NoticeWidget = class("NoticeWidget",function()
    return BaseWidget.create()
end)

NoticeWidget.__index = NoticeWidget

function NoticeWidget.create(owner,type)
    local chat = NoticeWidget.new(owner,type)
    return chat
end

function NoticeWidget:ctor(owner,type)
    self.owner = owner
    self.type = type
    self.running = false

    self:setupViews()
    
    --self:show()
end

function NoticeWidget:setupViews()
    self.visibleSize = cc.Director:getInstance():getVisibleSize()
    self.origin = cc.Director:getInstance():getVisibleOrigin()

    self.bg = cc.Sprite:create("parts/common/labakuang.png")
    self:addChild(self.bg)

    local bgSize = self.bg:getContentSize()
    self:setContentSize(bgSize)

    self:setPosition(self.visibleSize.width/2,self.visibleSize.height-50)
    if self.type==1 then
        self:setPosition(self.visibleSize.width/2+80,self.visibleSize.height-50)
    end
    
    --按钮
    local s = nil
    self.speakerBtn = ccui.Button:create("parts/common/laba.png","parts/common/laba-1.png","parts/common/laba-1.png",ccui.TextureResType.localType)
    s = self.speakerBtn:getContentSize()
    self.speakerBtn:setPosition(-bgSize.width/2+s.width/2+2,0)
    self:addChild(self.speakerBtn)
    
    --
    local mask = cc.Sprite:create("parts/common/broadcastBG.png")
    self.broadcast = cc.ClippingNode:create()
    self.broadcast:setPosition(15,-2)
    self.broadcast:setStencil(mask)
    self.broadcast:setContentSize(mask:getContentSize())
    self:addChild(self.broadcast)
    
    self.broadcatsSize = mask:getContentSize()
    
    self.broadcastText = ccui.Text:create()
    self.broadcastText:setAnchorPoint(0,0.5)
    self.broadcastText:setPosition(self.broadcatsSize.width/2,0)
    self.broadcastText:setString("")
    self.broadcastText:setFontSize(24)
    self.broadcast:addChild(self.broadcastText)
    
    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.speakerBtn then
                self:onSpeakerClick(sender)
            end
        end
    end
    
    self.speakerBtn:addTouchEventListener(btnCallback)
    
    EventBus.getInst():registerEvent(self,NI.ID.BROAD_CAST_UPDATE,self.onSpeakerUpdate,false)
    
    self:onSpeakerUpdate()
end

function NoticeWidget:onSpeakerClick(sender)
    --发送喇叭
    cclog("发送喇叭")
    
    
end

function NoticeWidget:onSpeakerUpdate(eventName,data)
    if self.running then
        return
    end
    
    self:startRun(GlobalDataModel.getInst():getNextBroadcast())
end

function NoticeWidget:startRun(b)
    if b==nil then
        self.running = false
        self:hide()
        return
    end
    
    self:show()
    
    self.running = true

    self.broadcastText:setPosition(self.broadcatsSize.width/2,0)
    self.broadcastText:setString(b.content)
    
    local size = self.broadcastText:getContentSize()
    local dur = (size.width+self.broadcatsSize.width)/70
    local actions = {}
    table.insert(actions,#actions+1,cc.MoveTo:create(dur,cc.p(-self.broadcatsSize.width/2-size.width,0)))
    table.insert(actions,#actions+1,cc.DelayTime:create(0.5))
    local function completeHandler()
        self.running = false
        self:startRun(GlobalDataModel.getInst():getNextBroadcast())
    end
    table.insert(actions,#actions+1,cc.CallFunc:create(completeHandler,{}))
    
    local seq = cc.Sequence:create(actions)
    self.broadcastText:runAction(seq)
end

function NoticeWidget:show()
    if self.owner and self:getParent()==nil then
        self.owner:addChild(self)
    end
end

function NoticeWidget:hide()
    --if self:getParent()~=nil then
        self:removeFromParent(false)
    --end
end