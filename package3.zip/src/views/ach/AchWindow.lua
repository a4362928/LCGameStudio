require "views/ach/AchItem.lua"

AchWindow = class("AchWindow",function()
    return SubWindow:create()
end)

AchWindow.__index = AchWindow
AchWindow._inst = nil

function AchWindow.show(p)
    if AchWindow._inst == nil then
        AchWindow._inst = AchWindow.new()
    end

    p = p and p or GameData.curScene
    AchWindow._inst:_show(p)
end

function AchWindow.hide()
    if AchWindow._inst~=nil then
        AchWindow._inst:_hide()
    end

    AchWindow._inst = nil
end

function AchWindow:ctor()
    --cclog("AchWindow:ctor()")
    self.items = {}
    
    self:setupViews()
end

function AchWindow:setupViews()
    --cclog("Solo:setupViews")
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()

    self.widget = ccs.GUIReader:getInstance():widgetFromBinaryFile("ui/ach/ach.csb")
    local ulSize = self.widget:getContentSize()
    self.widget:setPosition((visibleSize.width - ulSize.width)/2,(visibleSize.height - ulSize.height)/2)
    self:addChild(self.widget)

    self.BG = self.widget:getChildByName("BG")
    
    self.cardBtn = self.BG:getChildByName("cardBtn")
    self.goldBtn = self.BG:getChildByName("goldBtn")
    self.glowBtn = self.BG:getChildByName("glowBtn")
    self.closeBtn = self.BG:getChildByName("closeBtn")
    
    self.scrollView = self.BG:getChildByName("scrollView")
    self.pointsText = self.BG:getChildByName("pointsText")

    local function btnCallback(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender == self.cardBtn then
                self:onCardClick(sender)
            elseif sender == self.goldBtn then
                self:onGoldClick(sender)
            elseif sender == self.glowBtn then
                self:onGlowClick(sender)
            elseif sender == self.closeBtn then
                self:onCloseClick(sender)
            end
        end
    end
    
    self.cardBtn:addTouchEventListener(btnCallback)
    self.goldBtn:addTouchEventListener(btnCallback)
    self.glowBtn:addTouchEventListener(btnCallback)
    self.closeBtn:addTouchEventListener(btnCallback)
    
    local function scrollViewEvent(sender, evenType)
        if evenType == ccui.ScrollviewEventType.scrolling then
            self:refreshScrollView()
        end
    end
    self.scrollView:addEventListener(scrollViewEvent)
    
    self:changeView(self.cardBtn)
end

function AchWindow:refreshScrollView()
    for i=1, #self.items do
        local item = self.items[i]
        
        if item.setupViewed==false then
            local gpos = self.scrollView:convertToWorldSpace(cc.p(0,0))
            local size = self.scrollView:getContentSize()
            local srect = cc.rect(gpos.x,gpos.y,size.width,size.height)

            gpos = item:convertToWorldSpace(cc.p(0,0))
            size = cc.size(633,127)
            local irect = cc.rect(gpos.x-size.width/2,gpos.y+size.height/2,size.width,size.height)

            if cc.rectIntersectsRect(srect,irect)==true then
                item:setupViews()
            else
                if cc.rectGetMinY(srect)>cc.rectGetMaxY(irect) then
                    break
                end
            end
        end
    end
end

function AchWindow:changeView(button)
    local btns = {self.cardBtn,self.goldBtn,self.glowBtn}
    local type = 1
    self.itemRowSize = 1
    self.itemColOffset = 0
    self.itemRowOffset = 10
    self.itemSize = cc.size(633,127)

    for i = 1 ,#btns do
        local btn = btns[i]
        if button==btn then
            btn:setTouchEnabled(false)
            btn:setHighlighted(true)
        else
            btn:setTouchEnabled(true)
            btn:setHighlighted(false)
        end
    end

    if button==self.cardBtn then
        type = 1
    elseif button==self.glowBtn then
        type = 2
    elseif button==self.goldBtn then
        type = 3
    end
    
    self.pointsText:setString("总成就:"..UserDataModel.getInst():getAchPoints(type).."/"..ResourceModel.getInst():getTotalAchPoint())

    local achs = ResourceModel.getInst():getAchList(type)

    local innerSize,size = self:resetView(#achs)
    self.items = {}

    for i=1, #achs do
        local item = AchItem.create(achs[i])
        local yu = (i-1)%self.itemRowSize
        local rows = math.floor((i-1)/self.itemRowSize)
        local tx = self.itemSize.width/2+2+yu*(self.itemSize.width+self.itemColOffset)
        local ty = -self.itemSize.height/2+innerSize.height-rows*(self.itemSize.height+self.itemRowOffset)
        item:setPosition(cc.p(tx,ty))
        self.scrollView:addChild(item)
        table.insert(self.items,#self.items+1,item)
    end
    
    self.scrollView:jumpToTop()
    
    self:refreshScrollView()
end

function AchWindow:resetView(num)
    self.scrollView:removeAllChildren(true)

    local innerWidth = self.scrollView:getContentSize().width
    local innerHeight = self.scrollView:getContentSize().height

    local rows = math.ceil(num/self.itemRowSize)
    local th = (self.itemSize.height+self.itemRowOffset)*rows-self.itemRowOffset

    if th > innerHeight then
        innerHeight = th
    end

    local size = self.scrollView:getContentSize()
    local innerSize = cc.size(innerWidth, innerHeight)

    self.scrollView:setInnerContainerSize(innerSize)

    return innerSize,size
end

function AchWindow:onCardClick(sender)
    self:changeView(sender)
end

function AchWindow:onGoldClick(sender)
    self:changeView(sender)
end

function AchWindow:onGlowClick(sender)
    self:changeView(sender)
end

function AchWindow:onCloseClick(sender)
    AchWindow.hide()
end