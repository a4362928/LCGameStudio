AchItem = class("AchItem",function()
    return cc.Node:create()
end)

AchItem.__index = AchItem

function AchItem.create(vo)
    local item = AchItem.new(vo)
    return item
end

function AchItem:ctor(vo)
    self.vo = vo
    self.setupViewed = false
    
    --self:setupViews()
end

function AchItem:setupViews()
    if self.setupViewed==true then
        return
    end
    
    self.setupViewed = true
    
    self.bg = cc.Sprite:create("parts/ach/yidongkuangdilan.png")
    self:addChild(self.bg)
    
    local size = self.bg:getContentSize()
    self:setContentSize(size)
    
    self.icon = cc.Sprite:create("parts/ach/icons/"..self.vo.id..".png")
    self.icon:setPosition(-size.width/2+self.icon:getContentSize().width/2+11,3)
    self:addChild(self.icon)
    
    --成就名称
    self.nameText = ccui.Text:create()
    self.nameText:setFontSize(24)
    self.nameText:setColor(cc.c3b(81,69,43))
    self.nameText:setPosition(-size.width/2+120,size.height/2-22)
    self.nameText:setAnchorPoint(0,0.5)
    self.nameText:setString(self.vo.name)
    self:addChild(self.nameText)
    
    --成就描述
    self.descText = ccui.Text:create()
    self.descText:setTextAreaSize(cc.size(320,50))
    self.descText:setFontSize(20)
    self.descText:setColor(cc.c3b(81,69,43))
    self.descText:setPosition(-size.width/2+120,size.height/2-35)
    self.descText:setAnchorPoint(0,1)
    self.descText:setString(self.vo.desc)
    self:addChild(self.descText)
    
    local userAch = UserDataModel.getInst():getUserAch(self.vo.id)
    --完成进度
    self.progressBG = cc.Sprite:create("parts/ach/jindutiao-1.png")
    self.progressBG:setAnchorPoint(0,0.5)
    self.progressBG:setPosition(-size.width/2+120,size.height/2-100)
    self:addChild(self.progressBG)
    
    local curNum = userAch and userAch.currentNum or 0
    local totalNum = self.vo.totalNum
    
    --金币以万为单位
    if self.vo.type==31 then
        totalNum = totalNum*10000
    end
    
    --成就完成时，当前数值以要求数量为准
    if userAch and userAch.finished>=1 and curNum > totalNum then
        curNum = totalNum
    end

    local p = curNum/totalNum*100
    --当成就未完成且要求数量==0时，设置p==0
    if not userAch or userAch.finished<1 then
        if totalNum==0 then
            p = 0
        end
    end
    
    self.progressBar = ccui.LoadingBar:create("parts/ach/jingdutiao.png",p)
    self.progressBar:setAnchorPoint(0,0.5)
    self.progressBar:setPosition(-size.width/2+120+1,size.height/2-100)
    self:addChild(self.progressBar)
    
    self.progressText = ccui.Text:create()
    self.progressText:setFontSize(20)
    self.progressText:setPosition(-size.width/2+120+85,size.height/2-100)
    self.progressText:setString(curNum.."/"..totalNum)
    self:addChild(self.progressText)
    
    --奖励点
    local s = cc.size(0,0)
    self.pointGroup = ccui.ImageView:create("parts/ach/jianli.png")
    self.pointGroup:setPosition(size.width/2-45,size.height/2-40)
    self:addChild(self.pointGroup)
    
    s = self.pointGroup:getContentSize()
    self.pointText = ccui.Text:create()
    self.pointText:setAnchorPoint(0.5,0.5)
    self.pointText:setFontSize(20)
    self.pointText:setPosition(s.width/2,s.height/2)
    self.pointText:setString(self.vo.source)
    self.pointGroup:addChild(self.pointText)
    
    self.jianliText = ccui.Text:create()
    self.jianliText:setAnchorPoint(1,0.5)
    self.jianliText:setFontSize(24)
    self.jianliText:setColor(cc.c3b(81,69,43))
    self.jianliText:setPosition(-s.width/2+20,s.height/2)
    self.jianliText:setString("奖励:")
    self.pointGroup:addChild(self.jianliText)
    
    --称号

    if self.vo.title and self.vo.title~="" then
        local sname = "parts/ach/caidaitiao.png"
        
        self.titleGroup = ccui.ImageView:create(sname)
        self.titleGroup:setAnchorPoint(1,0.5)
        self.titleGroup:setPosition(size.width/2+8,-30)
        self:addChild(self.titleGroup)
        
        s = self.titleGroup:getContentSize()
        self.titleText = ccui.Text:create()
        self.titleText:setFontSize(24)
        self.titleText:setAnchorPoint(0.5,0.5)
        self.titleText:setPosition(s.width/2,s.height/2+4)
        self.titleText:setString(self.vo.title)
        self.titleGroup:addChild(self.titleText)
        
        if string.len(self.vo.title) > 12 then
            self.titleText:setFontSize(22)
        end
    end
    
    --未完成遮罩
    if not userAch or userAch.finished<1 then
        local mask = cc.Sprite:create("parts/ach/weiwanchuisezhezhao.png")
        mask:setPosition(-2,4)
        self:addChild(mask)
    end
end