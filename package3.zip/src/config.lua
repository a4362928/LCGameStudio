Config = Config or {}

Config.debugEnabled = true

--testlogin
Config.ServerInput = false
Config.version = "1.0.0"

Config.Server =
    {
        --ip = "jlb.gunabc.com",
        ip = "58.215.179.160",
        --ip = "127.0.0.1",
        --port = 8215,
        --ip = "192.168.1.66",
        --ip = "192.168.1.190",
        --port = 8205,
        port = 8444,
        openid = nil,
        openkey = "guyu",
        pf = "mainweb",
    }