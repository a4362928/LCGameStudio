local events = {
    {id=1,name="首次充值奖励1",title="首次充值送金币1",beginDate=0,endDate=0,desc="首次充值任意金额送10万金币",icon=""},
    {id=2,name="首次充值奖励2",title="首次充值送金币2",beginDate=0,endDate=0,desc="首次充值任意金额送10万金币首次充值任意金额送10万金币",icon=""},
}

return events