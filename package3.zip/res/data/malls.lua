local malls = {
    golds_ios={
        {id=1,name="60,000",gold=60000,rmb=6,ex="",free=0,icon="parts/mall/6w.png"},
        {id=2,name="300,000",gold=300000,rmb=30,ex="赠送2W",free=20000,icon="parts/mall/30w.png"},
        {id=3,name="600,000",gold=600000,rmb=60,ex="赠送6W",free=60000,icon="parts/mall/60w.png"},
        {id=4,name="1980,000",gold=1980000,rmb=198,ex="赠送20W",free=200000,icon="parts/mall/198w.png"},
        {id=5,name="3280,000",gold=3280000,rmb=328,ex="赠送45W",free=450000,icon="parts/mall/328w.png"},
        {id=6,name="6480,000",gold=6480000,rmb=648,ex="赠送100W",free=1000000,icon="parts/mall/648w.png"}
    },
    golds_android={
        {id=1,name="20,000",gold=20000,rmb=2,ex="",free=0,icon="parts/mall/6w.png"},
        {id=2,name="100,000",gold=100000,rmb=10,ex="赠送1W",free=10000,icon="parts/mall/30w.png"},
        {id=3,name="500,000",gold=500000,rmb=50,ex="赠送6W",free=60000,icon="parts/mall/60w.png"},
        {id=4,name="1000,000",gold=1000000,rmb=100,ex="赠送15W",free=150000,icon="parts/mall/198w.png"},
        {id=5,name="3000,000",gold=3000000,rmb=300,ex="赠送50W",free=500000,icon="parts/mall/328w.png"},
        {id=6,name="5000,000",gold=5000000,rmb=500,ex="赠送90W",free=900000,icon="parts/mall/648w.png"}
    },
    vips={
        {id=1,name="白银贵宾卡",desc="加勒比海域豪华游轮的贵宾通行证，购买后立即获得12万金币7天内每天登录可领4万金币，总共可得40万金币。",rmb=30,icon="parts/mall/zhouka.png"},
        {id=2,name="黄金贵宾卡",desc="加勒比海域豪华游轮的贵宾通行证，购买后立即获得40万金币30天内每天登录可领4万金币，总共可得160万金币。",rmb=98,icon="parts/mall/yueka.png"}
    },
    frees={
    }
}

return malls