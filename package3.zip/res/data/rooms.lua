local roomObjs = {
    {baseBet=100,enterNum=1000,maxBet=1000,id=1,name="新手场",serverId=1,sysCost=0,type=1},
    {baseBet=500,enterNum=5000,maxBet=5000,id=2,name="初级场",serverId=1,sysCost=50,type=2},
    {baseBet=2000,enterNum=20000,maxBet=20000,id=3,name="中级场",serverId=1,sysCost=200,type=3},
    {baseBet=5000,enterNum=50000,maxBet=50000,id=4,name="高级场",serverId=1,sysCost=500,type=4},
    {baseBet=0,enterNum=0,id=5,name="比赛场",serverId=1,sysCost=0,type=5}
}
return roomObjs